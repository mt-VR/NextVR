# Next VR

A browser-based MR workspace for Android, built on the existing React, Three.js CSS3D, camera hand-tracking and quaternion 3DOF systems. The original movement, resize, passthrough and player modules are retained and extended.

## Startup And Controls

- Startup shows only the spatial desktop and the dock. No app, camera, Hand worker, YouTube iframe or external site starts automatically.
- On a fresh install, Next VR first asks for Portuguese, English or Spanish. The choice is saved locally and can be changed later from Settings or the floating menu without resetting the workspace.
- Tap the hand icon to enable camera hand tracking. Tap it again to stop tracking. If passthrough is also off, the camera stream is stopped.
- Camera MR and the "Mundo real" environment explicitly request camera permission. Camera frames are shared with Hand instead of opening another camera stream.
- Drag the background or use arrow keys to look on desktop. On mobile, device orientation uses a low-gain yaw/pitch reference calibrated at startup. It never recalibrates when an app opens.
- The dock's Next VR logo recenters the workspace. Nothing follows head motion as a screen-fixed dock.
- The adjacent ↺ dock button and the floating menu's Centralizar action treat the *current phone direction* as the new forward reference without repositioning windows or dock. Landscape starts the dock closer to the viewer; a manually moved dock is respected.
- Window position and rotation are stored when a window is placed. Every spatial object is created with billboarding disabled; the render loop never rewrites a window quaternion from camera/head orientation. A user can look away and the window remains in its physical world-space pose.
- Apps open from dock/library icons only. White bottom handles move one window. Corner brackets resize it; +/- controls and Cinema are explicit size requests.
- Red X closes only that app and releases its resources. Minimize preserves its state and pauses YouTube; use its icon or Multitask to restore it.

## Hand Tracking

- MediaPipe tracks the real hand's 21 landmarks. A touch or mouse pointer never creates a simulated hand.
- GPU inference runs in an inline classic worker when supported, with CPU and compatible main-thread fallbacks. The worker receives one frame at a time, not a queue of stale frames.
- Adaptive inference rate/resolution, One Euro smoothing, bounded short-horizon prediction, whole-palm identity matching and adjustable loss tolerance reduce jitter and brief visual disappearances.
- Pinch is normalized to palm size, requires an open-hand arming state, uses separate close/open thresholds and a configurable confirmation duration. Buttons activate on release. Missing or unreliable fingertip data cannot trigger new clicks.
- Pinch and move vertically over scrollable content to scroll instead of click. Grab/resize gestures remain separate. Keyboard keys, dock, store and in-app YouTube results use the same interaction system.
- Hands are rendered on their own transparent layer above all HTML windows, keyboard and iframe surfaces. That renderer is created only when Hand is enabled.
- Monocular tracking cannot recover fingers outside the camera or provide native Quest-grade accuracy. Long losses hide the hand; short holds never invent new gestures. Hardware performance has not been benchmarked in this environment.

## Workspace And Apps

- `src/mr/workspace.ts` supplies fixed world-space arc slots. Three apps occupy separate center/left/right slots, with identical base window width and height. Their position and rotation remain fixed in the world after placement. Moving one window does not reorganize the others.
- The multitask manager does not consume an app slot. Exactly three app slots are available; opening a fourth minimizes the oldest visible app without closing it. "Abrir 3 abas" explicitly opens YouTube, Browser and Gallery, and never runs during startup.
- Explicit "Organizar em arco" resets positions and sizes. Settings also offers flat placement, window scale and distance. Windows behind the viewer are culled from UI hit testing/rendering.
- Three dock styles are available: Vidro, Carbon and Minimal. Dock size, accent, reduced motion and custom PNG icons are saved as preferences. Enabling the camera or Hand is intentionally not persisted.
- The store follows the reference's tab navigation, three-column discovery list and cover carousel. Wishlist is local. Game details and official Meta/Steam links work; the web app does not install Quest games or Android APKs, fabricate prices or process payments.
- The library uses the same reference-inspired rectangular application tiles. Existing demo panels remain available; contacts/headset information in those panels is illustrative rather than real Android data.
- The spatial keyboard is a separate world-space element. It edits native React inputs and submits searches/forms. Closing/minimizing its owning app disconnects the input. Android's own keyboard can be used by disabling the spatial keyboard option.
- Gallery reads only user-selected images through the Android/browser picker. The picker is a native permission surface; after selection, viewing, zoom and previous/next navigation stay inside the MR window. Photos are never uploaded, enumerated silently or modified. Session limits are 48 images, 25 MB per image and 96 MB total; object URLs are revoked when the window closes.
- Studio, Next VR Home, Aurora and Sunset change the virtual environment in-place. Passthrough is explicitly enabled with permission. Environment changes do not close other windows or restart the app.
- All environments use the original lightweight 3D room with different solid palettes. There are no panorama, skybox or 360-degree image downloads. Next VR Home is the startup default.

## YouTube And Browser

YouTube uses the official IFrame player and official YouTube Data API v3. There are no preselected videos. Search, pagination, result selection and playback happen inside the same normal-sized MR window after a real API key is connected. The virtual keyboard can enter search queries; copying video links is optional, not the primary workflow.

**A YouTube API key is not included.** The "YouTube oficial" link and keyword search open real YouTube results in another tab or, on Android, try to open the actual YouTube app with an official web fallback. Next VR remains open for return. Searching inside the MR window still requires a user-supplied official YouTube Data API v3 key. Android app launch uses a Chrome intent and may require a real touch, not a synthetic pinch.

To search/select results inside the MR window, enable YouTube Data API v3 in your Google Cloud project, restrict a browser key to your site's HTTP referrers and that API, and configure `VITE_YOUTUBE_API_KEY` in `.env.local` using `.env.example`. Alternatively, enter a key in the YouTube window; UI-entered keys remain in that window's memory only. There are no fabricated results or unofficial public search proxies.

Google Search is provided through Google's official **Programmable Search Element**, rendered in the browser window. Configure a web-search engine in the Google Programmable Search control panel, then set `VITE_GOOGLE_CSE_ID` or enter its `cx` ID in the Browser configuration. This is required because regular `google.com` search pages forbid iframe embedding. The native Next VR address field and virtual keyboard execute the official search control; results can be selected with the existing hand interaction when Google's result markup is in the host DOM. Some destination websites can still refuse iframe rendering due to their own security policy.

The complete YouTube website, Google search and some other sites block embedding. A frontend cannot bypass those policies. Playback may also be restricted by the video owner, age, region, privacy or the browser's autoplay/referrer policy. Official playback errors and explicit external fallback links are provided.

The Next VR Browser uses Google Programmable Search when configured with a CSE ID. This is the official Google-compatible embeddable search format because google.com blocks regular iframes. Supported sites stay inside the browser iframe after selection. Cross-origin iframe content cannot be driven directly by this app's synthetic pinch/keyboard; address-bar interactions and Next VR controls can. Native Android WebView/OS integration would require an Android wrapper not present in this repository.

## Two-Eye Mode

The supplied base used a single view; no native stereo-camera acquisition existed. An opt-in experimental Cardboard mode now projects the 3D scene and hand layer into left/right viewports. A synchronized DOM mirror shares the original application state instead of mounting another React app. The right YouTube player is muted and synchronized to the primary player.

Use landscape orientation. The passthrough feed is shared from one camera, not real dual-camera stereo capture. Two-eye mode requires additional rendering/video decoding, and browser-provided iframe content may have synchronization restrictions. It must be validated on the intended phone/headset; it is not native WebXR, lens distortion calibration or 6DOF SLAM.

## Performance And Verification

Equilibrado is the mobile default and targets 45 FPS at native pixel ratio. Economia targets 24 FPS at reduced resolution; Qualidade targets 60 FPS with a modest pixel-ratio increase. Environment geometry uses unlit low-poly meshes; dynamic shadows, panorama downloads, environment lights and extra grid layers are disabled. Hidden/minimized YouTube requests and player polling stop; the Hand layer/worker and camera are released when not required.

When the page goes into the background, the camera and Hand worker stop. On return, only a camera mode the user had already enabled in that session is resumed; a fresh launch never resumes camera access automatically.

The project is checked using its production build tool. Live YouTube search still requires credentials and quota. Camera accuracy, gesture stability, actual Android FPS, gallery picker behavior and binocular playback need real-device testing; a successful build is not a hardware/performance test.

## Orientation Fix

Device readings are converted to independent heading and tilt deltas, then clamped and passed through a quaternion smoothing filter. The default gain is intentionally low (28%) and can be adjusted in General. Centralization changes only the sensor reference. This still needs validation with the intended Android phone.