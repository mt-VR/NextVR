/** Angle-aware Kalman + 1€ filter chain for 3DOF IMU smoothing. */

export function unwrapAngle(prev: number, next: number): number {
  let d = next - prev;
  while (d > Math.PI) d -= Math.PI * 2;
  while (d < -Math.PI) d += Math.PI * 2;
  return prev + d;
}

export class Kalman1D {
  q: number;
  r: number;
  p = 1;
  x = 0;
  v = 0;
  ready = false;

  constructor(processNoise = 0.012, measurementNoise = 0.08) {
    this.q = processNoise;
    this.r = measurementNoise;
  }

  reset(x = 0) {
    this.x = x;
    this.v = 0;
    this.p = 1;
    this.ready = false;
  }

  update(z: number, dt = 1 / 60): number {
    if (!this.ready) {
      this.x = z;
      this.ready = true;
      return z;
    }
    // Constant-velocity prediction
    this.x += this.v * dt;
    this.p += this.q + Math.abs(this.v) * 0.002;

    const k = this.p / (this.p + this.r);
    const innov = z - this.x;
    this.x += k * innov;
    this.v = this.v * 0.85 + (innov / Math.max(dt, 1e-4)) * 0.15;
    this.p *= 1 - k;
    return this.x;
  }
}

class LowPass {
  y: number | null = null;
  hatxprev = 0;

  filter(x: number, a: number): number {
    if (this.y === null) {
      this.y = x;
      this.hatxprev = x;
      return x;
    }
    const y = a * x + (1 - a) * this.y;
    this.hatxprev = this.y;
    this.y = y;
    return y;
  }

  reset() {
    this.y = null;
  }
}

function alpha(dt: number, cutoff: number): number {
  const tau = 1 / (2 * Math.PI * cutoff);
  return 1 / (1 + tau / Math.max(dt, 1e-5));
}

/** One Euro Filter — low lag during fast motion, strong smoothing at rest. */
export class OneEuro {
  minCutoff: number;
  beta: number;
  dCutoff: number;
  x = new LowPass();
  dx = new LowPass();
  lastT: number | null = null;
  lastX: number | null = null;

  constructor(minCutoff = 1.15, beta = 0.045, dCutoff = 1.0) {
    this.minCutoff = minCutoff;
    this.beta = beta;
    this.dCutoff = dCutoff;
  }

  reset() {
    this.x.reset();
    this.dx.reset();
    this.lastT = null;
    this.lastX = null;
  }

  filter(v: number, t: number): number {
    if (this.lastT === null || this.lastX === null) {
      this.lastT = t;
      this.lastX = v;
      this.x.filter(v, 1);
      return v;
    }
    const dt = Math.max((t - this.lastT) / 1000, 1e-4);
    const rawDx = (v - this.lastX) / dt;
    const edx = this.dx.filter(rawDx, alpha(dt, this.dCutoff));
    const cutoff = this.minCutoff + this.beta * Math.abs(edx);
    const y = this.x.filter(v, alpha(dt, cutoff));
    this.lastT = t;
    this.lastX = v;
    return y;
  }
}

export class PoseFilter3DOF {
  ky = new Kalman1D(0.018, 0.07);
  kp = new Kalman1D(0.018, 0.07);
  kr = new Kalman1D(0.02, 0.09);
  ey = new OneEuro(1.2, 0.05, 1.0);
  ep = new OneEuro(1.2, 0.05, 1.0);
  er = new OneEuro(1.35, 0.04, 1.0);
  uy = 0;
  up = 0;
  ur = 0;
  primed = false;

  yaw = 0;
  pitch = 0;
  roll = 0;

  reset() {
    this.ky.reset();
    this.kp.reset();
    this.kr.reset();
    this.ey.reset();
    this.ep.reset();
    this.er.reset();
    this.primed = false;
  }

  update(yaw: number, pitch: number, roll: number, t: number, dt: number) {
    if (!this.primed) {
      this.uy = yaw;
      this.up = pitch;
      this.ur = roll;
      this.primed = true;
    } else {
      this.uy = unwrapAngle(this.uy, yaw);
      this.up = unwrapAngle(this.up, pitch);
      this.ur = unwrapAngle(this.ur, roll);
    }

    const ky = this.ky.update(this.uy, dt);
    const kp = this.kp.update(this.up, dt);
    const kr = this.kr.update(this.ur, dt);

    this.yaw = this.ey.filter(ky, t);
    this.pitch = this.ep.filter(kp, t);
    this.roll = this.er.filter(kr, t);

    return { yaw: this.yaw, pitch: this.pitch, roll: this.roll };
  }
}
