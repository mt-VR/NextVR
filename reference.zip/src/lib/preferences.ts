import { useEffect, useState } from "react";

export type DockStyle = "glass" | "carbon" | "minimal";
export type EnvironmentId = "studio" | "horizon" | "aurora" | "sunset" | "passthrough";
export type PerformanceMode = "balanced" | "battery" | "quality";
export type NextLanguage =
  | "pt"
  | "en"
  | "en-GB"
  | "es"
  | "es-419"
  | "ja"
  | "fr"
  | "de"
  | "ko"
  | "it"
  | "nl"
  | "ru"
  | "pl"
  | "zh"
  | "tr"
  | "ar";

export interface MetaPreferences {
  dockStyle: DockStyle;
  dockScale: number;
  iconImages: Record<string, string>;
  pinchConfirmMs: number;
  handHoldMs: number;
  handSmoothing: number;
  gyroSensitivity: number;
  performance: PerformanceMode;
  virtualKeyboard: boolean;
  windowScale: number;
  windowDistance: number;
  autoArrange: boolean;
  accent: string;
  reduceMotion: boolean;
  environment: Exclude<EnvironmentId, "passthrough">;
  language: NextLanguage;
  languageConfigured: boolean;
}

export const DEFAULT_PREFERENCES: MetaPreferences = {
  dockStyle: "glass", dockScale: 0.85, iconImages: {},
  pinchConfirmMs: 90, handHoldMs: 600, handSmoothing: 0.55, gyroSensitivity: 0.28,
  performance: "balanced", virtualKeyboard: true,
  windowScale: 0.9, windowDistance: 1.25, autoArrange: true,
  accent: "#9bbaff", reduceMotion: false, environment: "horizon",
  language: "pt", languageConfigured: false,
};

export function useMetaPreferences() {
  const [preferences, setPreferences] = useState<MetaPreferences>(() => {
    try {
      const saved = JSON.parse(localStorage.getItem("metamr:preferences") ?? "null");
      const defaults = DEFAULT_PREFERENCES;
      return saved ? {
        ...defaults,
        dockStyle: ["glass", "carbon", "minimal"].includes(saved.dockStyle) ? saved.dockStyle : defaults.dockStyle,
        dockScale: Math.max(0.65, Math.min(1.2, Number(saved.dockScale) || defaults.dockScale)),
        iconImages: typeof saved.iconImages === "object" && saved.iconImages ? saved.iconImages : {},
        pinchConfirmMs: Math.max(60, Math.min(200, Number(saved.pinchConfirmMs) || 90)),
        handHoldMs: Math.max(300, Math.min(900, Number(saved.handHoldMs) || 600)),
        handSmoothing: typeof saved.handSmoothing === "number" && Number.isFinite(saved.handSmoothing) ? Math.max(0, Math.min(1, saved.handSmoothing)) : 0.55,
        gyroSensitivity: typeof saved.gyroSensitivity === "number" && Number.isFinite(saved.gyroSensitivity) ? Math.max(0.12, Math.min(0.42, saved.gyroSensitivity)) : defaults.gyroSensitivity,
        performance: ["balanced", "battery", "quality"].includes(saved.performance) ? saved.performance : defaults.performance,
        virtualKeyboard: saved.virtualKeyboard !== false,
        windowScale: Math.max(0.6, Math.min(1.3, Number(saved.windowScale) || 0.9)),
        windowDistance: Math.max(1, Math.min(1.9, Number(saved.windowDistance) || 1.25)),
        autoArrange: saved.autoArrange !== false,
        accent: /^#[a-f0-9]{6}$/i.test(saved.accent ?? "") ? saved.accent : defaults.accent,
        reduceMotion: saved.reduceMotion === true,
        // Older panorama presets map to the original lightweight 3D room after panorama removal.
        environment: ["studio", "aurora", "sunset"].includes(saved.environment) ? "horizon" : saved.environment === "horizon" ? "horizon" : defaults.environment,
        language: ["pt", "en", "en-GB", "es", "es-419", "ja", "fr", "de", "ko", "it", "nl", "ru", "pl", "zh", "tr", "ar"].includes(saved.language) ? saved.language : defaults.language,
        languageConfigured: saved.languageConfigured === true,
      } : defaults;
    } catch { return DEFAULT_PREFERENCES; }
  });
  useEffect(() => {
    try { localStorage.setItem("metamr:preferences", JSON.stringify(preferences)); } catch { /* Storage is optional. */ }
  }, [preferences]);
  const update = (patch: Partial<MetaPreferences>) => setPreferences((current) => ({ ...current, ...patch }));
  return { preferences, update, reset: () => setPreferences(DEFAULT_PREFERENCES) };
}