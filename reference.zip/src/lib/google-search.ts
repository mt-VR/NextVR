export interface GoogleCseControl {
  execute: (query: string) => void;
  clearAllResults?: () => void;
}

interface GoogleCseApi {
  render: (config: { div: HTMLElement; tag: "searchresults-only"; gname: string; attributes?: Record<string, string> }) => void;
  getElement: (gname: string) => GoogleCseControl | null;
}

type GoogleWindow = Window & {
  __gcse?: { parsetags?: "explicit"; callback?: () => void };
  google?: { search?: { cse?: { element?: GoogleCseApi } } };
};

const loads = new Map<string, Promise<GoogleCseApi>>();

/** Load Google's official Programmable Search Element into the current window. */
export function loadGoogleCse(cx: string): Promise<GoogleCseApi> {
  const id = cx.trim();
  if (!id) return Promise.reject(new Error("Informe o ID do mecanismo de busca do Google."));
  const host = window as GoogleWindow;
  const available = host.google?.search?.cse?.element;
  if (available) return Promise.resolve(available);
  const known = loads.get(id);
  if (known) return known;

  const promise = new Promise<GoogleCseApi>((resolve, reject) => {
    let settled = false;
    const resolveApi = () => {
      const api = host.google?.search?.cse?.element;
      if (!api || settled) return;
      settled = true;
      clearTimeout(timeout);
      resolve(api);
    };
    const fail = () => {
      if (settled) return;
      settled = true;
      loads.delete(id);
      clearTimeout(timeout);
      reject(new Error("O Google Programmable Search não carregou. Verifique o ID e sua conexão."));
    };
    const timeout = window.setTimeout(fail, 15000);
    host.__gcse = { parsetags: "explicit", callback: resolveApi };
    const script = document.createElement("script");
    script.async = true;
    script.src = `https://cse.google.com/cse.js?cx=${encodeURIComponent(id)}`;
    script.referrerPolicy = "strict-origin-when-cross-origin";
    script.onerror = fail;
    script.onload = () => window.setTimeout(resolveApi, 0);
    document.head.appendChild(script);
  });
  loads.set(id, promise);
  return promise;
}