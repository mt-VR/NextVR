export interface YouTubeSelection {
  videoId: string | null;
  playlistId: string | null;
  startSeconds: number;
  title: string;
  channel?: string;
}

export interface YouTubeResult {
  id: string;
  title: string;
  channel: string;
  thumbnail: string;
  publishedAt: string;
}

export interface YouTubeSearchPage {
  videos: YouTubeResult[];
  nextPageToken: string | null;
}

const VIDEO_ID = /^[A-Za-z0-9_-]{11}$/;
const PLAYLIST_ID = /^[A-Za-z0-9_-]{10,100}$/;
const HOSTS = new Set([
  "youtube.com", "www.youtube.com", "m.youtube.com", "music.youtube.com",
  "youtu.be", "www.youtu.be", "youtube-nocookie.com", "www.youtube-nocookie.com",
]);

function parseTimestamp(value: string | null): number {
  if (!value) return 0;
  if (/^\d+$/.test(value)) return Math.min(Number(value), 604800);
  if (/^(?:\d+h)?(?:\d+m)?(?:\d+s)?$/.test(value)) {
    return Math.min(
      Number(value.match(/(\d+)h/)?.[1] ?? 0) * 3600 +
      Number(value.match(/(\d+)m/)?.[1] ?? 0) * 60 +
      Number(value.match(/(\d+)s/)?.[1] ?? 0), 604800,
    );
  }
  return 0;
}

export function parseYouTubeLink(input: string): YouTubeSelection | null {
  const text = input.trim();
  if (VIDEO_ID.test(text)) {
    return { videoId: text, playlistId: null, startSeconds: 0, title: "Seu v\u00eddeo" };
  }
  const sharedUrl = text.match(/(?:https?:\/\/)?(?:www\.|m\.|music\.)?(?:youtube(?:-nocookie)?\.com|youtu\.be)\/[^\s<>]+/i)?.[0];
  if (!sharedUrl) return null;
  try {
    const url = new URL(/^https?:\/\//i.test(sharedUrl) ? sharedUrl : `https://${sharedUrl}`);
    if (!HOSTS.has(url.hostname.toLowerCase())) return null;
    const parts = url.pathname.split("/").filter(Boolean);
    const rawVideo = url.hostname.endsWith("youtu.be") ? parts[0] :
      ["shorts", "live", "embed", "v"].includes(parts[0]) ? parts[1] : url.searchParams.get("v");
    const rawList = url.searchParams.get("list");
    const videoId = rawVideo && VIDEO_ID.test(rawVideo) ? rawVideo : null;
    const playlistId = rawList && PLAYLIST_ID.test(rawList) ? rawList : null;
    if (!videoId && !playlistId) return null;
    return {
      videoId,
      playlistId,
      startSeconds: parseTimestamp(url.searchParams.get("t") ?? url.searchParams.get("start")),
      title: videoId ? "Seu v\u00eddeo" : "Sua playlist",
    };
  } catch {
    return null;
  }
}

export function isWebLink(input: string) {
  return /^(?:https?:\/\/|www\.|m\.youtube|youtu\.be|youtube\.com)/i.test(input.trim());
}

export function youtubeWatchUrl(selection: YouTubeSelection): string {
  const url = new URL(selection.videoId ? "https://www.youtube.com/watch" : "https://www.youtube.com/playlist");
  if (selection.videoId) url.searchParams.set("v", selection.videoId);
  if (selection.playlistId) url.searchParams.set("list", selection.playlistId);
  if (selection.startSeconds) url.searchParams.set("t", `${selection.startSeconds}s`);
  return url.toString();
}

export function youtubeSearchUrl(query: string) {
  const url = new URL("https://www.youtube.com/results");
  url.searchParams.set("search_query", query.trim());
  return url.toString();
}

export function youtubeOfficialUrl(query = "") {
  return query.trim() ? youtubeSearchUrl(query) : "https://www.youtube.com/";
}

export function youtubeAndroidIntent(query = "") {
  const url = new URL(youtubeOfficialUrl(query));
  return `intent://${url.host}${url.pathname}${url.search}#Intent;scheme=https;action=android.intent.action.VIEW;package=com.google.android.youtube;S.browser_fallback_url=${encodeURIComponent(url.toString())};end`;
}

export function youtubeEmbedUrl(selection: YouTubeSelection) {
  const url = new URL(`https://www.youtube-nocookie.com/embed/${selection.videoId ?? "videoseries"}`);
  url.searchParams.set("enablejsapi", "1");
  url.searchParams.set("autoplay", "1");
  url.searchParams.set("playsinline", "1");
  url.searchParams.set("controls", "1");
  url.searchParams.set("rel", "0");
  url.searchParams.set("hl", "pt-BR");
  if (selection.playlistId) url.searchParams.set("list", selection.playlistId);
  if (selection.startSeconds) url.searchParams.set("start", String(selection.startSeconds));
  if (/^https?:$/.test(window.location.protocol)) url.searchParams.set("origin", window.location.origin);
  return url.toString();
}

function decodeTitle(text: string) {
  const node = document.createElement("textarea");
  node.innerHTML = text;
  return node.value;
}

interface SearchResponse {
  nextPageToken?: string;
  error?: { message?: string; errors?: { reason?: string }[] };
  items?: {
    id?: { videoId?: string };
    snippet?: {
      title?: string;
      channelTitle?: string;
      publishedAt?: string;
      thumbnails?: { medium?: { url?: string }; high?: { url?: string } };
    };
  }[];
}

export async function searchYouTube(
  query: string,
  apiKey: string,
  signal: AbortSignal,
  pageToken?: string,
): Promise<YouTubeSearchPage> {
  const url = new URL("https://www.googleapis.com/youtube/v3/search");
  const params = {
    part: "snippet", q: query, type: "video", maxResults: "12",
    videoEmbeddable: "true", relevanceLanguage: "pt", safeSearch: "moderate",
    key: apiKey.trim(),
  };
  Object.entries(params).forEach(([name, value]) => url.searchParams.set(name, value));
  if (pageToken) url.searchParams.set("pageToken", pageToken);
  const response = await fetch(url, { signal, referrerPolicy: "strict-origin-when-cross-origin" });
  const data: SearchResponse = await response.json();
  if (!response.ok) {
    const reason = data.error?.errors?.[0]?.reason;
    const message = reason === "quotaExceeded" || reason === "dailyLimitExceeded"
      ? "A cota de busca desta chave acabou. Voc\u00ea ainda pode buscar no YouTube e colar um link."
      : reason === "keyInvalid" || response.status === 400
        ? "Verifique a chave da YouTube Data API v3."
        : response.status === 403
          ? "Ative a YouTube Data API v3 e autorize este dom\u00ednio nas restri\u00e7\u00f5es da chave."
          : "A busca n\u00e3o respondeu. Tente novamente ou pesquise no YouTube.";
    throw new Error(message);
  }
  return {
    nextPageToken: data.nextPageToken ?? null,
    videos: (data.items ?? []).flatMap((item) => {
      const id = item.id?.videoId;
      if (!id || !VIDEO_ID.test(id) || !item.snippet) return [];
      return [{
        id,
        title: decodeTitle(item.snippet.title ?? "V\u00eddeo do YouTube"),
        channel: decodeTitle(item.snippet.channelTitle ?? "YouTube"),
        thumbnail: item.snippet.thumbnails?.medium?.url ?? item.snippet.thumbnails?.high?.url ?? `https://i.ytimg.com/vi/${id}/mqdefault.jpg`,
        publishedAt: item.snippet.publishedAt ?? "",
      }];
    }),
  };
}

export interface YouTubePlayerInstance {
  playVideo: () => void;
  pauseVideo: () => void;
  seekTo: (seconds: number, allowSeekAhead: boolean) => void;
  getCurrentTime: () => number;
  getDuration: () => number;
  getPlayerState: () => number;
  mute: () => void;
  unMute: () => void;
  isMuted: () => boolean;
  setSize: (width: number, height: number) => void;
  destroy: () => void;
}

interface YouTubeAPI {
  Player: new (element: HTMLIFrameElement, options: {
    events: {
      onReady: (event: { target: YouTubePlayerInstance }) => void;
      onStateChange: (event: { data: number }) => void;
      onError: (event: { data: number }) => void;
      onAutoplayBlocked: () => void;
    };
  }) => YouTubePlayerInstance;
}

type YouTubeWindow = Window & { YT?: YouTubeAPI; onYouTubeIframeAPIReady?: () => void };
let apiPromise: Promise<YouTubeAPI> | null = null;

export function loadYouTubePlayerAPI(): Promise<YouTubeAPI> {
  const host = window as YouTubeWindow;
  if (host.YT?.Player) return Promise.resolve(host.YT);
  if (apiPromise) return apiPromise;
  apiPromise = new Promise<YouTubeAPI>((resolve, reject) => {
    let finished = false;
    const previous = host.onYouTubeIframeAPIReady;
    const timer = window.setTimeout(() => fail(), 15000);
    function fail() {
      if (finished) return;
      finished = true;
      clearTimeout(timer);
      apiPromise = null;
      reject(new Error("Os controles do YouTube n\u00e3o carregaram. Use os controles do pr\u00f3prio v\u00eddeo."));
    }
    host.onYouTubeIframeAPIReady = () => {
      try { previous?.(); } catch { /* Other embeds must not block this player. */ }
      if (finished || !host.YT?.Player) return;
      finished = true;
      clearTimeout(timer);
      resolve(host.YT);
    };
    let script = document.getElementById("youtube-iframe-api") as HTMLScriptElement | null;
    if (!script) {
      script = document.createElement("script");
      script.id = "youtube-iframe-api";
      script.src = "https://www.youtube.com/iframe_api";
      script.async = true;
      script.referrerPolicy = "strict-origin-when-cross-origin";
      script.onerror = () => { script?.remove(); fail(); };
      document.head.appendChild(script);
    }
  });
  return apiPromise;
}

export function youtubePlayerError(code: number) {
  if (code === 2) return "O link deste v\u00eddeo n\u00e3o \u00e9 v\u00e1lido.";
  if (code === 100) return "Este v\u00eddeo foi removido ou \u00e9 privado.";
  if (code === 101 || code === 150) return "O autor n\u00e3o permite assistir a este v\u00eddeo fora do YouTube.";
  if (code === 153) return "O YouTube n\u00e3o identificou este site. Abra o app por HTTPS ou localhost, sem bloquear o Referer.";
  return "O YouTube n\u00e3o conseguiu reproduzir este v\u00eddeo aqui. Tente novamente ou abra no YouTube.";
}