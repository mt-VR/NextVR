import type { NextLanguage } from "./preferences";

export const LANGUAGE_ORDER: NextLanguage[] = [
  "en", "ja", "fr", "de", "ko", "es", "it", "en-GB", "nl", "ru", "es-419", "pl", "zh", "pt", "tr", "ar",
];

export const LOCALE_LABELS: Record<NextLanguage, { native: string; flag: string; detail: string }> = {
  pt: { native: "Português", flag: "BR", detail: "Português (Brasil)" },
  en: { native: "English", flag: "US", detail: "English (United States)" },
  "en-GB": { native: "English (UK)", flag: "UK", detail: "English (United Kingdom)" },
  es: { native: "Español", flag: "ES", detail: "Español (España)" },
  "es-419": { native: "Español (Latinoamérica)", flag: "LA", detail: "Español (Latinoamérica)" },
  ja: { native: "日本語", flag: "JP", detail: "Japanese" },
  fr: { native: "Français", flag: "FR", detail: "French" },
  de: { native: "Deutsch", flag: "DE", detail: "German" },
  ko: { native: "한국어", flag: "KR", detail: "Korean" },
  it: { native: "Italiano", flag: "IT", detail: "Italian" },
  nl: { native: "Nederlands", flag: "NL", detail: "Dutch" },
  ru: { native: "Русский", flag: "RU", detail: "Russian" },
  pl: { native: "Polski", flag: "PL", detail: "Polish" },
  zh: { native: "简体中文", flag: "CN", detail: "Chinese (Simplified)" },
  tr: { native: "Türkçe", flag: "TR", detail: "Turkish" },
  ar: { native: "العربية", flag: "AR", detail: "Arabic" },
};

type Copy = {
  chooseLanguage: string; continue: string; language: string; languageDescription: string;
  nextVr: string; menu: string; close: string; recenter: string; settings: string; gallery: string;
  environments: string; dock: string; recentApps: string; handTracking: string; apps: string;
  noRecent: string; connected: string; battery: string; fixed: string; general: string;
  interaction: string; appearance: string; windows: string; performance: string; privacy: string;
};

const english: Copy = {
  chooseLanguage: "Choose your language", continue: "Continue", language: "Language", languageDescription: "You can change this later in Settings.",
  nextVr: "Next VR", menu: "Menu", close: "Close", recenter: "Recenter", settings: "Settings", gallery: "Gallery", environments: "Environments", dock: "Dock", recentApps: "Recent apps", handTracking: "Hand tracking", apps: "Apps", noRecent: "No apps open", connected: "Connected", battery: "Battery", fixed: "World locked", general: "General", interaction: "Hands and interaction", appearance: "Appearance", windows: "Windows and multitasking", performance: "Performance", privacy: "Privacy and system",
};
const portuguese: Copy = {
  chooseLanguage: "Escolha seu idioma", continue: "Continuar", language: "Idioma", languageDescription: "Você poderá mudar isso depois nas Configurações.",
  nextVr: "Next VR", menu: "Menu", close: "Fechar", recenter: "Centralizar", settings: "Configurações", gallery: "Galeria", environments: "Ambientes", dock: "Dock", recentApps: "Aplicativos recentes", handTracking: "Hand tracking", apps: "Aplicativos", noRecent: "Nenhum aplicativo aberto", connected: "Conectado", battery: "Bateria", fixed: "Fixo no espaço", general: "Geral", interaction: "Mãos e interação", appearance: "Aparência", windows: "Janelas e multitarefa", performance: "Desempenho", privacy: "Privacidade e sistema",
};
const spanish: Copy = {
  chooseLanguage: "Elige tu idioma", continue: "Continuar", language: "Idioma", languageDescription: "Podrás cambiarlo más tarde en Configuración.",
  nextVr: "Next VR", menu: "Menú", close: "Cerrar", recenter: "Centrar", settings: "Configuración", gallery: "Galería", environments: "Ambientes", dock: "Dock", recentApps: "Apps recientes", handTracking: "Hand tracking", apps: "Aplicaciones", noRecent: "No hay apps abiertas", connected: "Conectado", battery: "Batería", fixed: "Fijo en el espacio", general: "General", interaction: "Manos e interacción", appearance: "Apariencia", windows: "Ventanas y multitarea", performance: "Rendimiento", privacy: "Privacidad y sistema",
};

const copy: Record<NextLanguage, Copy> = {
  pt: portuguese, en: english, "en-GB": english, es: spanish, "es-419": spanish,
  ja: english, fr: english, de: english, ko: english, it: english, nl: english,
  ru: english, pl: english, zh: english, tr: english, ar: english,
};

export type NextCopyKey = keyof Copy;
export function tr(language: NextLanguage, key: NextCopyKey) { return copy[language][key]; }