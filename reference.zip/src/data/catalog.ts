export type AppId =
  | "home"
  | "youtube"
  | "browser"
  | "settings"
  | "contacts"
  | "apps"
  | "store"
  | "music"
  | "video"
  | "games"
  | "worlds"
  | "explore"
  | "media"
  | "photos"
  | "system"
  | "wifi"
  | "guardian"
  | "personalization"
  | "storage"
  | "notifications"
  | "accounts"
  | "hands"
  | "accessibility"
  | "privacy"
  | "security"
  | "experimental"
  | "calls"
  | "elix"
  | "avatar"
  | "feed"
  | "gallery"
  | "multitask"
  | "keyboard"
  | "camera";

export interface SpatialApp {
  id: AppId;
  name: string;
  subtitle?: string;
  color: string;
  color2?: string;
  icon: string;
  iconImage?: string;
  category: "system" | "media" | "social" | "tools" | "store";
}

export interface Contact {
  id: string;
  name: string;
  letter: string;
  color: string;
  online: boolean;
  status: string;
}

export const APPS: SpatialApp[] = [
  { id: "gallery", name: "Galeria", subtitle: "Suas fotos", color: "#65b488", color2: "#277f63", icon: "photo", category: "media" },
  { id: "multitask", name: "Multitarefa", subtitle: "Seu workspace", color: "#9bb8f5", color2: "#526cb8", icon: "layers", category: "system" },
  { id: "camera", name: "Câmera MR", subtitle: "Passthrough", color: "#e38592", color2: "#ae4169", icon: "camera", category: "tools" },
  { id: "youtube", name: "YouTube", subtitle: "Assistir", color: "#ff3b30", color2: "#c41e16", icon: "play", category: "media" },
  { id: "video", name: "Video", subtitle: "Cinema VR", color: "#7b6cff", color2: "#5b4cdb", icon: "film", category: "media" },
  { id: "browser", name: "Browser", subtitle: "Web espacial", color: "#3aa0d8", color2: "#2b7eab", icon: "globe", category: "tools" },
  { id: "explore", name: "Explore", subtitle: "Descobrir", color: "#9b6bdc", color2: "#7a49c4", icon: "square", category: "store" },
  { id: "media", name: "Media", subtitle: "Galeria", color: "#3dcf8a", color2: "#22a066", icon: "phone", category: "media" },
  { id: "music", name: "Music", subtitle: "Ouvir", color: "#e85aad", color2: "#c43386", icon: "music", category: "media" },
  { id: "games", name: "Games", subtitle: "Jogos", color: "#8b7cf6", color2: "#6b5bd4", icon: "diamond", category: "store" },
  { id: "worlds", name: "Ambientes", subtitle: "Mundos virtuais", color: "#d4a574", color2: "#b8864e", icon: "spark", category: "store" },
  { id: "contacts", name: "Pessoas", subtitle: "Amigos", color: "#b57bdc", color2: "#8d52c4", icon: "people", category: "social" },
  { id: "feed", name: "Feed", subtitle: "Notícias", color: "#3b9adf", color2: "#2178b8", icon: "feed", category: "social" },
  { id: "store", name: "Loja", subtitle: "Next VR Store", color: "#f08a2a", color2: "#d46b12", icon: "store", category: "store" },
  { id: "settings", name: "Ajustes", subtitle: "Sistema", color: "#6b7380", color2: "#4e5560", icon: "gear", category: "system" },
  { id: "calls", name: "Chamadas", subtitle: "Talk", color: "#35c46a", color2: "#1ea34e", icon: "phone", category: "social" },
  { id: "apps", name: "Apps", subtitle: "Biblioteca", color: "#4aa3e8", color2: "#2d86cc", icon: "grid", category: "tools" },
  { id: "photos", name: "Fotos", subtitle: "Capturas", color: "#f0a10a", color2: "#d48900", icon: "photo", category: "media" },
  { id: "avatar", name: "Avatar", subtitle: "Seu eu", color: "#9b6bdc", color2: "#7a49c4", icon: "face", category: "social" },
  { id: "elix", name: "Elix", subtitle: "Criar", color: "#2ec9b0", color2: "#1aa890", icon: "spark", category: "tools" },
];

export const SETTINGS_TILES = [
  { id: "system" as AppId, name: "System", subtitle: "Display, Voice Commands, Power", icon: "display" },
  { id: "wifi" as AppId, name: "Wi-Fi", subtitle: "VR", icon: "wifi" },
  { id: "guardian" as AppId, name: "Guardian", subtitle: "Boundary, Passthrough", icon: "grid" },
  { id: "personalization" as AppId, name: "Personalization", subtitle: "Virtual Environment", icon: "pencil" },
  { id: "storage" as AppId, name: "Storage", subtitle: "53.85 GB free of 256.00 GB", icon: "storage" },
  { id: "apps" as AppId, name: "Apps", subtitle: "App Permissions", icon: "grid" },
  { id: "notifications" as AppId, name: "Notifications", subtitle: "Phone Notifications, Do Not Disturb", icon: "people" },
  { id: "accounts" as AppId, name: "Accounts", subtitle: "Add Account, App Sharing", icon: "person" },
  { id: "hands" as AppId, name: "Hands and Controllers", subtitle: "Hand Tracking, controller options", icon: "hand" },
  { id: "accessibility" as AppId, name: "Accessibility", subtitle: "Color Correction, Text Size", icon: "a11y" },
  { id: "privacy" as AppId, name: "Privacy", subtitle: "Activity, Friends List", icon: "shield" },
  { id: "security" as AppId, name: "Security", subtitle: "Unlock pattern for headset", icon: "lock" },
  { id: "experimental" as AppId, name: "Experimental", subtitle: "Features in development", icon: "tools" },
];

export const CONTACTS: Contact[] = [
  { id: "1", name: "Alex Morgan", letter: "A", color: "#e8b4c8", online: true, status: "Em um mundo" },
  { id: "2", name: "Bia Oliveira", letter: "B", color: "#a9c4d8", online: true, status: "Disponível" },
  { id: "3", name: "Chris Parker", letter: "C", color: "#d4b496", online: false, status: "Offline" },
  { id: "4", name: "Daniel Costa", letter: "D", color: "#b5d4b8", online: true, status: "No YouTube" },
  { id: "5", name: "Emilia Santos", letter: "E", color: "#e0b0c8", online: true, status: "Jogando" },
  { id: "6", name: "Felipe Lima", letter: "F", color: "#b0c4d8", online: false, status: "Ausente" },
  { id: "7", name: "Gabi", letter: "G", color: "#dcc4a8", online: true, status: "No Next VR" },
];

export const WIFI_NETWORKS = [
  { ssid: "NextVR-5G", secure: true, bars: 4, connected: true },
  { ssid: "QuestLink", secure: true, bars: 3, connected: false },
  { ssid: "Cafe_MR", secure: false, bars: 2, connected: false },
  { ssid: "VISITORS", secure: true, bars: 1, connected: false },
];

export function appById(id: string) {
  return APPS.find((a) => a.id === id);
}
