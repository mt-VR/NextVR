export interface StoreGame {
  id: number;
  name: string;
  genre: string;
  description: string;
  color: string;
}

export const STORE_GAMES: StoreGame[] = [
  { id: 620980, name: "Beat Saber", genre: "Ritmo", description: "Corte os blocos no ritmo da música em uma experiência de realidade virtual.", color: "#5968da" },
  { id: 1592190, name: "BONELAB", genre: "Ação · Sandbox", description: "Explore um laboratório de física experimental em realidade virtual.", color: "#7d8668" },
  { id: 629730, name: "Blade & Sorcery", genre: "Combate · Fantasia", description: "Combate físico, magia e exploração em mundos de fantasia.", color: "#6f4d94" },
  { id: 1408230, name: "Walkabout Mini Golf", genre: "Esporte · Social", description: "Descubra percursos de minigolfe para jogar sozinho ou com amigos.", color: "#418e92" },
  { id: 617830, name: "SUPERHOT VR", genre: "Ação · Estratégia", description: "O tempo acompanha seus movimentos. Pense antes de agir.", color: "#a64b4b" },
  { id: 1079800, name: "Pistol Whip", genre: "Ritmo · Ação", description: "Uma experiência de ação e música em cenários cinematográficos.", color: "#ae5992" },
  { id: 1782330, name: "Green Hell VR", genre: "Sobrevivência", description: "Uma jornada de sobrevivência em uma floresta tropical.", color: "#5c7640" },
  { id: 1957780, name: "Ghosts of Tabor", genre: "Ação · Multijogador", description: "Uma experiência de extração e combate tático em realidade virtual.", color: "#51715e" },
  { id: 846470, name: "Moss", genre: "Aventura · Puzzle", description: "Ajude uma pequena heroína em uma aventura de enigmas e exploração.", color: "#789267" },
];

export function gameCover(id: number, large = false) {
  return `https://cdn.akamai.steamstatic.com/steam/apps/${id}/${large ? "header" : "library_600x900"}.jpg`;
}