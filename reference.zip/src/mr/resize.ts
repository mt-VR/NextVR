import * as THREE from "three";
import type { CSS3DObject } from "three/addons/renderers/CSS3DRenderer.js";

export type ResizeCorner = "nw" | "ne" | "sw" | "se";
export const MIN_WINDOW_SCALE = 0.56;
export const MAX_WINDOW_SCALE = 1.9;
const PIXEL_TO_METERS = 0.001;

export interface WindowResizeSession {
  id: string;
  object: CSS3DObject;
  plane: THREE.Plane;
  inverseRotation: THREE.Quaternion;
  rotation: THREE.Quaternion;
  startPointer: THREE.Vector3;
  startScale: number;
  anchorPixels: THREE.Vector3;
  anchorWorld: THREE.Vector3;
  diagonalPixels: THREE.Vector3;
}

export interface WindowResizeResult {
  id: string;
  scale: number;
  position: { x: number; y: number; z: number };
}

export function screenPointOnPlane(
  x: number, y: number,
  bounds: { left: number; top: number; width: number; height: number },
  camera: THREE.PerspectiveCamera,
  plane: THREE.Plane,
) {
  const ray = new THREE.Raycaster();
  ray.setFromCamera(new THREE.Vector2(
    ((x - bounds.left) / bounds.width) * 2 - 1,
    1 - ((y - bounds.top) / bounds.height) * 2,
  ), camera);
  return ray.ray.intersectPlane(plane, new THREE.Vector3());
}

export function startWindowResize(
  id: string, object: CSS3DObject, host: HTMLElement,
  corner: ResizeCorner, x: number, y: number,
  bounds: { left: number; top: number; width: number; height: number },
  camera: THREE.PerspectiveCamera,
): WindowResizeSession | null {
  if (!["nw", "ne", "sw", "se"].includes(corner)) return null;
  const frame = host.querySelector<HTMLElement>("[data-resize-frame]");
  if (!frame || !frame.offsetWidth || !frame.offsetHeight) return null;
  camera.updateMatrixWorld(true);
  const rotation = object.quaternion.clone();
  const normal = new THREE.Vector3(0, 0, 1).applyQuaternion(rotation);
  const plane = new THREE.Plane().setFromNormalAndCoplanarPoint(normal, object.position);
  const point = screenPointOnPlane(x, y, bounds, camera, plane);
  if (!point) return null;

  const cornerX = corner.endsWith("e") ? 1 : -1;
  const cornerY = corner.startsWith("n") ? 1 : -1;
  const frameCenter = new THREE.Vector3(
    frame.offsetLeft + frame.offsetWidth / 2 - host.offsetWidth / 2,
    host.offsetHeight / 2 - frame.offsetTop - frame.offsetHeight / 2, 0,
  );
  const anchorPixels = frameCenter.clone().add(new THREE.Vector3(
    -cornerX * frame.offsetWidth / 2, -cornerY * frame.offsetHeight / 2, 0,
  ));
  const startScale = object.scale.x / PIXEL_TO_METERS;
  return {
    id, object, plane, rotation,
    inverseRotation: rotation.clone().invert(),
    startPointer: point,
    startScale,
    anchorPixels,
    anchorWorld: anchorPixels.clone().multiplyScalar(PIXEL_TO_METERS * startScale)
      .applyQuaternion(rotation).add(object.position),
    diagonalPixels: new THREE.Vector3(cornerX * frame.offsetWidth, cornerY * frame.offsetHeight, 0),
  };
}

/** Resize on the window's actual 3D plane, keeping its opposite corner fixed. */
export function applyWindowResizeDelta(session: WindowResizeSession, worldDelta: THREE.Vector3): WindowResizeResult {
  const localDelta = worldDelta.clone().applyQuaternion(session.inverseRotation);
  const increment = localDelta.dot(session.diagonalPixels) /
    (PIXEL_TO_METERS * session.diagonalPixels.lengthSq());
  const scale = THREE.MathUtils.clamp(
    Number.isFinite(increment) ? session.startScale + increment : session.startScale,
    MIN_WINDOW_SCALE, MAX_WINDOW_SCALE,
  );
  session.object.scale.setScalar(PIXEL_TO_METERS * scale);
  session.object.position.copy(session.anchorWorld).sub(
    session.anchorPixels.clone().multiplyScalar(PIXEL_TO_METERS * scale).applyQuaternion(session.rotation),
  );
  session.object.element.querySelectorAll<HTMLElement>("[data-scale-readout]").forEach((label) => {
    label.textContent = `${Math.round(scale * 100)}%`;
  });
  return {
    id: session.id, scale,
    position: { x: session.object.position.x, y: session.object.position.y, z: session.object.position.z },
  };
}

export function updateWindowResize(
  session: WindowResizeSession, x: number, y: number,
  bounds: { left: number; top: number; width: number; height: number },
  camera: THREE.PerspectiveCamera,
) {
  const point = screenPointOnPlane(x, y, bounds, camera, session.plane);
  return point ? applyWindowResizeDelta(session, point.sub(session.startPointer)) : null;
}