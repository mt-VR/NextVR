import * as THREE from "three";
import { CSS3DObject, CSS3DRenderer } from "three/addons/renderers/CSS3DRenderer.js";
import { buildHorizonHome, setEnvironmentTheme, setPassthroughMode } from "./environment";
import { TrackedHandVisual } from "./hand";
import { CameraHandTracker } from "./hand-tracker";
import { DevicePose, screenAngle } from "./orientation";
import { DEFAULT_HAND_OPTIONS, type HandFrame, type HandOptions, type HandTrackingState } from "./tracking-types";
import type { EnvironmentId, PerformanceMode } from "../lib/preferences";
import { StereoUI } from "./stereo";
import {
  applyWindowResizeDelta, startWindowResize, updateWindowResize,
  MIN_WINDOW_SCALE, MAX_WINDOW_SCALE,
  type ResizeCorner, type WindowResizeResult, type WindowResizeSession,
} from "./resize";

export type Vec3 = { x: number; y: number; z: number };

export interface SpatialHandle {
  id: string;
  object: CSS3DObject;
  el: HTMLElement;
  enabled: boolean;
  billboard: boolean;
}

export interface HandDragEvent {
  phase: "start" | "move" | "end";
  id: string;
  position: Vec3;
}

export type HandResizeEvent = WindowResizeResult & { phase: "start" | "move" | "end" };

/** One HTML pixel equals one millimeter in the spatial scene. */
export const CSS_WORLD_SCALE = 0.001;

export class MREngine {
  gl!: THREE.WebGLRenderer;
  css!: CSS3DRenderer;
  handRenderer: THREE.WebGLRenderer | null = null;
  scene = new THREE.Scene();
  cssScene = new THREE.Scene();
  handScene = new THREE.Scene();
  camera = new THREE.PerspectiveCamera(62, 1, 0.05, 80);
  pose = new DevicePose();
  home!: THREE.Group;
  video: HTMLVideoElement | null = null;
  passthrough = false;
  running = false;
  width = 1;
  height = 1;
  handTrackingEnabled = false;
  pointerDragActive = false;
  trackingState: HandTrackingState = { status: "off", count: 0, message: "Hand desativado." };
  handOptions: HandOptions = { ...DEFAULT_HAND_OPTIONS };
  private performanceMode: PerformanceMode = "balanced";
  private frameCount = 0;
  private fpsTime = performance.now();
  private lastRendered = 0;
  private lastClickTime = 0;
  private stereoUI: StereoUI | null = null;
  private stereoCamera = new THREE.StereoCamera();
  private rightVideo: HTMLVideoElement | null = null;
  stereo = false;
  private handPress: {
    target: HTMLElement;
    handId: string;
    startY: number;
    startX: number;
    scrollStart: number;
    scroller: HTMLElement | null;
    moved: boolean;
  } | null = null;
  private tracker: CameraHandTracker | null = null;
  private handRigs = new Map<string, TrackedHandVisual>();
  private nextHandId = 1;
  private handsResetAt = 0;
  private pinchStates = new Map<string, boolean>();
  private streamPromise: Promise<boolean> | null = null;
  private resumeCamera = false;
  private videoMirrored = false;
  private hoverTarget: HTMLElement | null = null;
  private primaryHand: string | null = null;
  private handPointerShown = false;
  private handDrag: {
    id: string;
    handId: string;
    startPalm: THREE.Vector3;
    startPosition: THREE.Vector3;
    scale: number;
    bar: HTMLElement;
  } | null = null;
  private handResize: {
    session: WindowResizeSession;
    handId: string;
    startPalm: THREE.Vector3;
    gain: number;
    handle: HTMLElement;
  } | null = null;

  euler = new THREE.Euler();
  private mouseRotation = new THREE.Quaternion();
  mouseYaw = 0;
  mousePitch = 0;
  lookDragging = false;
  lastLookX = 0;
  lastLookY = 0;
  objects = new Map<string, SpatialHandle>();
  raf = 0;
  lastT = performance.now();
  clock = new THREE.Clock();

  onFrame: ((dt: number, t: number) => void) | null = null;
  onHandDrag: ((event: HandDragEvent) => void) | null = null;
  onHandResize: ((event: HandResizeEvent) => void) | null = null;
  onHandPointer: ((point: { x: number; y: number; progress?: number; pinching?: boolean; fresh?: boolean } | null) => void) | null = null;
  onTrackingState: ((state: HandTrackingState) => void) | null = null;
  onWindowSelect: ((id: string) => void) | null = null;
  onMetrics: ((metrics: { fps: number; hands: number }) => void) | null = null;

  parent!: HTMLElement;
  cssLayer!: HTMLElement;
  glLayer!: HTMLCanvasElement;

  constructor(private orientationEnabled = true) {}

  get hasDevice() {
    return this.pose.hasSensor;
  }

  get handDragging() {
    return this.handDrag !== null || this.handResize !== null || this.handPress !== null;
  }

  mount(parent: HTMLElement) {
    this.parent = parent;
    this.width = parent.clientWidth || window.innerWidth;
    this.height = parent.clientHeight || window.innerHeight;

    this.gl = new THREE.WebGLRenderer({ antialias: false, alpha: false, powerPreference: "low-power" });
    this.gl.setPixelRatio(Math.min(devicePixelRatio, 1.0));
    this.gl.setSize(this.width, this.height);
    // Keep a visible 3D-world fallback even while CSS3D UI is mounting.
    this.gl.setClearColor(0x182331, 1);
    this.gl.shadowMap.enabled = false;
    this.gl.domElement.style.position = "absolute";
    this.gl.domElement.style.inset = "0";
    this.gl.domElement.style.pointerEvents = "none";
    this.gl.domElement.style.zIndex = "2";
    parent.appendChild(this.gl.domElement);
    this.glLayer = this.gl.domElement;

    this.css = new CSS3DRenderer();
    this.css.setSize(this.width, this.height);
    const el = this.css.domElement;
    el.style.position = "absolute";
    el.style.inset = "0";
    el.style.zIndex = "3";
    el.style.pointerEvents = "none";
    el.style.overflow = "hidden";
    // Prevent Android GPU compositing from promoting the transparent CSS3D root to black.
    el.style.background = "transparent";
    el.style.backfaceVisibility = "hidden";
    parent.appendChild(el);
    this.cssLayer = el;

    this.camera.position.set(0, 0, 0);
    this.camera.lookAt(0, 0, -1);

    this.home = buildHorizonHome(this.scene);

    this.bindEvents();
    this.onResize();
    this.recenter();
    this.running = true;
    this.loop();
  }

  unmount() {
    this.running = false;
    cancelAnimationFrame(this.raf);
    this.onHandDrag = null;
    this.onHandResize = null;
    this.onHandPointer = null;
    this.onTrackingState = null;
    this.onWindowSelect = null;
    this.onMetrics = null;
    this.stopPassthrough();
    this.stereoUI?.dispose();
    window.removeEventListener("resize", this.onResize);
    window.removeEventListener("deviceorientation", this.onOrient, true);
    window.removeEventListener("orientationchange", this.onScreenRotate);
    window.screen.orientation?.removeEventListener("change", this.onScreenRotate);
    document.removeEventListener("visibilitychange", this.onVisibility);
    window.removeEventListener("pointerdown", this.onPtrDown);
    window.removeEventListener("pointermove", this.onPtrMove);
    window.removeEventListener("pointerup", this.onPtrUp);
    window.removeEventListener("pointercancel", this.onPtrUp);
    window.removeEventListener("keydown", this.onKey);
    this.handRigs.forEach((rig) => rig.dispose());
    this.handRigs.clear();
    this.scene.traverse((object) => {
      if (object instanceof THREE.Mesh || object instanceof THREE.LineSegments) {
        object.geometry.dispose();
        const materials = Array.isArray(object.material) ? object.material : [object.material];
        materials.forEach((material) => material.dispose());
      }
    });
    this.gl?.dispose();
    this.handRenderer?.dispose();
    this.handRenderer?.domElement.remove();
    this.cssLayer?.remove();
    this.glLayer?.remove();
    this.objects.clear();
  }

  private bindEvents() {
    window.addEventListener("resize", this.onResize);
    if (this.orientationEnabled) window.addEventListener("deviceorientation", this.onOrient, true);
    window.addEventListener("orientationchange", this.onScreenRotate);
    window.screen.orientation?.addEventListener("change", this.onScreenRotate);
    document.addEventListener("visibilitychange", this.onVisibility);
    window.addEventListener("pointerdown", this.onPtrDown);
    window.addEventListener("pointermove", this.onPtrMove);
    window.addEventListener("pointerup", this.onPtrUp);
    window.addEventListener("pointercancel", this.onPtrUp);
    window.addEventListener("keydown", this.onKey);
  }

  onKey = (e: KeyboardEvent) => {
    if (this.hasDevice || e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
    const step = 0.07;
    if (e.key === "ArrowLeft") this.mouseYaw += step;
    if (e.key === "ArrowRight") this.mouseYaw -= step;
    if (e.key === "ArrowUp") this.mousePitch += step;
    if (e.key === "ArrowDown") this.mousePitch -= step;
  };

  onResize = () => {
    if (!this.parent) return;
    this.width = this.parent.clientWidth || window.innerWidth;
    this.height = this.parent.clientHeight || window.innerHeight;
    this.camera.aspect = this.width / (this.height * (this.stereo ? 2 : 1));
    this.camera.updateProjectionMatrix();
    this.gl.setSize(this.width, this.height);
    this.css.setSize(this.stereo ? this.width / 2 : this.width, this.height);
    this.stereoUI?.resize(this.width, this.height);
    this.handRenderer?.setSize(this.width, this.height);
    this.resetHands();
  };

  onScreenRotate = () => {
    this.pose.screenChanged();
    this.onResize();
  };

  onVisibility = () => {
    this.lastT = performance.now();
    if (document.hidden) {
      this.resumeCamera = !!this.video && (this.handTrackingEnabled || this.passthrough);
      this.releaseCamera();
      if (this.passthrough) setPassthroughMode(this.scene, this.home, false);
    } else {
      this.pose.screenChanged();
      if (this.resumeCamera && (this.handTrackingEnabled || this.passthrough)) void this.requestCamera();
      this.resumeCamera = false;
    }
  };

  onOrient = (e: DeviceOrientationEvent) => {
    if (document.hidden) return;
    if (!this.hasDevice) this.pose.rotation.copy(this.camera.quaternion);
    if (this.pose.accept(e, screenAngle(), performance.now())) {
      this.camera.quaternion.copy(this.pose.rotation);
      this.lookDragging = false;
    }
  };

  onPtrDown = (e: PointerEvent) => {
    const t = e.target as HTMLElement;
    const onUi = t.closest?.("[data-spatial], [data-hud], [data-grab]");
    if (!onUi && e.button === 0 && !this.hasDevice) {
      this.lookDragging = true;
      this.lastLookX = e.clientX;
      this.lastLookY = e.clientY;
    }
  };

  onPtrMove = (e: PointerEvent) => {
    if (this.lookDragging) {
      const dx = e.clientX - this.lastLookX;
      const dy = e.clientY - this.lastLookY;
      this.lastLookX = e.clientX;
      this.lastLookY = e.clientY;
      if (!this.hasDevice) {
        this.mouseYaw -= dx * 0.0045;
        this.mousePitch -= dy * 0.0035;
        this.mousePitch = Math.max(-1.2, Math.min(1.2, this.mousePitch));
      }
    }
  };

  onPtrUp = () => {
    this.lookDragging = false;
  };

  recenter() {
    this.finishHandDrag();
    this.finishHandResize();
    this.finishHandPress(false);
    if (this.orientationEnabled && this.pose.hasSensor) {
      this.pose.recenter();
    } else {
      this.mouseYaw = 0;
      this.mousePitch = 0;
      this.pose.recenter();
      this.camera.quaternion.identity();
    }
    this.camera.updateMatrixWorld(true);
  }

  attach(id: string, el: HTMLElement, pos: Vec3, scale = CSS_WORLD_SCALE): SpatialHandle {
    el.style.pointerEvents = "auto";
    el.style.position = "absolute";
    el.style.width = "max-content";
    el.style.backfaceVisibility = "hidden";
    el.style.webkitBackfaceVisibility = "hidden";
    el.style.transformStyle = "preserve-3d";
    el.style.willChange = "transform";
    el.dataset.spatial = id;
    const obj = new CSS3DObject(el);
    obj.position.set(pos.x, pos.y, pos.z);
    obj.scale.setScalar(scale);
    obj.quaternion.copy(this.camera.quaternion);
    this.cssScene.add(obj);
    // Every spatial object receives a fixed pose at placement time. The render loop never billboards it.
    const h = { id, object: obj, el, enabled: true, billboard: false };
    this.objects.set(id, h);
    return h;
  }

  detach(id: string) {
    if (this.handDrag?.id === id) this.finishHandDrag();
    if (this.handResize?.session.id === id) this.finishHandResize();
    if (this.handPress?.target.closest<HTMLElement>("[data-win]")?.dataset.win === id) this.finishHandPress(false);
    const h = this.objects.get(id);
    if (!h) return;
    this.cssScene.remove(h.object);
    this.objects.delete(id);
  }

  setPose(id: string, pos: Vec3, lookAtCamera = false) {
    const h = this.objects.get(id);
    if (!h) return;
    h.object.position.set(pos.x, pos.y, pos.z);
    if (lookAtCamera) {
      h.object.quaternion.copy(this.camera.quaternion);
    }
  }

  setRotation(id: string, rotation: [number, number, number, number]) {
    const handle = this.objects.get(id);
    if (!handle) return;
    handle.object.quaternion.fromArray(rotation);
  }

  setBillboard(id: string, enabled: boolean) {
    const handle = this.objects.get(id);
    if (handle) handle.billboard = enabled;
  }

  setStereo(enabled: boolean) {
    if (enabled === this.stereo) return;
    this.stereo = enabled;
    if (enabled) this.stereoUI = new StereoUI(this.parent);
    else { this.stereoUI?.dispose(); this.stereoUI = null; }
    this.cssLayer.style.width = enabled ? "50%" : "100%";
    this.syncStereoVideo();
    this.onResize();
  }

  private syncStereoVideo() {
    this.rightVideo?.pause(); this.rightVideo?.remove(); this.rightVideo = null;
    const source = this.video;
    if (!source) return;
    source.style.width = this.stereo ? "50%" : "100%";
    if (this.stereo) {
      const video = document.createElement("video");
      video.muted = true; video.autoplay = true; video.playsInline = true;
      video.srcObject = source.srcObject;
      Object.assign(video.style, { position: "absolute", left: "50%", top: "0", width: "50%", height: "100%", objectFit: "cover", zIndex: "0", pointerEvents: "none", opacity: this.passthrough ? "1" : "0", transform: source.style.transform });
      this.parent.appendChild(video); this.rightVideo = video; void video.play().catch(() => {});
    }
  }

  private interactionBounds() {
    const bounds = this.parent.getBoundingClientRect();
    return { left: bounds.left, top: bounds.top, width: this.stereo ? bounds.width / 2 : bounds.width, height: bounds.height };
  }

  configureHands(options: HandOptions) {
    this.handOptions = { ...options };
    this.handRigs.forEach((rig) => rig.configure(options));
    this.tracker?.configure(options);
  }

  setGyroSensitivity(value: number) {
    this.pose.setSensitivity(value);
  }

  setPerformance(mode: PerformanceMode) {
    this.performanceMode = mode;
    const ratio = Math.min(devicePixelRatio, mode === "quality" ? 1.25 : mode === "battery" ? 0.75 : 1.0);
    this.gl.setPixelRatio(ratio);
    this.handRenderer?.setPixelRatio(ratio);
    this.gl.setSize(this.width, this.height);
    this.handRenderer?.setSize(this.width, this.height);
  }

  enableOrientation() {
    void requestOrientationPermission().then((allowed) => {
      if (!allowed || !this.running) return;
      this.orientationEnabled = true;
      window.removeEventListener("deviceorientation", this.onOrient, true);
      window.addEventListener("deviceorientation", this.onOrient, true);
      this.pose.screenChanged();
    });
  }

  focusWindow(id: string) {
    const object = this.objects.get(id)?.object;
    if (!object) return;
    const rotation = new THREE.Quaternion().setFromRotationMatrix(new THREE.Matrix4().lookAt(this.camera.position, object.position, new THREE.Vector3(0, 1, 0)));
    this.pose.setView(rotation);
    this.camera.quaternion.copy(rotation);
    if (!this.hasDevice) {
      this.euler.setFromQuaternion(rotation, "YXZ");
      this.mousePitch = this.euler.x;
      this.mouseYaw = this.euler.y;
    }
  }

  setScale(id: string, scale: number) {
    const handle = this.objects.get(id);
    if (handle) handle.object.scale.setScalar(CSS_WORLD_SCALE * THREE.MathUtils.clamp(scale, MIN_WINDOW_SCALE, MAX_WINDOW_SCALE));
  }

  setVisible(id: string, visible: boolean) {
    const handle = this.objects.get(id);
    if (!handle) return;
    if (!visible) {
      if (this.handDrag?.id === id) this.finishHandDrag();
      if (this.handResize?.session.id === id) this.finishHandResize();
    }
    handle.object.visible = visible;
    handle.enabled = visible;
    handle.el.style.pointerEvents = visible ? "auto" : "none";
  }

  beginResize(id: string, corner: ResizeCorner, x: number, y: number) {
    const handle = this.objects.get(id);
    if (!handle || !handle.object.visible) return null;
    return startWindowResize(id, handle.object, handle.el, corner, x, y, this.interactionBounds(), this.camera);
  }

  updateResize(session: WindowResizeSession, x: number, y: number) {
    return updateWindowResize(session, x, y, this.interactionBounds(), this.camera);
  }

  /** Pixel drag → meters along the camera plane (world-locked content). */
  dragDelta(dxPx: number, dyPx: number) {
    const right = new THREE.Vector3(1, 0, 0).applyQuaternion(this.camera.quaternion);
    const up = new THREE.Vector3(0, 1, 0).applyQuaternion(this.camera.quaternion);
    const k = 0.00105;
    return {
      x: right.x * dxPx * k + up.x * -dyPx * k,
      y: right.y * dxPx * k + up.y * -dyPx * k,
      z: right.z * dxPx * k + up.z * -dyPx * k,
    };
  }

  pushDepth(dzPx: number) {
    const fwd = new THREE.Vector3(0, 0, -1).applyQuaternion(this.camera.quaternion);
    const k = 0.0014;
    return { x: fwd.x * dzPx * k, y: fwd.y * dzPx * k, z: fwd.z * dzPx * k };
  }

  /** Spawn point in front of the user, in meters. */
  frontPosition(distance = 0.72, y = -0.02, x = 0): Vec3 {
    const dir = new THREE.Vector3(0, 0, -1).applyQuaternion(this.camera.quaternion);
    const up = new THREE.Vector3(0, 1, 0).applyQuaternion(this.camera.quaternion);
    const rt = new THREE.Vector3(1, 0, 0).applyQuaternion(this.camera.quaternion);
    const p = dir.multiplyScalar(distance).add(up.multiplyScalar(y)).add(rt.multiplyScalar(x));
    return { x: p.x, y: p.y, z: p.z };
  }

  attachStream(stream: MediaStream) {
    if (this.video?.srcObject === stream) return;
    this.releaseCamera();
    const video = document.createElement("video");
    video.setAttribute("playsinline", "true");
    video.setAttribute("aria-hidden", "true");
    video.muted = true;
    video.autoplay = true;
    video.srcObject = stream;
    video.style.position = "absolute";
    video.style.inset = "0";
    video.style.width = "100%";
    video.style.height = "100%";
    video.style.objectFit = "cover";
    video.style.zIndex = "0";
    video.style.pointerEvents = "none";
    video.style.opacity = this.passthrough ? "1" : "0";
    this.videoMirrored = stream.getVideoTracks()[0]?.getSettings().facingMode === "user";
    video.style.transform = this.videoMirrored ? "scaleX(-1)" : "none";
    this.parent.insertBefore(video, this.parent.firstChild);
    this.video = video;
    this.syncStereoVideo();
    void video.play().catch(() => {
      if (this.running && this.video === video) this.noteCameraFailure("Toque em Tentar novamente para iniciar a c\u00e2mera.");
    });
    stream.getVideoTracks()[0]?.addEventListener("ended", () => {
      if (this.running && this.video === video) {
        this.releaseCamera();
        this.noteCameraFailure("A c\u00e2mera foi interrompida. Ative o Hand novamente.");
        setPassthroughMode(this.scene, this.home, false);
      }
    }, { once: true });
    if (this.handTrackingEnabled) this.startHandTracker();
  }

  noteCameraFailure(message = "Permita a c\u00e2mera para rastrear sua m\u00e3o. O toque n\u00e3o cria uma m\u00e3o virtual.") {
    this.tracker?.dispose();
    this.tracker = null;
    this.resetHands();
    this.publishTrackingState({ status: "camera-required", count: 0, message });
  }

  requestCamera(): Promise<boolean> {
    if (this.video && (this.video.srcObject as MediaStream)?.active) return Promise.resolve(true);
    if (this.streamPromise) return this.streamPromise;
    this.streamPromise = (async () => {
      try {
        if (!navigator.mediaDevices?.getUserMedia) {
          this.noteCameraFailure("A c\u00e2mera requer HTTPS ou localhost e um navegador compat\u00edvel.");
          return false;
        }
        const stream = await navigator.mediaDevices.getUserMedia({
          video: {
            facingMode: { ideal: "environment" },
            width: { ideal: 1280 }, height: { ideal: 720 },
            frameRate: { ideal: 30, max: 30 },
          },
          audio: false,
        });
        if (!this.running || document.hidden || (!this.handTrackingEnabled && !this.passthrough)) {
          stream.getTracks().forEach((track) => track.stop());
          return false;
        }
        this.attachStream(stream);
        if (this.passthrough) setPassthroughMode(this.scene, this.home, true);
        return true;
      } catch {
        if (this.running) this.noteCameraFailure();
        return false;
      }
    })().finally(() => { this.streamPromise = null; });
    return this.streamPromise;
  }

  async startPassthrough() {
    this.passthrough = true;
    const ok = await this.requestCamera();
    if (!this.running) return false;
    if (!ok) this.passthrough = false;
    if (this.video) this.video.style.opacity = this.passthrough ? "1" : "0";
    if (this.rightVideo) this.rightVideo.style.opacity = this.passthrough ? "1" : "0";
    this.gl.setClearAlpha(ok && this.passthrough ? 0 : 1);
    setPassthroughMode(this.scene, this.home, ok && this.passthrough);
    return ok;
  }

  private releaseCamera() {
    this.rightVideo?.pause(); this.rightVideo?.remove(); this.rightVideo = null;
    this.tracker?.dispose();
    this.tracker = null;
    this.resetHands();
    if (!this.video) return;
    const video = this.video;
    this.video = null;
    const stream = video.srcObject as MediaStream | null;
    stream?.getTracks().forEach((track) => track.stop());
    video.pause();
    video.srcObject = null;
    video.remove();
  }

  stopPassthrough() {
    this.releaseCamera();
    this.passthrough = false;
    if (this.home) setPassthroughMode(this.scene, this.home, false);
  }

  setEnvironment(mode: EnvironmentId) {
    this.passthrough = mode === "passthrough";
    if (mode === "passthrough") {
      if (this.video) {
        this.video.style.opacity = "1";
        if (this.rightVideo) this.rightVideo.style.opacity = "1";
        setPassthroughMode(this.scene, this.home, true);
        this.gl.setClearAlpha(0);
      }
    } else {
      // Keep decoding the same video for Hand even when the 3D environment hides it.
      if (this.video) this.video.style.opacity = "0";
      if (this.rightVideo) this.rightVideo.style.opacity = "0";
      setEnvironmentTheme(this.scene, this.home, mode);
      this.gl.setClearAlpha(1);
      if (!this.handTrackingEnabled) this.releaseCamera();
    }
  }

  async setHandTracking(enabled: boolean, askForCamera = false) {
    this.handTrackingEnabled = enabled;
    if (!enabled) {
      this.tracker?.dispose();
      this.tracker = null;
      this.resetHands();
      this.handRigs.forEach((rig) => rig.dispose());
      this.handRigs.clear();
      this.pinchStates.clear();
      this.handRenderer?.dispose();
      this.handRenderer?.domElement.remove();
      this.handRenderer = null;
      this.publishTrackingState({ status: "off", count: 0, message: "Hand desativado." });
      if (!this.passthrough) this.releaseCamera();
      return;
    }
    if (!this.video && askForCamera) await this.requestCamera();
    else if (!this.video && this.streamPromise) return;
    if (!this.running || !this.handTrackingEnabled) return;
    if (this.video) { this.ensureHandLayer(); this.startHandTracker(); }
    else this.noteCameraFailure();
  }

  async retryHandTracking() {
    this.tracker?.dispose();
    this.tracker = null;
    this.resetHands();
    if (this.video) {
      try { await this.video.play(); } catch { this.releaseCamera(); }
    }
    await this.setHandTracking(true, true);
  }

  private startHandTracker() {
    const video = this.video;
    if (!video || this.tracker || !this.handTrackingEnabled) return;
    const tracker = new CameraHandTracker(
      video,
      (frame) => {
        if (this.running && this.tracker === tracker) this.applyHandFrame(frame);
      },
      (state) => {
        if (this.running && this.tracker === tracker) this.publishTrackingState(state);
      },
    );
    this.tracker = tracker;
    tracker.configure(this.handOptions);
    tracker.start();
  }

  private ensureHandLayer() {
    if (this.handRenderer) return;
    const renderer = new THREE.WebGLRenderer({ antialias: false, alpha: true, powerPreference: "low-power" });
    renderer.setPixelRatio(Math.min(devicePixelRatio, this.performanceMode === "quality" ? 1.25 : this.performanceMode === "battery" ? 0.75 : 1.0));
    renderer.setSize(this.width, this.height);
    renderer.setClearColor(0x000000, 0);
    Object.assign(renderer.domElement.style, { position: "absolute", inset: "0", zIndex: "6", pointerEvents: "none" });
    renderer.domElement.setAttribute("aria-hidden", "true");
    this.parent.appendChild(renderer.domElement);
    this.handRenderer = renderer;
  }

  private publishTrackingState(state: HandTrackingState) {
    if (state.status === this.trackingState.status && state.count === this.trackingState.count &&
      state.message === this.trackingState.message) return;
    this.trackingState = state;
    this.onTrackingState?.(state);
  }

  private applyHandFrame(frame: HandFrame) {
    const video = this.video;
    if (!video || !this.handTrackingEnabled || document.hidden || !video.videoWidth || frame.timestamp < this.handsResetAt || performance.now() - frame.timestamp > 350) return;
    const visible = new Set<string>();
    const assigned = new Set<string>();
    const now = performance.now();
    frame.hands.filter((hand) => hand.landmarks.length === 21).slice(0, 2).forEach((hand) => {
      const palm = [0, 5, 9, 13, 17].reduce((sum, i) => ({
        x: sum.x + hand.landmarks[i].x / 5,
        y: sum.y + hand.landmarks[i].y / 5,
      }), { x: 0, y: 0 });
      const available = [...this.handRigs.values()].filter((rig) => !assigned.has(rig.id));
      // Match the whole palm across frames; handedness labels may flip for an inverted hand.
      let rig: TrackedHandVisual | undefined = available.filter((candidate) => now - candidate.lastSeen < this.handOptions.holdMs)
        .sort((a, b) => Math.hypot(a.imagePalm.x - palm.x, a.imagePalm.y - palm.y) -
          Math.hypot(b.imagePalm.x - palm.x, b.imagePalm.y - palm.y))[0];
      if (rig && Math.hypot(rig.imagePalm.x - palm.x, rig.imagePalm.y - palm.y) > 0.32) {
        rig = undefined;
      }
      if (!rig) rig = available.find((candidate) => !candidate.root.visible);
      if (!rig && this.handRigs.size >= 2) rig = available[0];
      if (!rig) {
        rig = new TrackedHandVisual(`hand-${this.nextHandId++}`);
        rig.configure(this.handOptions);
        this.handRigs.set(rig.id, rig);
        this.handScene.add(rig.root);
      }
      assigned.add(rig.id);
      rig.update(hand, {
        width: this.stereo ? this.width / 2 : this.width, height: this.height,
        videoWidth: video.videoWidth, videoHeight: video.videoHeight,
        mirrored: this.videoMirrored,
      }, this.camera, frame.timestamp);
      if (rig.root.visible) visible.add(rig.id);
    });
    // Keep the last coherent pose through brief detector misses; disable new pinches while stale.
    this.handRigs.forEach((rig, id) => {
      if (!visible.has(id) && now - rig.lastSeen > this.handOptions.holdMs) rig.hide();
    });
  }

  private resetHands() {
    this.handsResetAt = performance.now();
    this.finishHandDrag();
    this.finishHandResize();
    this.finishHandPress(false);
    this.handRigs.forEach((rig) => rig.hide());
    this.pinchStates.clear();
    this.primaryHand = null;
    this.setHover(null);
    if (this.handPointerShown) this.onHandPointer?.(null);
    this.handPointerShown = false;
  }

  private setHover(target: HTMLElement | null) {
    if (target === this.hoverTarget) return;
    this.hoverTarget?.classList.remove("is-gaze");
    this.hoverTarget = target;
    target?.classList.add("is-gaze");
  }

  private pickHandTarget(pointer: { x: number; y: number }): HTMLElement | null {
    if (pointer.x < 0 || pointer.y < 0 || pointer.x > this.width || pointer.y > this.height) return null;
    const rect = this.parent.getBoundingClientRect();
    const x = pointer.x + rect.left;
    const y = pointer.y + rect.top;
    const rawHit = document.elementFromPoint(x, y);
    const hit = this.stereoUI ? this.stereoUI.resolve(rawHit) : rawHit as HTMLElement | null;
    const exact = hit?.closest<HTMLElement>("[data-resize], [data-grab], button, a, input, textarea, [data-scroll], [data-window]");
    if (exact) return exact;
    if (hit?.closest("[data-hud]")) return null;

    let nearest: HTMLElement | null = null;
    let distance = Infinity;
    this.objects.forEach(({ el, object }) => {
      if (!object.visible) return;
      const viewPosition = object.position.clone().applyMatrix4(this.camera.matrixWorldInverse);
      if (viewPosition.z >= 0) return;
      el.querySelectorAll<HTMLElement>("[data-grab], [data-resize]").forEach((bar) => {
        const bounds = bar.getBoundingClientRect();
        if (!bounds.width || x < bounds.left - 24 || x > bounds.right + 24 || y < bounds.top - 24 || y > bounds.bottom + 24) return;
        const d = Math.hypot(x - (bounds.left + bounds.right) / 2, y - (bounds.top + bounds.bottom) / 2);
        if (d < distance) { nearest = bar; distance = d; }
      });
    });
    return nearest;
  }

  private updateHandInteraction(time: number) {
    this.handRigs.forEach((rig) => {
      if (rig.root.visible) rig.refresh(this.camera);
    });
    const visible = [...this.handRigs.values()].filter((rig) => rig.root.visible);
    if (this.handTrackingEnabled && this.video && this.tracker && this.trackingState.status !== "loading" && this.trackingState.status !== "error") {
      this.publishTrackingState({
        status: visible.length ? "tracking" : "ready", count: visible.length,
        message: visible.length ? "Hand ativo. Pin\u00e7a para selecionar; segure e deslize para rolar." : "Mostre sua m\u00e3o para a c\u00e2mera.",
      });
    }
    if (this.handPress) {
      const press = this.handPress;
      const rig = this.handRigs.get(press.handId);
      if (!rig?.root.visible || time - rig.lastSeen > 170) this.finishHandPress(false);
      else if (!rig.pinching) this.finishHandPress(rig.canInteract);
      else {
        const dy = rig.pointer.y - press.startY;
        if (Math.hypot(dy, rig.pointer.x - press.startX) > 18) press.moved = true;
        if (press.moved && press.scroller) {
          const projected = press.scroller.getBoundingClientRect().height / Math.max(1, press.scroller.clientHeight);
          press.scroller.scrollTop = press.scrollStart - dy / Math.max(0.3, projected);
        }
      }
    }
    const activeResize = this.handResize;
    if (activeResize) {
      const rig = this.handRigs.get(activeResize.handId);
      if (!rig?.root.visible || !rig.pinching || !this.objects.get(activeResize.session.id)?.object.visible) {
        this.finishHandResize();
      } else {
        const result = applyWindowResizeDelta(activeResize.session,
          rig.palmWorld.clone().sub(activeResize.startPalm).multiplyScalar(activeResize.gain));
        this.onHandResize?.({ ...result, phase: "move" });
      }
    }
    const activeDrag = this.handDrag;
    if (activeDrag) {
      const rig = this.handRigs.get(activeDrag.handId);
      const handle = this.objects.get(activeDrag.id);
      if (!rig?.root.visible || !rig.pinching || !handle?.object.visible) {
        this.finishHandDrag();
      } else {
        handle.object.position.copy(activeDrag.startPosition).addScaledVector(
          rig.palmWorld.clone().sub(activeDrag.startPalm), activeDrag.scale,
        );
        this.onHandDrag?.({ phase: "move", id: activeDrag.id, position: this.positionOf(handle.object) });
      }
    }

    const rising = visible.find((rig) => rig.canInteract && rig.pinching && !this.pinchStates.get(rig.id));
    const primary = visible.find((rig) => rig.id === (this.handResize?.handId ?? this.handDrag?.handId ?? this.handPress?.handId)) ?? rising ??
      visible.find((rig) => rig.id === this.primaryHand) ?? visible[0];
    if (!primary) {
      this.setHover(null);
      if (this.handPointerShown) this.onHandPointer?.(null);
      this.handPointerShown = false;
      this.primaryHand = null;
      this.pinchStates.clear();
      if (this.trackingState.status === "tracking") {
        this.publishTrackingState({ status: "ready", count: 0, message: "Mostre a m\u00e3o inteira para a c\u00e2mera." });
      }
      return;
    }
    this.primaryHand = primary.id;
    this.handPointerShown = true;
    this.onHandPointer?.({ ...primary.pointer, progress: primary.pinchProgress, pinching: primary.pinching, fresh: primary.canInteract });
    const target = this.handResize?.handle ?? this.handDrag?.bar ?? this.handPress?.target ?? this.pickHandTarget(primary.pointer);
    this.setHover(this.pointerDragActive ? null : target);

    if (rising && !this.handDragging && !this.pointerDragActive && target) {
      const windowId = target.closest<HTMLElement>("[data-win]")?.dataset.win;
      if (windowId) this.onWindowSelect?.(windowId);
      if (target.matches("[data-resize]")) {
        const spatialId = target.closest<HTMLElement>("[data-spatial]")?.dataset.spatial;
        const corner = target.dataset.resize as ResizeCorner;
        const bounds = this.parent.getBoundingClientRect();
        const session = spatialId && this.beginResize(spatialId, corner, primary.pointer.x + bounds.left, primary.pointer.y + bounds.top);
        if (session) {
          this.handResize = {
            session,
            handId: primary.id,
            startPalm: primary.palmWorld.clone(),
            gain: THREE.MathUtils.clamp(session.object.position.distanceTo(this.camera.position) /
              Math.max(primary.palmWorld.distanceTo(this.camera.position), 0.2), 0.5, 3),
            handle: target,
          };
          target.classList.add("is-pinch");
          this.onHandResize?.({
            phase: "start", id: session.id, scale: session.startScale,
            position: this.positionOf(session.object),
          });
        }
      } else if (target.matches("[data-grab]")) {
        const spatialId = target.closest<HTMLElement>("[data-spatial]")?.dataset.spatial;
        const handle = spatialId ? this.objects.get(spatialId) : undefined;
        if (handle) {
          this.handDrag = {
            id: handle.id,
            handId: primary.id,
            startPalm: primary.palmWorld.clone(),
            startPosition: handle.object.position.clone(),
            scale: THREE.MathUtils.clamp(
              handle.object.position.distanceTo(this.camera.position) /
              Math.max(primary.palmWorld.distanceTo(this.camera.position), 0.2), 0.5, 3,
            ),
            bar: target,
          };
          target.classList.add("is-pinch");
          this.onHandDrag?.({ phase: "start", id: handle.id, position: this.positionOf(handle.object) });
        }
      } else if (target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement) {
        target.focus();
      } else {
        if (!(target instanceof HTMLButtonElement && target.disabled)) {
          let scroller: HTMLElement | null = target.closest<HTMLElement>("[data-scroll]");
          while (scroller && scroller.scrollHeight <= scroller.clientHeight + 2) {
            scroller = scroller.parentElement?.closest<HTMLElement>("[data-scroll]") ?? null;
          }
          this.handPress = {
            target, handId: primary.id, startY: primary.pointer.y, startX: primary.pointer.x,
            scroller, scrollStart: scroller?.scrollTop ?? 0, moved: false,
          };
          target.classList.add("is-pressed");
        }
      }
    }
    this.handRigs.forEach((rig, id) => this.pinchStates.set(id, rig.root.visible && rig.pinching));
  }

  private finishHandPress(activate: boolean) {
    const press = this.handPress;
    if (!press) return;
    this.handPress = null;
    press.target.classList.remove("is-pressed");
    if (activate && !press.moved && press.target.isConnected && performance.now() - this.lastClickTime > 180) {
      this.lastClickTime = performance.now();
      press.target.click();
    }
  }

  private positionOf(object: CSS3DObject): Vec3 {
    return { x: object.position.x, y: object.position.y, z: object.position.z };
  }

  private finishHandDrag() {
    const drag = this.handDrag;
    if (!drag) return;
    this.handDrag = null;
    drag.bar.classList.remove("is-pinch");
    const handle = this.objects.get(drag.id);
    if (handle) this.onHandDrag?.({ phase: "end", id: drag.id, position: this.positionOf(handle.object) });
  }

  private finishHandResize() {
    const resize = this.handResize;
    if (!resize) return;
    this.handResize = null;
    resize.handle.classList.remove("is-pinch");
    this.onHandResize?.({
      phase: "end", id: resize.session.id,
      scale: resize.session.object.scale.x / CSS_WORLD_SCALE,
      position: this.positionOf(resize.session.object),
    });
  }

  private applyOrientation(dt: number) {
    if (this.hasDevice) {
      this.camera.quaternion.copy(this.pose.rotation);
    } else {
      this.euler.set(this.mousePitch, this.mouseYaw, 0, "YXZ");
      this.mouseRotation.setFromEuler(this.euler);
      this.camera.quaternion.slerp(this.mouseRotation, 1 - Math.exp(-18 * dt));
      this.pose.rotation.copy(this.camera.quaternion);
    }
    this.camera.updateMatrixWorld(true);
  }

  private loop = () => {
    if (!this.running) return;
    this.raf = requestAnimationFrame(this.loop);
    const t = performance.now();
    if (document.hidden) { this.lastT = t; return; }
    const frameLimit = this.performanceMode === "battery" ? 24 : this.performanceMode === "balanced" ? 45 : 60;
    if (t - this.lastRendered < 1000 / frameLimit - 1) return;
    this.lastRendered = t;
    const dt = Math.min((t - this.lastT) / 1000, 0.05);
    this.lastT = t;

    this.applyOrientation(dt);
    this.tracker?.tick(t);
    // Windows keep the quaternion assigned when they were placed. Camera motion never rewrites it.
    this.updateHandInteraction(t);

    this.onFrame?.(dt, t);
    if (this.stereo) {
      this.stereoCamera.update(this.camera);
      const cameras = [this.stereoCamera.cameraL, this.stereoCamera.cameraR];
      for (const renderer of [this.gl, ...(this.handRenderer ? [this.handRenderer] : [])]) {
        renderer.setScissorTest(true);
        cameras.forEach((camera, eye) => {
          renderer.setViewport(eye * this.width / 2, 0, this.width / 2, this.height);
          renderer.setScissor(eye * this.width / 2, 0, this.width / 2, this.height);
          renderer.render(renderer === this.gl ? this.scene : this.handScene, camera);
        });
        renderer.setScissorTest(false);
      }
      this.css.render(this.cssScene, cameras[0]);
      this.stereoUI?.render(this.objects, cameras[1], t);
    } else {
      this.gl.setViewport(0, 0, this.width, this.height);
      this.handRenderer?.setViewport(0, 0, this.width, this.height);
      this.gl.render(this.scene, this.camera);
      this.css.render(this.cssScene, this.camera);
      this.handRenderer?.render(this.handScene, this.camera);
    }
    this.frameCount++;
    if (t - this.fpsTime >= 1200) {
      this.onMetrics?.({ fps: Math.round(this.frameCount * 1000 / (t - this.fpsTime)), hands: [...this.handRigs.values()].filter((rig) => rig.root.visible).length });
      this.frameCount = 0;
      this.fpsTime = t;
    }
  };
}

export async function requestOrientationPermission(): Promise<boolean> {
  if (typeof DeviceOrientationEvent === "undefined" || !window.isSecureContext) return false;
  const DOE = DeviceOrientationEvent as unknown as {
    requestPermission?: () => Promise<string>;
  };
  if (typeof DOE.requestPermission === "function") {
    try {
      const res = await DOE.requestPermission();
      return res === "granted";
    } catch {
      return false;
    }
  }
  return true;
}
