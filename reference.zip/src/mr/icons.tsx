import type { ReactNode } from "react";

const s = {
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 1.8,
  strokeLinecap: "round" as const,
  strokeLinejoin: "round" as const,
};

export function Icon({ name, className = "w-5 h-5" }: { name: string; className?: string }) {
  const n = name.toLowerCase();
  let body: ReactNode = <circle cx="12" cy="12" r="7" />;

  if (n === "back") body = <path d="M15 5l-7 7 7 7M8 12h13" />;
  else if (n === "chevron") body = <path d="M9 5l7 7-7 7" />;
  else if (n === "check") body = <path d="M5 12l4 4 10-10" />;
  else if (n === "heart") body = <path d="M12 20L4.8 13A5 5 0 0 1 12 6a5 5 0 0 1 7.2 7z" />;
  else if (n === "bolt") body = <path d="M14 2L4 14h7l-1 8 10-12h-7z" />;
  else if (n === "keyboard") body = <><rect x="2" y="5" width="20" height="14" rx="3" /><path d="M6 9h.5M10 9h.5M14 9h.5M18 9h.5M6 12h.5M10 12h.5M14 12h.5M18 12h.5M7 16h10" /></>;
  else if (n === "shift") body = <path d="M12 4l8 8h-5v8H9v-8H4z" />;
  else if (n === "backspace") body = <><path d="M8 5h13v14H8l-6-7zM12 9l5 6M17 9l-5 6" /></>;
  else if (n === "enter") body = <path d="M20 5v9H5M9 10l-4 4 4 4" />;
  else if (n === "world") body = <><circle cx="12" cy="12" r="5" /><ellipse cx="12" cy="12" rx="11" ry="4" transform="rotate(-30 12 12)" /></>;
  else if (n === "arc") body = <><path d="M3 17C4 5 20 5 21 17M7 16v-4M12 13V8M17 16v-4" /></>;
  else if (n === "play")
    body = <polygon points="9,7 19,12 9,17" fill="currentColor" stroke="none" />;
  else if (n === "film")
    body = (
      <>
        <rect x="4" y="6" width="16" height="12" rx="2" />
        <path d="M9 6v12M15 6v12" />
      </>
    );
  else if (n === "globe")
    body = (
      <>
        <circle cx="12" cy="12" r="8" />
        <path d="M3 12h18M12 4a14 14 0 0 1 0 16M12 4a14 14 0 0 0 0 16" />
      </>
    );
  else if (n === "pause") body = <><path d="M8 6v12M16 6v12" strokeWidth="3.5" /></>;
  else if (n === "external") body = <><path d="M14 4h6v6M20 4L10 14M10 5H5v14h14v-5" /></>;
  else if (n === "expand") body = <path d="M4 9V4h5M15 4h5v5M20 15v5h-5M9 20H4v-5" />;
  else if (n === "restore") body = <><path d="M8 3h13v13M3 8h13v13H3z" /></>;
  else if (n === "resize") body = <path d="M5 19L19 5M12 5h7v7M5 12v7h7" />;
  else if (n === "rewind") body = <><path d="M11 5l-7 7 7 7M20 5l-7 7 7 7" /></>;
  else if (n === "forward") body = <><path d="M4 5l7 7-7 7M13 5l7 7-7 7" /></>;
  else if (n === "volume" || n === "muted") body = <>
    <path d="M11 5L6 9H3v6h3l5 4z" />
    {n === "volume" ? <><path d="M15 8a6 6 0 0 1 0 8M18 5a10 10 0 0 1 0 14" /></> : <path d="M16 9l5 6M21 9l-5 6" />}
  </>;
  else if (n === "clipboard") body = <><rect x="5" y="5" width="14" height="16" rx="2" /><rect x="9" y="3" width="6" height="4" rx="1" /><path d="M9 12h6M9 16h4" /></>;
  else if (n === "link") body = <><path d="M10 7l2-2a5 5 0 0 1 7 7l-2 2M14 17l-2 2a5 5 0 0 1-7-7l2-2M8 16l8-8" /></>;
  else if (n === "history") body = <><path d="M4 5v5h5M4 10a8 8 0 1 1 1 8M12 8v5l3 2" /></>;
  else if (n === "square") body = <rect x="6" y="6" width="12" height="12" rx="2" />;
  else if (n === "phone")
    body = (
      <>
        <path d="M8 4h8a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1H8a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1z" />
        <circle cx="12" cy="17" r="0.8" fill="currentColor" />
      </>
    );
  else if (n === "music")
    body = (
      <>
        <path d="M9 18V6l10-2v12" />
        <circle cx="7" cy="18" r="2.2" />
        <circle cx="17" cy="16" r="2.2" />
      </>
    );
  else if (n === "diamond") body = <path d="M12 4l8 8-8 8-8-8z" />;
  else if (n === "spark")
    body = (
      <path d="M12 3l1.4 6.2L20 12l-6.6 2.8L12 21l-1.4-6.2L4 12l6.6-2.8z" />
    );
  else if (n === "people")
    body = (
      <>
        <circle cx="9" cy="8" r="3" />
        <path d="M3 19c0-3 2.5-5 6-5s6 2 6 5" />
        <circle cx="17" cy="9" r="2.4" />
        <path d="M16 19c.4-2 1.6-3.4 3.5-4" />
      </>
    );
  else if (n === "person")
    body = (
      <>
        <circle cx="12" cy="8" r="3.2" />
        <path d="M5 20c0-3.6 3-6 7-6s7 2.4 7 6" />
      </>
    );
  else if (n === "feed")
    body = (
      <>
        <rect x="5" y="5" width="14" height="14" rx="2" />
        <path d="M8 9h8M8 12h8M8 15h5" />
      </>
    );
  else if (n === "store")
    body = (
      <>
        <path d="M4 9h16l-1 10H5L4 9z" />
        <path d="M8 9V7a4 4 0 0 1 8 0v2" />
      </>
    );
  else if (n === "gear")
    body = (
      <>
        <circle cx="12" cy="12" r="3" />
        <path d="M12 3v2M12 19v2M4.2 7.1l1.7 1M18.1 16l1.7 1M4.2 16.9l1.7-1M18.1 8l1.7-1M3 12h2M19 12h2" />
      </>
    );
  else if (n === "grid")
    body = (
      <>
        <rect x="4" y="4" width="6" height="6" rx="1" />
        <rect x="14" y="4" width="6" height="6" rx="1" />
        <rect x="4" y="14" width="6" height="6" rx="1" />
        <rect x="14" y="14" width="6" height="6" rx="1" />
      </>
    );
  else if (n === "photo")
    body = (
      <>
        <rect x="4" y="6" width="16" height="12" rx="2" />
        <circle cx="9" cy="10" r="1.4" />
        <path d="M4 16l5-4 4 3 3-2 4 3" />
      </>
    );
  else if (n === "face")
    body = (
      <>
        <circle cx="12" cy="12" r="8" />
        <circle cx="9" cy="10" r="0.8" fill="currentColor" />
        <circle cx="15" cy="10" r="0.8" fill="currentColor" />
        <path d="M8.5 14.5c1.2 1.4 5.8 1.4 7 0" />
      </>
    );
  else if (n === "display")
    body = (
      <>
        <rect x="4" y="5" width="16" height="12" rx="2" />
        <path d="M9 21h6M12 17v4" />
      </>
    );
  else if (n === "wifi")
    body = (
      <>
        <path d="M5 12a9 9 0 0 1 14 0" />
        <path d="M8 15a5.5 5.5 0 0 1 8 0" />
        <circle cx="12" cy="18" r="1.1" fill="currentColor" />
      </>
    );
  else if (n === "pencil")
    body = (
      <>
        <path d="M4 20l4.5-1.2L19 8.3 15.7 5 5.2 15.5z" />
        <path d="M13.5 6.8l3.7 3.7" />
      </>
    );
  else if (n === "storage")
    body = (
      <>
        <path d="M5 7h14v3H5zM5 12h14v3H5zM5 17h14v3H5z" />
        <circle cx="8" cy="8.5" r="0.7" fill="currentColor" />
        <circle cx="8" cy="13.5" r="0.7" fill="currentColor" />
      </>
    );
  else if (n === "hand")
    body = (
      <>
        <path d="M8 11V6.5a1.5 1.5 0 0 1 3 0V11" />
        <path d="M11 10V5.5a1.5 1.5 0 0 1 3 0V11" />
        <path d="M14 11V7a1.5 1.5 0 0 1 3 0v7c0 3-2 5-5 5h-1c-3 0-6-2.2-6-5.5V12" />
      </>
    );
  else if (n === "a11y")
    body = (
      <>
        <circle cx="12" cy="6" r="2" />
        <path d="M6 10h12M12 10v5M9 21l3-6 3 6" />
      </>
    );
  else if (n === "shield") body = <path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z" />;
  else if (n === "lock")
    body = (
      <>
        <rect x="6" y="11" width="12" height="9" rx="2" />
        <path d="M9 11V8a3 3 0 0 1 6 0v3" />
      </>
    );
  else if (n === "tools")
    body = (
      <>
        <path d="M14.5 4.5l5 5-8 8-5-2 8-11z" />
        <path d="M5 19l4-4" />
      </>
    );
  else if (n === "home") body = <path d="M4 11l8-7 8 7v9H4z" />;
  else if (n === "bell")
    body = (
      <>
        <path d="M6 16h12l-1.2-2.2a6.5 6.5 0 0 1-.8-3.3V9a5 5 0 0 0-10 0v1.5c0 1.2-.3 2.3-.8 3.3z" />
        <path d="M10 16a2 2 0 0 0 4 0" />
      </>
    );
  else if (n === "car")
    body = (
      <>
        <path d="M4 14h16v4H4z" />
        <path d="M6 14l2-5h8l2 5" />
        <circle cx="8" cy="18" r="1.2" />
        <circle cx="16" cy="18" r="1.2" />
      </>
    );
  else if (n === "plus") body = <path d="M12 6v12M6 12h12" />;
  else if (n === "search")
    body = (
      <>
        <circle cx="11" cy="11" r="6" />
        <path d="M16 16l4 4" />
      </>
    );
  else if (n === "close") body = <path d="M6 6l12 12M18 6L6 18" />;
  else if (n === "minus") body = <path d="M6 12h12" />;
  else if (n === "battery")
    body = (
      <>
        <rect x="3" y="8" width="16" height="8" rx="1.5" />
        <path d="M19 10.5v3h1.5v-3z" />
        <rect x="5" y="10" width="10" height="4" rx="0.5" fill="currentColor" stroke="none" />
      </>
    );
  else if (n === "recenter") body = <circle cx="12" cy="12" r="7" />;
  else if (n === "share")
    body = (
      <>
        <circle cx="6" cy="12" r="2.2" />
        <circle cx="16" cy="7" r="2.2" />
        <circle cx="16" cy="17" r="2.2" />
        <path d="M8 11.2l6-3.4M8 12.8l6 3.4" />
      </>
    );
  else if (n === "layers")
    body = (
      <>
        <path d="M4 8l8-4 8 4-8 4z" />
        <path d="M4 12l8 4 8-4" />
        <path d="M4 16l8 4 8-4" />
      </>
    );
  else if (n === "trash")
    body = (
      <>
        <path d="M5 8h14M9 8V6h6v2M7 8l1 12h8l1-12" />
      </>
    );
  else if (n === "camera")
    body = (
      <>
        <rect x="3" y="7" width="18" height="12" rx="2" />
        <circle cx="12" cy="13" r="3.2" />
        <path d="M9 7l1.2-2h3.6L15 7" />
      </>
    );
  else if (n === "chat")
    body = <path d="M5 6h14v10H8l-3 3z" />;
  else if (n === "compass")
    body = (
      <>
        <circle cx="12" cy="12" r="8" />
        <path d="M14.5 9.5l-2 5-5 2 2-5z" fill="currentColor" />
      </>
    );

  return (
    <svg viewBox="0 0 24 24" className={className} {...s}>
      {body}
    </svg>
  );
}
