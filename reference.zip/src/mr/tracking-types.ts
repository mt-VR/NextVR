export interface Landmark {
  x: number;
  y: number;
  z: number;
}

export interface DetectedHand {
  id: string;
  landmarks: Landmark[];
  worldLandmarks: Landmark[];
  confidence: number;
}

export interface HandFrame {
  hands: DetectedHand[];
  timestamp: number;
  inferenceMs?: number;
}

export type TrackingStatus = "off" | "loading" | "ready" | "tracking" | "camera-required" | "error";

export interface HandTrackingState {
  status: TrackingStatus;
  count: number;
  message: string;
}

export type WorkerRequest =
  | { type: "init" }
  | { type: "frame"; bitmap: ImageBitmap; timestamp: number }
  | { type: "close" };

export type WorkerResponse =
  | { type: "ready" }
  | { type: "result"; frame: HandFrame }
  | { type: "error"; message: string };

export interface HandOptions {
  confirmMs: number;
  holdMs: number;
  smoothing: number;
  fps: number;
  resolution: number;
}

export const DEFAULT_HAND_OPTIONS: HandOptions = {
  confirmMs: 90, holdMs: 600, smoothing: 0.55, fps: 26, resolution: 640,
};