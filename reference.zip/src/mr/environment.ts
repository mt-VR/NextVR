import * as THREE from "three";
import type { EnvironmentId } from "../lib/preferences";

export function buildHorizonHome(scene: THREE.Scene) {
  const group = new THREE.Group();
  group.name = "horizonHome";

  const floor = new THREE.Mesh(
    new THREE.PlaneGeometry(28, 28),
    new THREE.MeshBasicMaterial({
      color: 0x3a1c0c,
    }),
  );
  floor.rotation.x = -Math.PI / 2;
  floor.position.y = -1.35;
  floor.userData.environmentRole = "floor";
  group.add(floor);

  const grid = new THREE.GridHelper(28, 42, 0xff7a3a, 0xc45a22);
  grid.position.y = -1.33;
  const gmat = grid.material as THREE.Material;
  (gmat as THREE.LineBasicMaterial).linewidth = 1;
  gmat.transparent = true;
  gmat.opacity = 0.72;
  group.add(grid);

  // Guardian ring
  const ring = new THREE.Mesh(
    new THREE.RingGeometry(1.55, 1.58, 32),
    new THREE.MeshBasicMaterial({
      color: 0x7ecbff,
      transparent: true,
      opacity: 0.55,
      side: THREE.DoubleSide,
    }),
  );
  ring.rotation.x = -Math.PI / 2;
  ring.position.y = -1.31;
  group.add(ring);

  const wood = new THREE.MeshBasicMaterial({
    color: 0xc47a3a,
  });
  const darkWood = new THREE.MeshBasicMaterial({
    color: 0x6a3a18,
  });

  const platform = new THREE.Mesh(new THREE.BoxGeometry(2.4, 0.22, 1.5, 1, 1, 1), wood);
  platform.position.set(0, -1.22, -0.2);
  platform.userData.environmentRole = "accent";
  group.add(platform);

  const step = new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.12, 0.7), darkWood);
  step.position.set(0, -1.28, 0.7);
  step.userData.environmentRole = "accent";
  group.add(step);

  // Warm wall blocks like the screenshots
  const wallMat = new THREE.MeshBasicMaterial({ color: 0xe08a40 });
  for (let i = 0; i < 6; i++) {
    const b = new THREE.Mesh(new THREE.BoxGeometry(0.55, 1.4 + (i % 3) * 0.25, 0.18), wallMat);
    b.position.set(-2.4 + i * 0.62, -0.4, -4.2);
    b.userData.environmentRole = "wall";
    group.add(b);
  }

  const back = new THREE.Mesh(
    new THREE.BoxGeometry(8, 3.2, 0.2),
    new THREE.MeshBasicMaterial({ color: 0x4a2210 }),
  );
  back.position.set(0, 0.2, -4.4);
  back.userData.environmentRole = "wall";
  group.add(back);

  scene.fog = new THREE.FogExp2(0x2a1208, 0.035);
  scene.background = new THREE.Color(0x241008);

  scene.add(group);
  return group;
}

export function setPassthroughMode(scene: THREE.Scene, home: THREE.Group, on: boolean) {
  home.visible = !on;
  if (on) {
    scene.background = null;
    scene.fog = null;
  } else {
    setEnvironmentTheme(scene, home, home.userData.theme ?? "horizon");
  }
}

export function setEnvironmentTheme(scene: THREE.Scene, home: THREE.Group, theme: Exclude<EnvironmentId, "passthrough">) {
  const palettes = {
    horizon: [0x241008, 0x3a1c0c, 0xff7a3a, 0xc47a3a, 0xe08a40],
    studio: [0x151b28, 0x242e3f, 0x485a73, 0x4b5f74, 0x8194a7],
    aurora: [0x081b24, 0x142a33, 0x357b82, 0x306c6e, 0x68aba2],
    sunset: [0x291b28, 0x3b2b3d, 0x9b6882, 0x8a6274, 0xe6a78d],
  };
  const [sky, floor, grid, wood, wall] = palettes[theme];
  home.userData.theme = theme;
  scene.background = new THREE.Color(sky);
  scene.fog = new THREE.FogExp2(sky, 0.035);
  scene.backgroundRotation.set(0, 0, 0);
  home.visible = true;
  const base = home.children[0] as THREE.Mesh;
  (base.material as THREE.MeshBasicMaterial).color.setHex(floor);
  const gridMaterial = (home.children[1] as THREE.GridHelper).material as THREE.LineBasicMaterial;
  gridMaterial.color.setHex(grid);
  gridMaterial.opacity = 0.35;
  home.children.forEach((object) => {
    if (!(object instanceof THREE.Mesh)) return;
    const material = object.material as THREE.MeshBasicMaterial;
    if (object.userData.environmentRole === "wall") material.color.setHex(wall);
    if (object.userData.environmentRole === "accent") material.color.setHex(wood);
  });
}
