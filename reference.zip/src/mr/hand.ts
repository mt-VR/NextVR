import * as THREE from "three";
import { OneEuro } from "../lib/filters";
import { DEFAULT_HAND_OPTIONS, type DetectedHand, type HandOptions, type Landmark } from "./tracking-types";

const CONNECTIONS = [
  [0, 1], [1, 2], [2, 3], [3, 4],
  [5, 6], [6, 7], [7, 8],
  [9, 10], [10, 11], [11, 12],
  [13, 14], [14, 15], [15, 16],
  [17, 18], [18, 19], [19, 20],
];
const PALM_OUTLINE = [0, 1, 5, 9, 13, 17];
const PALM_CENTER = [0, 5, 9, 13, 17];
const PALM_SPANS = [[5, 17], [0, 9], [0, 5], [0, 17]];
const Y_AXIS = new THREE.Vector3(0, 1, 0);

export interface VideoProjection {
  width: number;
  height: number;
  videoWidth: number;
  videoHeight: number;
  mirrored: boolean;
}

export function projectVideoPoint(point: Landmark, projection: VideoProjection) {
  const { width, height, videoWidth, videoHeight, mirrored } = projection;
  const cover = Math.max(width / videoWidth, height / videoHeight);
  const imageX = mirrored ? 1 - point.x : point.x;
  return {
    x: (imageX * videoWidth * cover - (videoWidth * cover - width) / 2) / width,
    y: (point.y * videoHeight * cover - (videoHeight * cover - height) / 2) / height,
  };
}

function separation(a: Landmark, b: Landmark, aspect = 1) {
  return Math.hypot(a.x - b.x, (a.y - b.y) * aspect, a.z - b.z);
}

export function handPinchRatio(hand: DetectedHand, aspect: number) {
  const hasWorld = hand.worldLandmarks.length === 21 &&
    hand.worldLandmarks.every((p) => [p.x, p.y, p.z].every(Number.isFinite));
  const points = hasWorld ? hand.worldLandmarks : hand.landmarks;
  const ratioAspect = hasWorld ? 1 : aspect;
  const palmSize = Math.max(
    separation(points[0], points[9], ratioAspect),
    separation(points[5], points[17], ratioAspect),
    0.0001,
  );
  return separation(points[4], points[8], ratioAspect) / palmSize;
}

function averageZ(points: Landmark[]) {
  return PALM_CENTER.reduce((sum, i) => sum + points[i].z, 0) / PALM_CENTER.length;
}

/** Articulated overlay driven exclusively by the camera's 21 hand landmarks. */
export class TrackedHandVisual {
  readonly root = new THREE.Group();
  readonly palmWorld = new THREE.Vector3();
  readonly palmNdc = new THREE.Vector2();
  readonly imagePalm = new THREE.Vector2();
  pointer = { x: 0, y: 0 };
  pinching = false;
  lastSeen = 0;
  reliable = false;
  pinchProgress = 0;
  options: HandOptions = { ...DEFAULT_HAND_OPTIONS };
  private points = Array.from({ length: 21 }, () => new THREE.Vector3());
  private filters = Array.from({ length: 63 }, () => new OneEuro(4, 25, 2));
  private depthFilter = new OneEuro(2.5, 6, 2);
  private joints: THREE.Mesh[] = [];
  private bones: THREE.Mesh[] = [];
  private palm: THREE.Mesh;
  private contour: THREE.LineLoop;
  private glow: THREE.Mesh;
  private ring: THREE.Mesh;
  private localPalm = new THREE.Vector3();
  private direction = new THREE.Vector3();
  private normal = new THREE.Vector3();
  private cross = new THREE.Vector3();
  private closingSince = 0;
  private openingSince = 0;
  private pinchArmed = false;
  private materials: THREE.Material[] = [];
  private basePointer = { x: 0, y: 0 };
  private pointerVelocity = { x: 0, y: 0 };
  private sampleTime = 0;
  private previousPalm = new THREE.Vector3();
  private palmVelocity = new THREE.Vector3();
  private predictedOffset = new THREE.Vector3();

  constructor(readonly id: string) {
    this.root.name = `tracked-hand-${id}`;
    this.root.visible = false;

    const skin = new THREE.MeshBasicMaterial({
      color: 0x494550,
      transparent: true,
      opacity: 0.72,
      depthWrite: false,
      depthTest: false,
      side: THREE.DoubleSide,
    });
    const outline = new THREE.MeshBasicMaterial({
      color: 0xf5f6ff,
      side: THREE.BackSide,
      transparent: true,
      opacity: 0.6,
      depthWrite: false,
      depthTest: false,
    });
    const sphere = new THREE.SphereGeometry(1, 10, 8);
    const cylinder = new THREE.CylinderGeometry(0.82, 1, 1, 8, 1);

    for (let i = 0; i < 21; i++) {
      const joint = new THREE.Mesh(sphere, skin);
      const edge = new THREE.Mesh(sphere, outline);
      edge.scale.setScalar(1.09);
      joint.add(edge);
      this.joints.push(joint);
      this.root.add(joint);
    }
    for (let i = 0; i < CONNECTIONS.length; i++) {
      const bone = new THREE.Mesh(cylinder, skin);
      const edge = new THREE.Mesh(cylinder, outline);
      edge.scale.set(1.11, 1.01, 1.11);
      bone.add(edge);
      this.bones.push(bone);
      this.root.add(bone);
    }

    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute("position", new THREE.BufferAttribute(new Float32Array(14 * 3), 3));
    const indices: number[] = [];
    for (let i = 0; i < 6; i++) {
      const next = (i + 1) % 6;
      indices.push(12, i, next, 13, next + 6, i + 6, i, i + 6, next, next, i + 6, next + 6);
    }
    geometry.setIndex(indices);
    this.palm = new THREE.Mesh(geometry, skin);
    this.palm.frustumCulled = false;
    this.root.add(this.palm);

    const contourGeometry = new THREE.BufferGeometry();
    contourGeometry.setAttribute("position", new THREE.BufferAttribute(new Float32Array(6 * 3), 3));
    this.contour = new THREE.LineLoop(contourGeometry, new THREE.LineBasicMaterial({
      color: 0xf4f6ff,
      transparent: true,
      opacity: 0.8,
      depthTest: false,
    }));
    this.contour.frustumCulled = false;
    this.root.add(this.contour);

    this.glow = new THREE.Mesh(sphere, new THREE.MeshBasicMaterial({
      color: 0xffffff, transparent: true, opacity: 0, depthTest: false,
    }));
    this.glow.scale.setScalar(0.0045);
    this.ring = new THREE.Mesh(new THREE.TorusGeometry(0.012, 0.001, 8, 28), new THREE.MeshBasicMaterial({
      color: 0xffffff, transparent: true, opacity: 0, depthTest: false,
    }));
    this.root.add(this.glow, this.ring);
    this.materials = [skin, outline, this.contour.material as THREE.Material];
    this.materials.forEach((material) => { material.userData.baseOpacity = (material as THREE.MeshBasicMaterial).opacity; });
  }

  configure(options: HandOptions) {
    this.options = { ...options };
    this.filters.forEach((filter) => { filter.minCutoff = 6 - options.smoothing * 3.5; filter.beta = 22; filter.dCutoff = 4; });
  }

  update(hand: DetectedHand, projection: VideoProjection, camera: THREE.PerspectiveCamera, timestamp: number) {
    if (hand.landmarks.length !== 21 ||
      hand.landmarks.some((p) => ![p.x, p.y, p.z].every(Number.isFinite))) {
      this.reliable = false;
      return;
    }
    if (!this.root.visible) this.resetFilters();
    if (this.sampleTime && timestamp - this.sampleTime > 150 && !this.pinching) {
      this.closingSince = 0;
      this.pinchArmed = false;
      this.pinchProgress = 0;
    }

    const landmarks = hand.landmarks.map((p, i) => ({
      x: this.filters[i * 3].filter(p.x, timestamp),
      y: this.filters[i * 3 + 1].filter(p.y, timestamp),
      z: this.filters[i * 3 + 2].filter(p.z, timestamp),
    }));
    this.imagePalm.set(0, 0);
    PALM_CENTER.forEach((i) => {
      this.imagePalm.x += landmarks[i].x / PALM_CENTER.length;
      this.imagePalm.y += landmarks[i].y / PALM_CENTER.length;
    });
    const screenPoints = landmarks.map((p) => projectVideoPoint(p, projection));
    const halfHeightAtOne = Math.tan(THREE.MathUtils.degToRad(camera.fov / 2));
    const halfWidthAtOne = halfHeightAtOne * camera.aspect;
    const widthAtOne = Math.hypot(
      (screenPoints[5].x - screenPoints[17].x) * 2 * halfWidthAtOne,
      (screenPoints[5].y - screenPoints[17].y) * 2 * halfHeightAtOne,
    );
    const hasWorld = hand.worldLandmarks.length === 21 &&
      hand.worldLandmarks.every((p) => [p.x, p.y, p.z].every(Number.isFinite));
    const physicalWidth = hasWorld
      ? THREE.MathUtils.clamp(separation(hand.worldLandmarks[5], hand.worldLandmarks[17]), 0.045, 0.095)
      : 0.065;
    let estimatedDepth = physicalWidth / Math.max(widthAtOne, 0.035);
    if (hasWorld) {
      let numerator = 0;
      let denominator = 0;
      // Multiple projected palm spans avoid a false depth jump when the hand turns edge-on.
      PALM_SPANS.forEach(([a, b]) => {
        const projectedSpan = Math.hypot(
          (screenPoints[a].x - screenPoints[b].x) * 2 * halfWidthAtOne,
          (screenPoints[a].y - screenPoints[b].y) * 2 * halfHeightAtOne,
        );
        const physicalSpan = Math.hypot(
          hand.worldLandmarks[a].x - hand.worldLandmarks[b].x,
          hand.worldLandmarks[a].y - hand.worldLandmarks[b].y,
        );
        numerator += projectedSpan * physicalSpan;
        denominator += projectedSpan * projectedSpan;
      });
      if (denominator > 0.0005) estimatedDepth = numerator / denominator;
    }
    const depth = this.depthFilter.filter(
      THREE.MathUtils.clamp(estimatedDepth, 0.2, 0.95),
      timestamp,
    );
    const palmZ = averageZ(hasWorld ? hand.worldLandmarks : landmarks);

    for (let i = 0; i < 21; i++) {
      const relativeZ = hasWorld
        ? hand.worldLandmarks[i].z - palmZ
        : (landmarks[i].z - palmZ) * depth * 2 * halfWidthAtOne;
      const jointDepth = depth + THREE.MathUtils.clamp(relativeZ, -0.12, 0.12);
      this.points[i].set(
        (screenPoints[i].x * 2 - 1) * halfWidthAtOne * jointDepth,
        (1 - screenPoints[i].y * 2) * halfHeightAtOne * jointDepth,
        -jointDepth,
      );
    }

    this.localPalm.set(0, 0, 0);
    PALM_CENTER.forEach((i) => this.localPalm.add(this.points[i]));
    this.localPalm.divideScalar(PALM_CENTER.length);
    if (this.sampleTime && timestamp > this.sampleTime) {
      const measuredVelocity = this.localPalm.clone().sub(this.previousPalm)
        .divideScalar(Math.max(0.01, (timestamp - this.sampleTime) / 1000)).clampLength(0, 0.8);
      this.palmVelocity.lerp(measuredVelocity, 0.35);
    }
    this.previousPalm.copy(this.localPalm);
    const palmScreen = PALM_CENTER.reduce((sum, i) => ({
      x: sum.x + screenPoints[i].x / PALM_CENTER.length,
      y: sum.y + screenPoints[i].y / PALM_CENTER.length,
    }), { x: 0, y: 0 });
    this.palmNdc.set(palmScreen.x * 2 - 1, 1 - palmScreen.y * 2);
    const ratio = handPinchRatio(hand, projection.videoHeight / projection.videoWidth);
    const pinchWeight = THREE.MathUtils.clamp((0.5 - ratio) / 0.4, 0, 1) * 0.5;
    const nextPointer = {
      x: (screenPoints[8].x * (1 - pinchWeight) + screenPoints[4].x * pinchWeight) * projection.width,
      y: (screenPoints[8].y * (1 - pinchWeight) + screenPoints[4].y * pinchWeight) * projection.height,
    };
    if (this.sampleTime && timestamp > this.sampleTime) {
      const seconds = Math.max((timestamp - this.sampleTime) / 1000, 0.01);
      this.pointerVelocity.x = this.pointerVelocity.x * 0.6 + THREE.MathUtils.clamp((nextPointer.x - this.basePointer.x) / seconds, -1200, 1200) * 0.4;
      this.pointerVelocity.y = this.pointerVelocity.y * 0.6 + THREE.MathUtils.clamp((nextPointer.y - this.basePointer.y) / seconds, -1200, 1200) * 0.4;
    }
    this.basePointer = nextPointer;
    this.pointer = { ...nextPointer };
    this.sampleTime = timestamp;
    this.reliable = [landmarks[4], landmarks[8]].every((p) => p.x > 0.015 && p.x < 0.985 && p.y > 0.015 && p.y < 0.985);

    const radius = THREE.MathUtils.clamp(physicalWidth * 0.12, 0.005, 0.011);
    this.joints.forEach((joint, i) => {
      joint.position.copy(this.points[i]);
      joint.scale.setScalar(radius * ([4, 8, 12, 16, 20].includes(i) ? 0.68 : 0.92));
    });
    CONNECTIONS.forEach(([from, to], i) => {
      const bone = this.bones[i];
      this.direction.subVectors(this.points[to], this.points[from]);
      bone.position.copy(this.points[from]).add(this.points[to]).multiplyScalar(0.5);
      bone.scale.set(radius, this.direction.length(), radius);
      if (this.direction.lengthSq() > 1e-9) {
        bone.quaternion.setFromUnitVectors(Y_AXIS, this.direction.normalize());
      }
    });
    this.updatePalm(radius);
    this.updatePinch(ratio, timestamp);
    this.root.visible = true;
    this.lastSeen = performance.now();
    this.refresh(camera);
  }

  private updatePalm(thickness: number) {
    this.normal.subVectors(this.points[5], this.points[0]);
    this.cross.subVectors(this.points[17], this.points[0]);
    this.normal.cross(this.cross).normalize().multiplyScalar(thickness * 0.5);
    const position = this.palm.geometry.getAttribute("position") as THREE.BufferAttribute;
    const edge = this.contour.geometry.getAttribute("position") as THREE.BufferAttribute;
    PALM_OUTLINE.forEach((index, i) => {
      const p = this.points[index];
      position.setXYZ(i, p.x + this.normal.x, p.y + this.normal.y, p.z + this.normal.z);
      position.setXYZ(i + 6, p.x - this.normal.x, p.y - this.normal.y, p.z - this.normal.z);
      edge.setXYZ(i, p.x, p.y, p.z);
    });
    position.setXYZ(12, this.localPalm.x + this.normal.x, this.localPalm.y + this.normal.y, this.localPalm.z + this.normal.z);
    position.setXYZ(13, this.localPalm.x - this.normal.x, this.localPalm.y - this.normal.y, this.localPalm.z - this.normal.z);
    position.needsUpdate = true;
    edge.needsUpdate = true;
  }

  private updatePinch(ratio: number, timestamp: number) {
    if (!Number.isFinite(ratio)) return;
    if (ratio > 0.46) this.pinchArmed = true;
    if (!this.pinching) {
      if (this.pinchArmed && ratio < 0.24 && this.reliable) {
        if (!this.closingSince) this.closingSince = timestamp;
      } else this.closingSince = 0;
      this.pinchProgress = this.closingSince ? Math.min(1, (timestamp - this.closingSince) / this.options.confirmMs) : 0;
      if (this.pinchProgress >= 1) {
        this.pinching = true;
        this.openingSince = 0;
        this.pinchArmed = false;
      }
    } else {
      if (ratio > 0.4) { if (!this.openingSince) this.openingSince = timestamp; }
      else this.openingSince = 0;
      if (this.openingSince && timestamp - this.openingSince >= 55) {
        this.pinching = false;
        this.closingSince = 0;
        this.pinchProgress = 0;
      }
    }
    const strength = this.pinching ? 1 : THREE.MathUtils.clamp((0.45 - ratio) / 0.3, 0, 0.6);
    this.glow.position.copy(this.points[4]).add(this.points[8]).multiplyScalar(0.5);
    this.ring.position.copy(this.glow.position);
    (this.glow.material as THREE.MeshBasicMaterial).opacity = strength * 0.9;
    (this.ring.material as THREE.MeshBasicMaterial).opacity = strength * 0.8;
  }

  refresh(camera: THREE.PerspectiveCamera) {
    const age = performance.now() - this.lastSeen;
    const lead = Math.min(0.018, Math.max(0, (performance.now() - this.sampleTime) / 1000)) * Math.exp(-Math.max(0, age - 80) * 0.025);
    this.predictedOffset.copy(this.palmVelocity).multiplyScalar(lead).applyQuaternion(camera.quaternion);
    this.root.position.copy(camera.position).add(this.predictedOffset);
    this.root.quaternion.copy(camera.quaternion);
    this.palmWorld.copy(this.localPalm).applyQuaternion(camera.quaternion).add(this.root.position);
    this.pointer.x = this.basePointer.x + this.pointerVelocity.x * lead;
    this.pointer.y = this.basePointer.y + this.pointerVelocity.y * lead;
    const fade = age <= this.options.holdMs * 0.7 ? 1 : THREE.MathUtils.clamp(
      (this.options.holdMs - age) / (this.options.holdMs * 0.3), 0, 1,
    );
    this.materials.forEach((material) => { (material as THREE.MeshBasicMaterial).opacity = material.userData.baseOpacity * fade; });
    if (age > 220) {
      this.pinching = false;
      this.pinchProgress = 0;
      this.reliable = false;
      (this.glow.material as THREE.MeshBasicMaterial).opacity = 0;
      (this.ring.material as THREE.MeshBasicMaterial).opacity = 0;
    }
    if (age > this.options.holdMs) this.hide();
  }

  get canInteract() { return this.root.visible && this.reliable && performance.now() - this.lastSeen < 170; }

  hide() {
    this.root.visible = false;
    this.pinching = false;
    this.pinchArmed = false;
    this.openingSince = 0;
    this.closingSince = 0;
    this.pinchProgress = 0;
    this.reliable = false;
  }

  private resetFilters() {
    this.filters.forEach((filter) => filter.reset());
    this.depthFilter.reset();
    this.sampleTime = 0;
    this.pointerVelocity = { x: 0, y: 0 };
    this.palmVelocity.set(0, 0, 0);
  }

  dispose() {
    const geometries = new Set<THREE.BufferGeometry>();
    const materials = new Set<THREE.Material>();
    this.root.traverse((object) => {
      if (object instanceof THREE.Mesh || object instanceof THREE.LineLoop) {
        geometries.add(object.geometry);
        const group = Array.isArray(object.material) ? object.material : [object.material];
        group.forEach((material) => materials.add(material));
      }
    });
    geometries.forEach((geometry) => geometry.dispose());
    materials.forEach((material) => material.dispose());
    this.root.removeFromParent();
  }
}