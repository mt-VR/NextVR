import * as THREE from "three";
import { CSS3DObject, CSS3DRenderer } from "three/addons/renderers/CSS3DRenderer.js";
import { loadYouTubePlayerAPI, type YouTubePlayerInstance } from "../lib/youtube";

type Mirror = { object: CSS3DObject; source: CSS3DObject; observer: MutationObserver; dirty: boolean };

/** Opt-in two-eye projection; all application state and input remain in the original React tree. */
export class StereoUI {
  readonly renderer = new CSS3DRenderer();
  readonly scene = new THREE.Scene();
  private mirrors = new Map<string, Mirror>();
  private sources = new WeakMap<Node, Node>();
  private players = new Map<HTMLIFrameElement, { source: HTMLIFrameElement; player: YouTubePlayerInstance | null }>();
  private lastSync = 0;
  private disposed = false;

  constructor(parent: HTMLElement) {
    Object.assign(this.renderer.domElement.style, { position: "absolute", top: "0", left: "50%", width: "50%", height: "100%", zIndex: "3", pointerEvents: "none", overflow: "hidden" });
    this.renderer.domElement.dataset.eyeMirror = "right";
    parent.appendChild(this.renderer.domElement);
    this.renderer.domElement.addEventListener("click", this.relayClick, true);
    for (const type of ["pointerdown", "pointermove", "pointerup", "pointercancel"]) this.renderer.domElement.addEventListener(type, this.relayPointer as EventListener, true);
    document.addEventListener("metamr:playback", this.playback);
  }

  resolve(element: Element | null): HTMLElement | null {
    let current: Node | null = element;
    while (current) {
      const source = this.sources.get(current);
      if (source instanceof HTMLElement) return source;
      current = current.parentNode;
    }
    return element instanceof HTMLElement ? element : element?.closest<HTMLElement>("button, a, input, textarea, [data-scroll], [data-spatial]") ?? null;
  }

  private relayClick = (event: MouseEvent) => {
    const source = this.resolve(event.target as Element);
    if (!source) return;
    event.preventDefault();
    event.stopPropagation();
    if (source instanceof HTMLInputElement || source instanceof HTMLTextAreaElement) source.focus();
    else source.click();
  };

  private relayPointer = (event: PointerEvent) => {
    const source = this.resolve(event.target as Element);
    if (!source) return;
    const bounds = this.renderer.domElement.getBoundingClientRect();
    event.stopPropagation();
    if (event.type === "pointerdown" && (event.target as Element).closest("[data-grab], [data-resize]")) {
      try { (event.target as HTMLElement).setPointerCapture(event.pointerId); } catch {}
    }
    source.dispatchEvent(new PointerEvent(event.type, {
      bubbles: true, cancelable: true, clientX: event.clientX - bounds.width, clientY: event.clientY,
      pointerId: event.pointerId, pointerType: event.pointerType, button: event.button, buttons: event.buttons,
    }));
  };

  private playback = (event: Event) => {
    const data = (event as CustomEvent<{ source: HTMLIFrameElement; time: number; state: number }>).detail;
    if (!data) return;
    this.players.forEach((entry) => {
      const player = entry.player;
      if (entry.source !== data.source || !player) return;
      try {
        player.mute();
        if (Math.abs(player.getCurrentTime() - data.time) > 0.75) player.seekTo(data.time, true);
        if (data.state === 1 && player.getPlayerState() !== 1) player.playVideo();
        if (data.state !== 1 && player.getPlayerState() === 1) player.pauseVideo();
      } catch { /* Third-party playback may be blocked by browser policy. */ }
    });
  };

  private synchronize(source: Node, target: Node, root = false) {
    this.sources.set(target, source);
    if (source.nodeType === Node.TEXT_NODE) { if (target.nodeValue !== source.nodeValue) target.nodeValue = source.nodeValue; return; }
    if (source instanceof Element && target instanceof Element) {
      if (!root) {
        for (const attribute of Array.from(target.attributes)) {
          if (!source.hasAttribute(attribute.name) && attribute.name !== "data-stereo-src") target.removeAttribute(attribute.name);
        }
        for (const attribute of Array.from(source.attributes)) {
          if (attribute.name === "id") continue;
          if (source instanceof HTMLIFrameElement && attribute.name === "src") continue;
          if (target.getAttribute(attribute.name) !== attribute.value) target.setAttribute(attribute.name, attribute.value);
        }
      }
      if (source instanceof HTMLInputElement && target instanceof HTMLInputElement) { target.value = source.value; target.checked = source.checked; }
      if (source instanceof HTMLTextAreaElement && target instanceof HTMLTextAreaElement) target.value = source.value;
      if (source instanceof HTMLIFrameElement && target instanceof HTMLIFrameElement) {
        if (target.dataset.stereoSrc !== source.src) {
          const parent = target.parentNode;
          const nextSibling = target.nextSibling;
          try { this.players.get(target)?.player?.destroy(); } catch {}
          if (parent && !target.parentNode) parent.insertBefore(target, nextSibling);
          this.players.delete(target);
          target.dataset.stereoSrc = source.src;
          if (/youtube(?:-nocookie)?\.com\/embed\//.test(source.src)) {
            const url = new URL(source.src);
            url.searchParams.set("mute", "1"); url.searchParams.set("autoplay", "0");
            target.src = url.toString();
            const entry = { source, player: null as YouTubePlayerInstance | null };
            this.players.set(target, entry);
            void loadYouTubePlayerAPI().then((api) => {
              if (this.disposed || !target.isConnected) return;
              entry.player = new api.Player(target, { events: {
                onReady: ({ target: player }) => { entry.player = player; player.mute(); },
                onStateChange: () => {}, onError: () => {}, onAutoplayBlocked: () => {},
              } });
            }).catch(() => {});
          } else target.src = source.src;
        }
        return;
      }
    }
    const originalChildren = Array.from(source.childNodes);
    for (let i = 0; i < originalChildren.length; i++) {
      const original = originalChildren[i];
      let copy = target.childNodes[i];
      if (!copy || copy.nodeType !== original.nodeType || copy.nodeName !== original.nodeName) {
        const fresh = original instanceof HTMLIFrameElement ? document.createElement("iframe") : original.cloneNode(false);
        if (fresh instanceof Element) fresh.removeAttribute("id");
        if (copy) target.replaceChild(fresh, copy); else target.appendChild(fresh);
        copy = fresh as ChildNode;
      }
      this.synchronize(original, copy);
    }
    while (target.childNodes.length > originalChildren.length) target.lastChild?.remove();
    if (source instanceof HTMLElement && target instanceof HTMLElement) {
      target.scrollTop = source.scrollTop; target.scrollLeft = source.scrollLeft;
    }
  }

  render(objects: Map<string, { object: CSS3DObject }>, camera: THREE.PerspectiveCamera, time: number) {
    const sync = time - this.lastSync > 90;
    if (sync) this.lastSync = time;
    objects.forEach(({ object: source }, id) => {
      let mirror = this.mirrors.get(id);
      if (!mirror) {
        const element = document.createElement("div");
        element.style.pointerEvents = "auto"; element.style.width = "max-content";
        element.dataset.spatial = id;
        const object = new CSS3DObject(element);
        mirror = { source, object, dirty: true, observer: new MutationObserver((records) => {
          if (records.some((record) => record.target !== source.element || record.type === "childList")) mirror!.dirty = true;
        }) };
        mirror.observer.observe(source.element, { subtree: true, attributes: true, childList: true, characterData: true });
        this.mirrors.set(id, mirror); this.scene.add(object);
      }
      if (mirror.object.visible && !source.visible) this.players.forEach((entry) => {
        if (source.element.contains(entry.source)) { try { entry.player?.pauseVideo(); } catch {} }
      });
      mirror.object.position.copy(source.position); mirror.object.quaternion.copy(source.quaternion); mirror.object.scale.copy(source.scale); mirror.object.visible = source.visible;
      if (sync && mirror.dirty && source.visible) { this.synchronize(source.element, mirror.object.element, true); mirror.dirty = false; }
      if (sync) {
        const from = source.element.querySelectorAll<HTMLElement>("[data-scroll]");
        const to = mirror.object.element.querySelectorAll<HTMLElement>("[data-scroll]");
        from.forEach((node, i) => { if (to[i]) { to[i].scrollTop = node.scrollTop; to[i].scrollLeft = node.scrollLeft; } });
      }
    });
    this.mirrors.forEach((mirror, id) => {
      if (!objects.has(id)) { mirror.observer.disconnect(); mirror.object.removeFromParent(); mirror.object.element.remove(); this.mirrors.delete(id); }
    });
    this.players.forEach((entry, element) => { if (!element.isConnected) { try { entry.player?.destroy(); } catch {} this.players.delete(element); } });
    this.renderer.render(this.scene, camera);
  }

  resize(width: number, height: number) { this.renderer.setSize(width / 2, height); }

  dispose() {
    this.disposed = true;
    this.mirrors.forEach((mirror) => mirror.observer.disconnect());
    this.players.forEach((entry) => { try { entry.player?.destroy(); } catch {} });
    this.mirrors.clear(); this.players.clear();
    document.removeEventListener("metamr:playback", this.playback);
    this.renderer.domElement.remove();
  }
}