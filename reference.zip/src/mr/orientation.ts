import { Euler, Quaternion, Vector3, MathUtils } from "three";
import { unwrapAngle } from "../lib/filters";

/** Smooth rotations on the quaternion sphere, not on discontinuous Euler angles. */
export class QuaternionPoseFilter {
  readonly value = new Quaternion();
  private estimate = new Quaternion();
  private previous = new Quaternion();
  private covariance = 0.001;
  private speed = 0;
  private lastTime: number | null = null;

  reset(sample: Quaternion, time = performance.now()) {
    this.value.copy(sample).normalize();
    this.estimate.copy(this.value);
    this.previous.copy(this.value);
    this.covariance = 0.001;
    this.speed = 0;
    this.lastTime = time;
  }

  update(sample: Quaternion, time: number): Quaternion {
    if (this.lastTime === null || time - this.lastTime > 1000) {
      this.reset(sample, time);
      return this.value;
    }

    const dt = MathUtils.clamp((time - this.lastTime) / 1000, 0.001, 0.1);
    const observedSpeed = this.previous.angleTo(sample) / dt;
    const derivativeAlpha = 1 - Math.exp(-2 * Math.PI * 3 * dt);
    this.speed += derivativeAlpha * (observedSpeed - this.speed);

    // Kalman gain adapts to motion; slerp cannot overshoot the measured rotation.
    this.covariance += (0.02 + this.speed * 0.012) * dt;
    const measurementNoise = 0.00065 / (1 + this.speed * 0.8);
    const gain = this.covariance / (this.covariance + measurementNoise);
    this.estimate.slerp(sample, gain).normalize();
    this.covariance *= 1 - gain;

    const cutoff = 3.5 + this.speed * 3;
    const euroAlpha = 1 / (1 + 1 / (2 * Math.PI * cutoff * dt));
    this.value.slerp(this.estimate, euroAlpha).normalize();
    this.previous.copy(sample);
    this.lastTime = time;
    return this.value;
  }
}

export function screenAngle(): number {
  const modern = window.screen.orientation?.angle;
  const legacy = (window as Window & { orientation?: number }).orientation;
  const degrees = Number.isFinite(modern) ? modern! : Number.isFinite(legacy) ? legacy! : 0;
  return degrees * MathUtils.DEG2RAD;
}

/** Match the mobile viewer convention: sensor, optical axis correction, then screen rotation. */
export function deviceCameraRotation(alpha: number, beta: number, gamma: number, angle: number, result = new Quaternion()) {
  const sensor = new Quaternion().setFromEuler(new Euler(
    beta * MathUtils.DEG2RAD, alpha * MathUtils.DEG2RAD, -gamma * MathUtils.DEG2RAD, "YXZ",
  ));
  const screen = new Quaternion().setFromAxisAngle(new Vector3(0, 0, 1), -angle);
  const opticalAxis = new Quaternion(-Math.SQRT1_2, 0, 0, Math.SQRT1_2);
  return result.copy(sensor).multiply(opticalAxis).multiply(screen).normalize();
}

export class DevicePose {
  readonly rotation = new Quaternion();
  readonly filter = new QuaternionPoseFilter();
  hasSensor = false;
  private euler = new Euler(0, 0, 0, "YXZ");
  private target = new Quaternion();
  private rawYaw = 0;
  private rawPitch = 0;
  private centerYaw = 0;
  private centerPitch = 0;
  private yawReady = false;
  private rebasePending = false;
  private lastSample = 0;
  private sensitivity = 0.28;
  private pitchSensitivity = 0.18;

  setSensitivity(value: number) {
    this.sensitivity = MathUtils.clamp(value, 0.12, 0.42);
    this.pitchSensitivity = MathUtils.clamp(value * 0.64, 0.08, 0.26);
  }

  private establishCenter(time: number) {
    this.centerYaw = this.rawYaw;
    this.centerPitch = this.rawPitch;
    this.euler.set(0, 0, 0, "YXZ");
    this.target.setFromEuler(this.euler);
    // Retain the current visual pose and glide into the new reference instead of snapping.
    this.filter.reset(this.rotation, time);
  }

  accept(event: DeviceOrientationEvent, angle: number, time: number): boolean {
    const { alpha, beta, gamma } = event;
    if (alpha === null || beta === null || gamma === null) return false;
    if (![alpha, beta, gamma, angle].every(Number.isFinite)) return false;

    const heading = alpha * MathUtils.DEG2RAD - angle;
    const landscape = Math.abs(Math.sin(angle)) > 0.7;
    const tiltSource = (landscape ? gamma : beta) * MathUtils.DEG2RAD;
    this.rawYaw = this.yawReady ? unwrapAngle(this.rawYaw, heading) : heading;
    this.rawPitch = tiltSource;
    this.yawReady = true;

    if (!this.hasSensor || this.rebasePending || time - this.lastSample > 1000) {
      this.establishCenter(time);
      this.hasSensor = true;
      this.rebasePending = false;
    } else {
      // Heading and tilt are independent, intentionally low-gain and clamped to avoid runaway worlds.
      const yaw = MathUtils.clamp((this.rawYaw - this.centerYaw) * this.sensitivity, -0.78, 0.78);
      const pitch = MathUtils.clamp((this.rawPitch - this.centerPitch) * this.pitchSensitivity, -0.32, 0.32);
      this.euler.set(
        pitch,
        yaw,
        0,
        "YXZ",
      );
      this.target.setFromEuler(this.euler);
      this.filter.update(this.target, time);
    }

    this.lastSample = time;
    this.rotation.copy(this.filter.value).normalize();
    return true;
  }

  screenChanged() {
    this.rebasePending = true;
  }

  setView(rotation: Quaternion) {
    this.rotation.copy(rotation);
    this.filter.reset(rotation, this.lastSample || performance.now());
  }

  recenter() {
    if (!this.hasSensor) {
      this.setView(new Quaternion());
      return;
    }
    this.establishCenter(performance.now());
  }
}