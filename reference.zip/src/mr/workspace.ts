import { Quaternion, Vector3 } from "three";
import type { Vec3 } from "./engine";

export interface WorkspaceWindow {
  id: string;
  kind: string;
  title: string;
  pos: Vec3;
  rotation: [number, number, number, number];
  width: number;
  scale: number;
  minimized: boolean;
  slot: number;
}

export const WINDOW_WIDTH = 840;
export const WINDOW_HEIGHT = 490;
export const WORKSPACE_SLOTS = [0, -1, 1] as const;
export const MAX_VISIBLE_APPS = 3;

export function isApplicationWindow(window: Pick<WorkspaceWindow, "kind">) {
  return window.kind !== "multitask";
}

export function reserveWorkspaceSlot(windows: WorkspaceWindow[], targetId: string) {
  let next = windows;
  const visible = windows.filter((window) => isApplicationWindow(window) && !window.minimized && window.id !== targetId);
  const minimizedIds: string[] = [];
  while (visible.length >= MAX_VISIBLE_APPS) {
    const oldest = visible.shift()!;
    minimizedIds.push(oldest.id);
  }
  if (minimizedIds.length) next = windows.map((window) => minimizedIds.includes(window.id) ? { ...window, minimized: true } : window);
  const occupied = new Set(next.filter((window) => isApplicationWindow(window) && !window.minimized && window.id !== targetId).map((window) => window.slot));
  return { windows: next, slot: WORKSPACE_SLOTS.find((slot) => !occupied.has(slot)) ?? 0, minimizedIds };
}

export function arcPose(slot: number, radius: number, basis: Quaternion) {
  // Slots 0, -1, +1 create three independent panels on a user-centered arc.
  const angle = slot * 0.72;
  const row = Math.floor(Math.abs(slot) / 4);
  const localPosition = new Vector3(Math.sin(angle) * radius, 0.045 + row * 0.62, -Math.cos(angle) * radius);
  const position = localPosition.clone();
  position.applyQuaternion(basis);
  const localNormal = localPosition.clone().multiplyScalar(-1).setY(0).normalize();
  const rotation = new Quaternion().setFromUnitVectors(new Vector3(0, 0, 1), localNormal).premultiply(basis);
  return {
    pos: { x: position.x, y: position.y, z: position.z },
    rotation: rotation.toArray() as [number, number, number, number],
  };
}

export function flatPose(slot: number, radius: number, basis: Quaternion, scale: number) {
  const localPosition = new Vector3(slot * (WINDOW_WIDTH * scale * 0.001 + 0.07), 0.045, -radius);
  const position = localPosition.clone().applyQuaternion(basis);
  const localNormal = localPosition.clone().multiplyScalar(-1).setY(0).normalize();
  return {
    pos: { x: position.x, y: position.y, z: position.z },
    rotation: new Quaternion().setFromUnitVectors(new Vector3(0, 0, 1), localNormal).premultiply(basis).toArray() as [number, number, number, number],
  };
}

export function availableSlot(windows: WorkspaceWindow[]) {
  const occupied = new Set(windows.filter((window) => isApplicationWindow(window) && !window.minimized).map((window) => window.slot));
  return WORKSPACE_SLOTS.find((slot) => !occupied.has(slot)) ?? 0;
}