import visionBundle from "../../node_modules/@mediapipe/tasks-vision/vision_bundle.cjs?raw";
import type { FilesetResolver, HandLandmarker } from "@mediapipe/tasks-vision";
import type { WorkerRequest, WorkerResponse } from "./tracking-types";

export const VISION_WASM = "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.21/wasm";
export const HAND_MODEL = "https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task";

type VisionAPI = {
  FilesetResolver: typeof FilesetResolver;
  HandLandmarker: typeof HandLandmarker;
};

function runWorker(api: VisionAPI, wasmPath: string, modelPath: string) {
  const scope = self as unknown as {
    onmessage: (event: MessageEvent<WorkerRequest>) => void;
    postMessage: (message: WorkerResponse) => void;
    close: () => void;
  };
  let task: HandLandmarker | null = null;

  scope.onmessage = async ({ data }) => {
    try {
      if (data.type === "init") {
        const fileset = await api.FilesetResolver.forVisionTasks(wasmPath);
        const options = {
          runningMode: "VIDEO",
          numHands: 2,
          minHandDetectionConfidence: 0.5,
          minHandPresenceConfidence: 0.45,
          minTrackingConfidence: 0.5,
        } as const;
        try {
          task = await api.HandLandmarker.createFromOptions(fileset, {
            ...options, canvas: new OffscreenCanvas(1, 1),
            baseOptions: { modelAssetPath: modelPath, delegate: "GPU" },
          });
        } catch {
          task = await api.HandLandmarker.createFromOptions(fileset, {
            ...options, canvas: new OffscreenCanvas(1, 1),
            baseOptions: { modelAssetPath: modelPath, delegate: "CPU" },
          });
        }
        scope.postMessage({ type: "ready" });
      } else if (data.type === "frame") {
        try {
          if (!task) throw new Error("Hand tracker not initialized");
          const started = performance.now();
          const result = task.detectForVideo(data.bitmap, data.timestamp);
          scope.postMessage({
            type: "result",
            frame: {
              timestamp: data.timestamp,
              inferenceMs: performance.now() - started,
              hands: result.landmarks.map((landmarks, i) => ({
                id: result.handedness[i]?.[0]?.categoryName ?? `hand-${i}`,
                confidence: result.handedness[i]?.[0]?.score ?? 0,
                landmarks,
                worldLandmarks: result.worldLandmarks[i] ?? [],
              })),
            },
          });
        } finally {
          data.bitmap.close();
        }
      } else {
        task?.close();
        scope.close();
      }
    } catch (error) {
      scope.postMessage({
        type: "error",
        message: error instanceof Error ? error.message : String(error),
      });
    }
  };
}

export function createHandWorker(): { worker: Worker; url: string } {
  // Classic inline worker keeps MediaPipe's importScripts compatible with Vite and single-file builds.
  const source = `var exports = {};\n${visionBundle}\n(${runWorker.toString()})(exports, ${JSON.stringify(VISION_WASM)}, ${JSON.stringify(HAND_MODEL)});`;
  const url = URL.createObjectURL(new Blob([source], { type: "text/javascript" }));
  try {
    return { worker: new Worker(url), url };
  } catch (error) {
    URL.revokeObjectURL(url);
    throw error;
  }
}