import type { HandLandmarker } from "@mediapipe/tasks-vision";
import { createHandWorker, HAND_MODEL, VISION_WASM } from "./hand-worker";
import { DEFAULT_HAND_OPTIONS, type HandFrame, type HandOptions, type HandTrackingState, type WorkerResponse } from "./tracking-types";

export class CameraHandTracker {
  private video: HTMLVideoElement;
  private worker: Worker | null = null;
  private workerUrl: string | null = null;
  private fallback: HandLandmarker | null = null;
  private starting = false;
  private fallbackStarting = false;
  private disposed = false;
  private busy = false;
  private ready = false;
  private lastVideoTime = -1;
  private lastDetection = 0;
  private inferenceAverage = 25;
  private initializationTimer: ReturnType<typeof setTimeout> | null = null;

  constructor(
    video: HTMLVideoElement,
    private onFrame: (frame: HandFrame) => void,
    private onState: (state: HandTrackingState) => void,
  ) {
    this.video = video;
  }

  options: HandOptions = { ...DEFAULT_HAND_OPTIONS };

  configure(options: HandOptions) { this.options = { ...options }; }

  start() {
    if (this.starting || this.disposed) return;
    this.starting = true;
    this.onState({ status: "loading", count: 0, message: "Carregando rastreamento da m\u00e3o..." });
    if (typeof Worker === "undefined" || typeof OffscreenCanvas === "undefined" || typeof createImageBitmap === "undefined") {
      void this.startFallback();
      return;
    }

    try {
      const { worker, url } = createHandWorker();
      this.worker = worker;
      this.workerUrl = url;
      worker.onmessage = ({ data }: MessageEvent<WorkerResponse>) => {
        if (this.disposed || this.worker !== worker) return;
        if (data.type === "ready") {
          this.clearTimer();
          this.ready = true;
          this.onState({ status: "ready", count: 0, message: "Mostre a m\u00e3o inteira para a c\u00e2mera." });
        } else if (data.type === "result") {
          this.busy = false;
          this.publish(data.frame);
        } else {
          void this.startFallback();
        }
      };
      worker.onerror = (event) => {
        event.preventDefault();
        void this.startFallback();
      };
      worker.postMessage({ type: "init" });
      this.initializationTimer = setTimeout(() => void this.startFallback(), 20000);
    } catch {
      void this.startFallback();
    }
  }

  tick(time: number) {
    if (this.disposed || !this.ready || document.hidden) return;
    if (this.busy) {
      if (time - this.lastDetection > 3000) void this.startFallback();
      return;
    }
    if (this.video.readyState < 2 || this.video.videoWidth === 0) return;
    if (this.video.currentTime === this.lastVideoTime) return;
    const interval = this.fallback ? Math.max(65, this.inferenceAverage * 1.4) :
      Math.max(1000 / this.options.fps, this.inferenceAverage * 1.05);
    if (time - this.lastDetection < interval) return;
    this.lastVideoTime = this.video.currentTime;
    this.lastDetection = time;

    if (this.fallback) {
      try {
        const start = performance.now();
        const result = this.fallback.detectForVideo(this.video, time);
        this.publish({
          timestamp: time,
          inferenceMs: performance.now() - start,
          hands: result.landmarks.map((landmarks, i) => ({
            id: result.handedness[i]?.[0]?.categoryName ?? `hand-${i}`,
            confidence: result.handedness[i]?.[0]?.score ?? 0,
            landmarks,
            worldLandmarks: result.worldLandmarks[i] ?? [],
          })),
        });
      } catch {
        this.fail();
      }
      return;
    }

    const worker = this.worker;
    if (!worker) return;
    this.busy = true;
    const resizeWidth = Math.min(this.options.resolution, this.video.videoWidth);
    const resizeHeight = Math.round(resizeWidth * this.video.videoHeight / this.video.videoWidth);
    void createImageBitmap(this.video, { resizeWidth, resizeHeight, resizeQuality: "low" })
      .then((bitmap) => {
        if (this.disposed || this.worker !== worker) {
          bitmap.close();
          this.busy = false;
          return;
        }
        try {
          worker.postMessage({ type: "frame", bitmap, timestamp: time }, [bitmap]);
        } catch (error) {
          bitmap.close();
          throw error;
        }
      })
      .catch(() => {
        this.busy = false;
        void this.startFallback();
      });
  }

  private publish(frame: HandFrame) {
    this.inferenceAverage = this.inferenceAverage * 0.85 + (frame.inferenceMs ?? 25) * 0.15;
    this.onFrame(frame);
  }

  private async startFallback() {
    if (this.disposed || this.fallback || this.fallbackStarting) return;
    this.fallbackStarting = true;
    this.clearWorker();
    this.ready = false;
    this.busy = false;
    this.onFrame({ hands: [], timestamp: performance.now() });
    this.onState({ status: "loading", count: 0, message: "Adaptando o Hand para este navegador..." });
    try {
      const { FilesetResolver, HandLandmarker } = await import("@mediapipe/tasks-vision");
      const fileset = await FilesetResolver.forVisionTasks(VISION_WASM);
      if (this.disposed) return;
      const options = {
        runningMode: "VIDEO" as const,
        numHands: 2,
        minHandDetectionConfidence: 0.5,
        minHandPresenceConfidence: 0.45,
        minTrackingConfidence: 0.5,
      };
      let task: HandLandmarker;
      try {
        task = await HandLandmarker.createFromOptions(fileset, {
          ...options,
          baseOptions: { modelAssetPath: HAND_MODEL, delegate: "GPU" },
        });
      } catch {
        if (this.disposed) return;
        task = await HandLandmarker.createFromOptions(fileset, {
          ...options,
          baseOptions: { modelAssetPath: HAND_MODEL, delegate: "CPU" },
        });
      }
      if (this.disposed) {
        task.close();
        return;
      }
      this.fallback = task;
      this.ready = true;
      this.onState({ status: "ready", count: 0, message: "Mostre a m\u00e3o inteira para a c\u00e2mera." });
    } catch {
      if (!this.disposed) this.fail();
    } finally {
      this.fallbackStarting = false;
    }
  }

  private fail() {
    this.ready = false;
    this.onFrame({ hands: [], timestamp: performance.now() });
    this.onState({ status: "error", count: 0, message: "N\u00e3o foi poss\u00edvel carregar o Hand. Verifique a internet e tente novamente." });
  }

  private clearTimer() {
    if (this.initializationTimer !== null) clearTimeout(this.initializationTimer);
    this.initializationTimer = null;
  }

  private clearWorker() {
    this.clearTimer();
    this.worker?.terminate();
    this.worker = null;
    if (this.workerUrl) URL.revokeObjectURL(this.workerUrl);
    this.workerUrl = null;
  }

  dispose() {
    this.disposed = true;
    this.clearWorker();
    this.fallback?.close();
    this.fallback = null;
  }
}