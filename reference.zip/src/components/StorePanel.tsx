import { useState } from "react";
import { APPS, type AppId } from "../data/catalog";
import { gameCover, STORE_GAMES, type StoreGame } from "../data/store";
import { Icon } from "../mr/icons";

export function StorePanel({ onOpen }: { onOpen: (app: AppId) => void }) {
  const [tab, setTab] = useState("Início");
  const [selected, setSelected] = useState<StoreGame | null>(null);
  const [query, setQuery] = useState("");
  const [wishlist, setWishlist] = useState<number[]>(() => {
    try { const stored = JSON.parse(localStorage.getItem("metamr:wishlist") ?? "[]"); return Array.isArray(stored) ? stored.filter((id) => typeof id === "number") : []; } catch { return []; }
  });
  const favorite = (id: number) => setWishlist((previous) => {
    const next = previous.includes(id) ? previous.filter((item) => item !== id) : [...previous, id];
    try { localStorage.setItem("metamr:wishlist", JSON.stringify(next)); } catch { /* Optional preferences. */ }
    return next;
  });
  const games = STORE_GAMES.filter((game) => game.name.toLowerCase().includes(query.toLowerCase()) && (tab !== "Desejos" || wishlist.includes(game.id)));
  return <section className="store-app">
    <header className="store-nav">
      <button className="store-brand" onClick={() => { setSelected(null); setTab("Início"); }}><Icon name="store" className="h-5 w-5" />Next VR<span>Store</span></button>
      <nav>{["Início", "Jogos", "Apps", "Desejos"].map((item) => <button className={tab === item ? "is-active" : ""} key={item} onClick={() => { setTab(item); setSelected(null); }}>{item}</button>)}</nav>
      <button className="store-profile" onClick={() => onOpen("contacts")} title="Pessoas"><Icon name="person" className="h-4 w-4" /></button>
    </header>
    {selected ? <div className="store-detail" data-scroll>
      <button className="app-back" onClick={() => setSelected(null)}><Icon name="back" className="h-4 w-4" />Voltar à loja</button>
      <img className="store-detail-cover" src={gameCover(selected.id, true)} alt={selected.name} />
      <div className="store-detail-heading"><div><h1>{selected.name}</h1><p>{selected.genre}</p></div><button className={`favorite-button ${wishlist.includes(selected.id) ? "is-active" : ""}`} onClick={() => favorite(selected.id)}><Icon name="heart" className="h-5 w-5" />{wishlist.includes(selected.id) ? "Salvo" : "Salvar"}</button></div>
      <p>{selected.description}</p>
      <div className="store-links"><a href={`https://www.meta.com/experiences/search/?q=${encodeURIComponent(selected.name)}`} target="_blank" rel="noopener" className="mr-primary">Consultar loja oficial<Icon name="external" className="h-4 w-4" /></a><a href={`https://store.steampowered.com/app/${selected.id}/`} target="_blank" rel="noopener" className="mr-secondary">Ver no Steam<Icon name="external" className="h-4 w-4" /></a></div>
      <p className="app-footnote">Catálogo de descoberta. Estes jogos exigem um dispositivo compatível; não são instalados nem executados pelo Next VR no Android. Preço, disponibilidade e compra são confirmados na loja oficial.</p>
    </div> : <div className="store-content" data-scroll>
      <div className="store-search"><Icon name="search" className="h-4 w-4" /><input inputMode="none" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Buscar na loja" aria-label="Buscar na loja" /></div>
      {tab === "Apps" ? <>
        <div className="section-heading"><h2>Essenciais do seu espaço</h2><span>Apps integrados</span></div>
        <div className="store-integrated">{APPS.filter((app) => ["youtube", "browser", "gallery", "worlds", "settings", "multitask"].includes(app.id)).map((app) => <button key={app.id} onClick={() => onOpen(app.id)}><span style={{ background: `linear-gradient(140deg, ${app.color}, ${app.color2})` }}><Icon name={app.icon} className="h-8 w-8" /></span><h3>{app.name}</h3><p>Abrir no Next VR</p></button>)}</div>
      </> : <>
        <div className="section-heading"><h2>{tab === "Desejos" ? "Sua lista de desejos" : "Explore a realidade virtual"}</h2><span>{games.length} experiências</span></div>
        <div className="store-ranking">{games.map((game, index) => <button key={game.id} onClick={() => setSelected(game)} className="store-rank-item">
          <div className="store-rank-image" style={{ background: game.color }}><img src={gameCover(game.id)} alt="" loading="lazy" onError={(event) => { event.currentTarget.style.opacity = "0"; }} /></div>
          <div><h3><small>{index + 1}.</small>{game.name}</h3><p>{game.genre}</p><span>Ver detalhes <Icon name="chevron" className="h-3 w-3" /></span></div>
        </button>)}</div>
        {!games.length && <div className="mr-empty"><Icon name="heart" className="h-9 w-9" /><h2>{tab === "Desejos" ? "Guarde o que chamou sua atenção." : "Nenhum resultado"}</h2><p>Abra uma experiência e toque em Salvar.</p></div>}
        {tab !== "Desejos" && !query && <>
          <div className="section-heading"><h2>Entre em outra realidade</h2><button onClick={() => setTab("Jogos")}>Ver tudo <Icon name="chevron" className="h-3 w-3" /></button></div>
          <div className="store-carousel">{STORE_GAMES.slice(4, 9).map((game) => <button key={game.id} onClick={() => setSelected(game)}><img src={gameCover(game.id, true)} alt="" loading="lazy" /><h3>{game.name}</h3><p>{game.genre}</p></button>)}</div>
        </>}
      </>}
      <p className="store-disclaimer">Descoberta de jogos VR. Sem compras simuladas ou instalação de APKs. Imagens dos respectivos jogos.</p>
    </div>}
  </section>;
}