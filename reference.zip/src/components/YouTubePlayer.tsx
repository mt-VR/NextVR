import { useEffect, useRef, useState } from "react";
import { Icon } from "../mr/icons";
import {
  loadYouTubePlayerAPI, youtubeEmbedUrl, youtubePlayerError, youtubeWatchUrl,
  type YouTubePlayerInstance, type YouTubeSelection,
} from "../lib/youtube";

function timeLabel(seconds: number) {
  if (!Number.isFinite(seconds) || seconds < 0) return "0:00";
  const h = Math.floor(seconds / 3600);
  const m = Math.floor(seconds / 60) % 60;
  const s = String(Math.floor(seconds) % 60).padStart(2, "0");
  return h ? `${h}:${String(m).padStart(2, "0")}:${s}` : `${m}:${s}`;
}

export function YouTubePlayer({ selection, hidden = false }: { selection: YouTubeSelection; hidden?: boolean }) {
  const holder = useRef<HTMLDivElement>(null);
  const player = useRef<YouTubePlayerInstance | null>(null);
  const [ready, setReady] = useState(false);
  const [state, setState] = useState(-1);
  const [muted, setMuted] = useState(false);
  const [notice, setNotice] = useState("");
  const [error, setError] = useState("");
  const [progress, setProgress] = useState({ time: 0, duration: 0 });
  const [retry, setRetry] = useState(0);
  const selectionRef = useRef(selection);
  const hiddenRef = useRef(hidden);
  selectionRef.current = selection;
  hiddenRef.current = hidden;

  useEffect(() => {
    const container = holder.current;
    if (!container) return;
    let disposed = false;
    let instance: YouTubePlayerInstance | null = null;
    let observer: ResizeObserver | null = null;
    setReady(false);
    setError("");
    setNotice("");
    setState(-1);
    setProgress({ time: 0, duration: 0 });
    const iframe = document.createElement("iframe");
    iframe.title = "Player oficial do YouTube";
    iframe.src = youtubeEmbedUrl(selectionRef.current);
    iframe.allow = "autoplay; encrypted-media; picture-in-picture; fullscreen; clipboard-write";
    iframe.allowFullscreen = true;
    iframe.referrerPolicy = "strict-origin-when-cross-origin";
    Object.assign(iframe.style, { width: "100%", height: "100%", border: "0", display: "block" });
    container.replaceChildren(iframe);

    const delayedNotice = window.setTimeout(() => {
      if (!disposed) setNotice("Se o v\u00eddeo n\u00e3o iniciar, toque no Play do player. Verifique tamb\u00e9m bloqueadores de conte\u00fado.");
    }, 16000);

    void loadYouTubePlayerAPI().then((api) => {
      if (disposed) return;
      instance = new api.Player(iframe, {
        events: {
          onReady: (event) => {
            if (disposed) return;
            player.current = event.target;
            clearTimeout(delayedNotice);
            setReady(true);
            setNotice("");
            setMuted(event.target.isMuted());
            if (hiddenRef.current) event.target.pauseVideo();
            const resize = () => {
              if (!container.clientWidth || !container.clientHeight) return;
              event.target.setSize(container.clientWidth, container.clientHeight);
            };
            resize();
            observer = new ResizeObserver(resize);
            observer.observe(container);
          },
          onStateChange: (event) => {
            if (disposed) return;
            setState(event.data);
            if (event.data === 1) { setNotice(""); setError(""); }
          },
          onError: (event) => {
            if (disposed) return;
            clearTimeout(delayedNotice);
            setError(youtubePlayerError(event.data));
            setNotice("");
          },
          onAutoplayBlocked: () => {
            if (!disposed) setNotice("Toque em Play para iniciar. Seu navegador bloqueou a reprodu\u00e7\u00e3o autom\u00e1tica.");
          },
        },
      });
    }).catch((failure: unknown) => {
      if (!disposed) setNotice(failure instanceof Error ? failure.message : "Use os controles do player.");
    });

    return () => {
      disposed = true;
      clearTimeout(delayedNotice);
      observer?.disconnect();
      player.current = null;
      try { instance?.destroy(); } catch { /* The iframe may already have been removed. */ }
      container.replaceChildren();
    };
  }, [selection.videoId, selection.playlistId, selection.startSeconds, retry]);

  useEffect(() => {
    if (!ready || hidden) return;
    const timer = setInterval(() => {
      const current = player.current;
      if (!current) return;
      setProgress({ time: current.getCurrentTime(), duration: current.getDuration() });
      setMuted(current.isMuted());
      if (document.querySelector(".stereo-mode")) document.dispatchEvent(new CustomEvent("metamr:playback", {
        detail: { source: holder.current?.querySelector("iframe"), time: current.getCurrentTime(), state: current.getPlayerState() },
      }));
    }, 750);
    return () => clearInterval(timer);
  }, [ready, hidden]);

  useEffect(() => {
    if (hidden && ready) player.current?.pauseVideo();
  }, [hidden, ready]);

  const playing = state === 1;
  return (
    <div className="yt-player-block">
      <div ref={holder} className="yt-player-surface" />
      <div className="yt-playback-controls">
        <button type="button" className="yt-control" disabled={!ready || !!error}
          title={playing ? "Pausar" : "Reproduzir"} aria-label={playing ? "Pausar" : "Reproduzir"}
          onClick={() => playing ? player.current?.pauseVideo() : player.current?.playVideo()}>
          <Icon name={playing ? "pause" : "play"} className="h-4 w-4" />
        </button>
        <button type="button" className="yt-control yt-skip" disabled={!ready || !!error} title="Voltar 10 segundos"
          onClick={() => { const p = player.current; if (p) p.seekTo(Math.max(0, p.getCurrentTime() - 10), true); }}>
          <Icon name="rewind" className="h-4 w-4" /><span>10</span>
        </button>
        <button type="button" className="yt-control yt-skip" disabled={!ready || !!error} title="Avan&#231;ar 10 segundos"
          onClick={() => { const p = player.current; if (p) p.seekTo(p.getCurrentTime() + 10, true); }}>
          <Icon name="forward" className="h-4 w-4" /><span>10</span>
        </button>
        <div className="yt-progress-readout" aria-live="off">{timeLabel(progress.time)} / {timeLabel(progress.duration)}</div>
        <div className="flex-1" />
        <button type="button" className="yt-control" disabled={!ready} title={muted ? "Ativar som" : "Silenciar"}
          aria-label={muted ? "Ativar som" : "Silenciar"}
          onClick={() => { const p = player.current; if (p) { if (p.isMuted()) p.unMute(); else p.mute(); setMuted(p.isMuted()); } }}>
          <Icon name={muted ? "muted" : "volume"} className="h-4 w-4" />
        </button>
        <a className="yt-control" href={youtubeWatchUrl(selection)} target="_blank" rel="noopener" title="Abrir no YouTube">
          <Icon name="external" className="h-4 w-4" />
        </a>
      </div>
      {(error || notice) && <div className={`yt-player-notice ${error ? "is-error" : ""}`} role={error ? "alert" : "status"}>
        <p>{error || notice}</p>
        {error && <button type="button" onClick={() => setRetry((value) => value + 1)}>Tentar novamente</button>}
        <a href={youtubeWatchUrl(selection)} target="_blank" rel="noopener">Assistir no YouTube <Icon name="external" className="h-3 w-3" /></a>
      </div>}
      {!error && <p className="yt-embed-disclosure">Alguns autores, v&iacute;deos privados e restri&ccedil;&otilde;es de idade exigem assistir no pr&oacute;prio YouTube.</p>}
    </div>
  );
}