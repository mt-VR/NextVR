import { Icon } from "../mr/icons";

export function HUD({
  onExit,
  onRecenter,
  pointer,
  pointerVisible = true,
  cardboard,
  minimal = false,
  stereo = false,
}: {
  onExit: () => void;
  onRecenter: () => void;
  pointer: { x: number; y: number };
  pointerVisible?: boolean;
  cardboard: boolean;
  minimal?: boolean;
  stereo?: boolean;
}) {
  return (
    <>
      {!minimal && <div className="pointer-events-none absolute inset-x-0 top-4 z-50 flex justify-center" data-hud>
        <div className="pointer-events-auto flex items-center gap-2 rounded-[22px] border border-white/10 bg-black/45 p-1.5 backdrop-blur-xl">
          <button className="hud-chip primary" onClick={onExit}>
            Sair do Cardboard
          </button>
          <button className="hud-chip inline-flex items-center gap-2" onClick={onRecenter}>
            <span className="grid h-4 w-4 place-items-center rounded-full border-2 border-white/80">
              <span className="h-1.5 w-1.5 rounded-full bg-white" />
            </span>
            Recentralizar
          </button>
        </div>
      </div>}

      {(pointerVisible || cardboard) && <div
        className="reticle"
        style={{
          left: cardboard ? "50%" : pointer.x,
          top: cardboard ? "50%" : pointer.y,
          opacity: cardboard ? 1 : 0.9,
        }}
      />}
      {stereo && pointerVisible && <div className="reticle reticle-right" style={{ left: `calc(50% + ${pointer.x}px)`, top: pointer.y }} aria-hidden="true" />}

      {!minimal && <div className="pointer-events-none absolute bottom-4 left-4 z-40 hidden rounded-xl border border-white/10 bg-black/40 px-3 py-1.5 text-[10px] font-medium tracking-wide text-white/55 backdrop-blur-md md:block">
        3DOF · WORLD LOCK · KALMAN · 1€ FILTER
      </div>}
    </>
  );
}

export function SideFabs({
  onLayers,
  onShare,
}: {
  onLayers: () => void;
  onShare: () => void;
}) {
  return (
    <div className="flex flex-col gap-3">
      <button
        onClick={onLayers}
        className="grid h-16 w-[72px] place-items-center rounded-[22px] border border-white/10 bg-black/55 text-white backdrop-blur-xl hover:bg-black/70"
      >
        <Icon name="layers" className="h-6 w-6" />
      </button>
      <button
        onClick={onShare}
        className="grid h-16 w-[72px] place-items-center rounded-[22px] border border-white/10 bg-black/55 text-white backdrop-blur-xl hover:bg-black/70"
      >
        <Icon name="share" className="h-6 w-6" />
      </button>
    </div>
  );
}
