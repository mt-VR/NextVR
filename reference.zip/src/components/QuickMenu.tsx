import { Icon } from "../mr/icons";
import type { NextLanguage } from "../lib/preferences";
import { LOCALE_LABELS, tr } from "../lib/i18n";

export function QuickMenu({
  language, battery, online, hands, recents, onClose, onRecenter, onOpen, onHands, onLanguage,
}: {
  language: NextLanguage; battery: number; online: boolean; hands: boolean;
  recents: { id: string; kind: string; title: string; minimized: boolean }[];
  onClose: () => void; onRecenter: () => void; onOpen: (kind: string) => void;
  onHands: () => void; onLanguage: () => void;
}) {
  return <section className="quick-menu" data-scroll>
    <header><div><span className="quick-n">N</span><div><small>NEXT VR</small><h1>{tr(language, "menu")}</h1></div></div><button className="close-red" onClick={onClose} aria-label={tr(language, "close")}><Icon name="close" className="h-4 w-4" /></button></header>
    <div className="quick-status"><div><Icon name="wifi" className="h-4 w-4" /><span>{online ? tr(language, "connected") : "Offline"}</span></div><div><Icon name="battery" className="h-4 w-4" /><span>{battery >= 0 ? `${battery}%` : "--"}</span></div><div><Icon name="layers" className="h-4 w-4" /><span>{tr(language, "fixed")}</span></div></div>
    <div className="quick-grid">
      <button onClick={onRecenter}><span><Icon name="recenter" className="h-6 w-6" /></span><strong>{tr(language, "recenter")}</strong><small>Visão atual</small></button>
      <button onClick={() => onOpen("settings")}><span><Icon name="gear" className="h-6 w-6" /></span><strong>{tr(language, "settings")}</strong><small>{tr(language, "general")}</small></button>
      <button onClick={() => onOpen("gallery")}><span><Icon name="photo" className="h-6 w-6" /></span><strong>{tr(language, "gallery")}</strong><small>Fotos</small></button>
      <button onClick={() => onOpen("worlds")}><span><Icon name="world" className="h-6 w-6" /></span><strong>{tr(language, "environments")}</strong><small>3D</small></button>
      <button onClick={onLanguage}><span><b>{LOCALE_LABELS[language].flag}</b></span><strong>{tr(language, "language")}</strong><small>{LOCALE_LABELS[language].native}</small></button>
      <button onClick={onHands} className={hands ? "is-active" : ""}><span><Icon name="hand" className="h-6 w-6" /></span><strong>{tr(language, "handTracking")}</strong><small>{hands ? "Ativo" : "Desativado"}</small></button>
    </div>
    <div className="quick-recents"><div><h2>{tr(language, "recentApps")}</h2><button onClick={() => onOpen("apps")}>{tr(language, "apps")}<Icon name="chevron" className="h-3 w-3" /></button></div>
      {recents.length ? <div className="quick-recent-list">{recents.slice(-3).reverse().map((app) => <button key={app.id} onClick={() => onOpen(app.kind)}><Icon name="square" className="h-4 w-4" /><span>{app.title}</span><small>{app.minimized ? "Minimizado" : "Aberto"}</small></button>)}</div> : <p>{tr(language, "noRecent")}</p>}
    </div>
    <div className="quick-grab"><div className="grab-bar" data-grab="quick-menu" /></div>
  </section>;
}