import { useState } from "react";
import {
  APPS,
  CONTACTS,
  SETTINGS_TILES,
  WIFI_NETWORKS,
  type AppId,
} from "../data/catalog";
import { Icon } from "../mr/icons";
import type { HandTrackingState } from "../mr/tracking-types";

export function SettingsGrid({
  onOpen,
  query,
  setQuery,
}: {
  onOpen: (id: AppId) => void;
  query: string;
  setQuery: (s: string) => void;
}) {
  const tiles = SETTINGS_TILES.filter(
    (t) =>
      !query ||
      t.name.toLowerCase().includes(query.toLowerCase()) ||
      t.subtitle.toLowerCase().includes(query.toLowerCase()),
  );
  return (
    <div className="p-4">
      <div className="mb-3 flex items-center justify-between px-1">
        <div className="flex items-center gap-2 rounded-full bg-black/35 px-3 py-1.5 text-white/55">
          <Icon name="search" className="h-4 w-4" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search Settings"
            className="w-40 bg-transparent text-[13px] outline-none placeholder:text-white/35"
          />
        </div>
        <button className="grid h-8 w-8 place-items-center rounded-full text-white/50 hover:bg-white/10">
          <Icon name="close" className="h-4 w-4" />
        </button>
      </div>
      <div className="grid grid-cols-4 gap-2.5">
        {tiles.map((t) => (
          <button key={t.id} className="tile p-4 text-left" onClick={() => onOpen(t.id)}>
            <div className="mb-6 text-white/90">
              <Icon name={t.icon} className="h-6 w-6" />
            </div>
            <div className="text-[15px] font-semibold">{t.name}</div>
            <div className="mt-0.5 text-[11px] leading-snug text-white/45">{t.subtitle}</div>
          </button>
        ))}
      </div>
      <div className="mt-3 flex justify-center">
        <div className="hint-pill text-[12px]">Olhe para um cartão e toque para selecionar</div>
      </div>
    </div>
  );
}

export function AppsLibrary({ onOpen }: { onOpen: (id: AppId) => void }) {
  const [tab, setTab] = useState<"All" | "Recent" | "Installed">("All");
  const list = tab === "Recent" ? APPS.slice(0, 8) : APPS;
  return (
    <div className="p-5">
      <div className="mb-4 flex items-end justify-between">
        <div>
          <div className="flex items-center gap-2 text-white/40">
            <Icon name="search" className="h-4 w-4" />
            <span className="text-sm">Search</span>
          </div>
          <div className="mt-2 flex gap-4 text-[13px] text-white/40">
            {(["All", "Recent", "Installed"] as const).map((t) => (
              <button
                key={t}
                onClick={() => setTab(t)}
                className={t === tab ? "font-semibold text-white" : ""}
              >
                {t}
              </button>
            ))}
          </div>
        </div>
        <div className="text-xl font-semibold">Apps</div>
      </div>
      <div className="grid grid-cols-3 gap-3">
        {list.map((a) => (
          <button
            key={a.id}
            onClick={() => onOpen(a.id)}
            className="app-icon relative aspect-[1.35] flex-col gap-2 p-3"
            style={{ background: `linear-gradient(160deg, ${a.color}, ${a.color2 ?? a.color})` }}
          >
            <Icon name={a.icon} className="h-8 w-8" />
            <span className="text-[13px] font-semibold">{a.name}</span>
          </button>
        ))}
      </div>
      <div className="mt-4 flex justify-center gap-5 text-white/50">
        <Icon name="home" className="h-5 w-5" />
        <Icon name="square" className="h-5 w-5" />
        <Icon name="grid" className="h-5 w-5" />
        <Icon name="gear" className="h-5 w-5" />
      </div>
    </div>
  );
}

export function ContactsPanel() {
  const online = CONTACTS.filter((c) => c.online).length;
  return (
    <div className="p-4">
      <div className="mb-3 flex items-center justify-between px-1">
        <div className="text-[16px] font-semibold">Pessoas <span className="text-[10px] text-white/35">contatos de demonstração</span></div>
        <Icon name="search" className="h-4 w-4 text-white/40" />
      </div>
      <div className="space-y-0.5">
        {CONTACTS.map((c) => (
          <div key={c.id} className="contact-row">
            <div
              className="grid h-9 w-9 place-items-center rounded-full text-[13px] font-bold text-[#1b1e24]"
              style={{ background: c.color }}
            >
              {c.letter}
            </div>
            <div className="min-w-0 flex-1">
              <div className="truncate text-[13px] font-medium">{c.name}</div>
              <div className="text-[10px] text-white/40">{c.status}</div>
            </div>
            <span className={`h-2 w-2 rounded-full ${c.online ? "bg-emerald-400" : "bg-white/20"}`} />
          </div>
        ))}
      </div>
      <div className="mt-3 px-1 text-[11px] text-white/40">{online} perfis ilustrativos. Nenhuma conta ou contato real é acessado.</div>
    </div>
  );
}

const BROWSER_HOME = `<!doctype html><html><head><meta charset="utf-8"/><style>
  body{margin:0;font-family:Inter,system-ui;background:#0e1116;color:#e8eaef;padding:28px}
  h1{font-size:22px;margin:0 0 8px} p{color:#9aa3b2}
  a{color:#7dd3fc;display:block;margin:8px 0;text-decoration:none}
</style></head><body>
<h1>Browser espacial</h1>
<p>Digite um URL acima. Alguns sites bloqueiam iframe.</p>
<a href="https://example.com">example.com</a>
<a href="https://www.openstreetmap.org">OpenStreetMap</a>
</body></html>`;

export function BrowserPanel() {
  const [url, setUrl] = useState("horizon://home");
  const [src, setSrc] = useState(BROWSER_HOME);
  const [mode, setMode] = useState<"html" | "url">("html");
  return (
    <div className="p-3">
      <form
        className="mb-2 flex items-center gap-2 rounded-full bg-black/40 px-3 py-1.5"
        onSubmit={(e) => {
          e.preventDefault();
          let u = url.trim();
          if (u.startsWith("horizon://")) {
            setMode("html");
            setSrc(BROWSER_HOME);
            return;
          }
          if (!/^https?:\/\//i.test(u)) u = "https://" + u;
          setMode("url");
          setSrc(u);
        }}
      >
        <Icon name="globe" className="h-4 w-4 text-white/40" />
        <input
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          className="w-full bg-transparent text-[13px] outline-none"
        />
        <button className="text-[12px] font-semibold text-sky-300">Abrir</button>
      </form>
      <div className="overflow-hidden rounded-2xl bg-[#0e1116]">
        {mode === "html" ? (
          <iframe title="browser" srcDoc={src} className="h-[420px] w-full bg-[#0e1116]" />
        ) : (
          <iframe title="browser" src={src} className="h-[420px] w-full bg-white" />
        )}
      </div>
    </div>
  );
}

export function StoragePanel() {
  return (
    <div className="p-6">
      <div className="text-lg font-semibold">Storage</div>
      <p className="mt-1 text-sm text-white/50">53.85 GB free of 256.00 GB</p>
      <div className="mt-4 h-3 overflow-hidden rounded-full bg-white/10">
        <div className="h-full w-[79%] rounded-full bg-gradient-to-r from-sky-400 to-indigo-500" />
      </div>
      <div className="mt-5 space-y-2 text-sm">
        {[
          ["Apps", "86.2 GB", 34],
          ["Media", "41.0 GB", 16],
          ["System", "18.4 GB", 8],
          ["Other", "56.5 GB", 21],
        ].map(([n, s, w]) => (
          <div key={n as string} className="flex items-center gap-3">
            <div className="w-20 text-white/60">{n}</div>
            <div className="h-2 flex-1 rounded-full bg-white/8">
              <div className="h-full rounded-full bg-white/35" style={{ width: `${w}%` }} />
            </div>
            <div className="w-16 text-right text-white/45">{s}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

export function WifiPanel() {
  return (
    <div className="p-5">
      <div className="mb-4 text-lg font-semibold">Wi-Fi</div>
      <div className="space-y-1">
        {WIFI_NETWORKS.map((n) => (
          <div key={n.ssid} className="tile flex items-center gap-3 px-4 py-3">
            <Icon name="wifi" className="h-5 w-5" />
            <div className="flex-1">
              <div className="text-sm font-medium">{n.ssid}</div>
              <div className="text-[11px] text-white/40">
                {n.connected ? "Conectado · VR" : n.secure ? "Segura" : "Aberta"}
              </div>
            </div>
            {n.connected && <span className="text-[11px] text-emerald-400">Ativo</span>}
          </div>
        ))}
      </div>
    </div>
  );
}

export function ToggleRow({
  label,
  sub,
  on,
  setOn,
}: {
  label: string;
  sub?: string;
  on: boolean;
  setOn: (v: boolean) => void;
}) {
  return (
    <button className="tile flex w-full items-center gap-3 px-4 py-3 text-left" onClick={() => setOn(!on)}>
      <div className="flex-1">
        <div className="text-sm font-medium">{label}</div>
        {sub && <div className="text-[11px] text-white/40">{sub}</div>}
      </div>
      <div className={`h-6 w-11 rounded-full p-0.5 transition ${on ? "bg-sky-400" : "bg-white/15"}`}>
        <div className={`h-5 w-5 rounded-full bg-white transition ${on ? "translate-x-5" : ""}`} />
      </div>
    </button>
  );
}

export function SystemPanel({
  passthrough,
  setPassthrough,
  dnd,
  setDnd,
}: {
  passthrough: boolean;
  setPassthrough: (v: boolean) => void;
  dnd: boolean;
  setDnd: (v: boolean) => void;
}) {
  const [voice, setVoice] = useState(true);
  return (
    <div className="space-y-2 p-5">
      <div className="mb-2 text-lg font-semibold">System</div>
      <ToggleRow label="Passthrough" sub="Ver o mundo real" on={passthrough} setOn={setPassthrough} />
      <ToggleRow label="Voice Commands" sub="Comandos de voz" on={voice} setOn={setVoice} />
      <ToggleRow label="Do Not Disturb" on={dnd} setOn={setDnd} />
      <div className="tile px-4 py-3 text-sm text-white/70">Power · Reiniciar · Desligar headset</div>
    </div>
  );
}

export function HandsPanel({
  tracking,
  setTracking,
  state,
  onRetry,
}: {
  tracking: boolean;
  setTracking: (v: boolean) => void;
  state: HandTrackingState;
  onRetry: () => void;
}) {
  return (
    <div className="space-y-2 p-5">
      <div className="mb-2 text-lg font-semibold">Hands and Controllers</div>
      <ToggleRow
        label="Hand Tracking"
        sub="Sua mão real, rastreada pela câmera"
        on={tracking}
        setOn={setTracking}
      />
      <div className="flex items-start gap-2 px-1 pt-3 text-[12px]" role="status" aria-live="polite">
        <span className={`mt-1 h-1.5 w-1.5 shrink-0 rounded-full ${
          state.status === "tracking" ? "bg-emerald-400" :
          state.status === "error" || state.status === "camera-required" ? "bg-amber-400" : "bg-white/40"
        }`} />
        <p className="leading-relaxed text-white/65">{state.message}</p>
      </div>
      {(state.status === "error" || state.status === "camera-required") && (
        <button onClick={onRetry} className="mt-2 rounded-xl bg-sky-400/15 px-4 py-2 text-[12px] font-semibold text-sky-200 hover:bg-sky-400/25">
          Permitir câmera / Tentar novamente
        </button>
      )}
      <p className="px-1 pt-2 text-[12px] leading-relaxed text-white/45">
        Mostre a mão inteira para a câmera. A palma, o pulso e todos os dedos acompanham sua mão,
        inclusive de ponta-cabeça. Aponte para a barrinha branca, faça pinça e mova a mão para
        arrastar a janela. Abra a pinça para soltar.
      </p>
      <p className="px-1 pt-1 text-[11px] leading-relaxed text-white/35">
        Sem uma mão detectada, o Hand fica invisível. Toque e mouse continuam disponíveis,
        mas não controlam a mão virtual. O processamento acontece no navegador; internet é
        necessária para carregar o modelo na primeira utilização. A profundidade é estimada
        pela câmera, não pelo rastreamento nativo do Quest.
      </p>
    </div>
  );
}

export function PersonalizationPanel({
  env,
  setEnv,
}: {
  env: "passthrough" | "horizon";
  setEnv: (e: "passthrough" | "horizon") => void;
}) {
  return (
    <div className="p-5">
      <div className="mb-3 text-lg font-semibold">Personalization</div>
      <p className="mb-3 text-[12px] text-white/45">Virtual Environment</p>
      <div className="grid grid-cols-2 gap-3">
        <button
          onClick={() => setEnv("horizon")}
          className={`tile overflow-hidden p-0 ${env === "horizon" ? "ring-2 ring-white/50" : ""}`}
        >
          <div className="h-24 bg-gradient-to-b from-orange-700 to-amber-900" />
          <div className="p-3 text-left text-sm font-medium">Next VR Home</div>
        </button>
        <button
          onClick={() => setEnv("passthrough")}
          className={`tile overflow-hidden p-0 ${env === "passthrough" ? "ring-2 ring-white/50" : ""}`}
        >
          <div className="h-24 bg-gradient-to-b from-slate-600 to-slate-900" />
          <div className="p-3 text-left text-sm font-medium">Passthrough</div>
        </button>
      </div>
    </div>
  );
}

export function GenericPanel({ title, subtitle }: { title: string; subtitle?: string }) {
  const experimental = title === "Experimental";
  return (
    <div className="p-6">
      <div className="text-lg font-semibold">{title}</div>
      {subtitle && <p className="mt-1 text-sm text-white/50">{subtitle}</p>}
      <div className="mt-4 grid gap-2">
        {experimental ? (
          <>
            <div className="tile px-4 py-3">
              <div className="text-sm font-medium">3DOF World Lock</div>
              <div className="text-[11px] text-white/40">A dock vive no mundo — não cola na tela</div>
            </div>
            <div className="tile px-4 py-3">
              <div className="text-sm font-medium">Kalman Filter</div>
              <div className="text-[11px] text-white/40">Suaviza o IMU / olhar</div>
            </div>
            <div className="tile px-4 py-3">
              <div className="text-sm font-medium">One Euro Filter</div>
              <div className="text-[11px] text-white/40">Baixa latência em movimento rápido</div>
            </div>
            <div className="tile px-4 py-3">
              <div className="text-sm font-medium">Pinça nas barrinhas brancas</div>
              <div className="text-[11px] text-white/40">Arraste janelas no espaço 3D</div>
            </div>
          </>
        ) : (
          <>
            <div className="tile px-4 py-3 text-sm">Opção 1</div>
            <div className="tile px-4 py-3 text-sm">Opção 2</div>
            <div className="tile px-4 py-3 text-sm">Opção 3</div>
          </>
        )}
      </div>
    </div>
  );
}

export function MusicPanel() {
  return (
    <div className="p-5">
      <div className="mb-4 text-lg font-semibold">Music</div>
      <div
        className="app-icon mb-4 flex aspect-[1.8] flex-col justify-end p-4"
        style={{ background: "linear-gradient(160deg,#e85aad,#7b2d8a)" }}
      >
        <Icon name="music" className="mb-3 h-10 w-10" />
        <div className="text-sm font-semibold">Next VR Mix</div>
        <div className="text-[11px] text-white/70">Spatial Audio</div>
      </div>
      <div className="flex items-center justify-center gap-5 py-2">
        <Icon name="minus" className="h-5 w-5" />
        <div className="grid h-12 w-12 place-items-center rounded-full bg-white text-black">
          <Icon name="play" className="h-5 w-5" />
        </div>
        <Icon name="plus" className="h-5 w-5" />
      </div>
    </div>
  );
}

export function GamesPanel({ onOpen }: { onOpen?: (id: AppId) => void }) {
  const games = [
    { n: "Beat Saber", c: "#5b3dff" },
    { n: "Superhot", c: "#e23b3b" },
    { n: "Walkabout", c: "#2aa0e8" },
    { n: "Eleven", c: "#3ccf7a" },
  ];
  return (
    <div className="p-5">
      <div className="mb-3 text-lg font-semibold">Games</div>
      <div className="grid grid-cols-2 gap-3">
        {games.map((g) => (
          <button
            key={g.n}
            className="app-icon aspect-[1.4] text-sm font-bold"
            style={{ background: g.c }}
            onClick={() => onOpen?.("games")}
          >
            {g.n}
          </button>
        ))}
      </div>
    </div>
  );
}

export function LauncherPanel({ onOpen }: { onOpen: (id: AppId) => void }) {
  return (
    <div className="flex gap-3 p-4">
      <div className="w-[160px] rounded-2xl bg-black/40 p-3">
        <div className="mb-2 flex items-center gap-2 rounded-full bg-white/10 px-2 py-1 text-[12px] font-semibold">
          <Icon name="grid" className="h-3.5 w-3.5" /> Todos
        </div>
        {[
          ["apps", "Apps", "grid"],
          ["games", "Jogos", "diamond"],
          ["browser", "Web", "globe"],
          ["contacts", "Pessoas", "people"],
          ["worlds", "Mundos", "spark"],
          ["store", "Loja", "store"],
        ].map(([id, n, ic]) => (
          <button
            key={id}
            onClick={() => onOpen(id as AppId)}
            className="flex w-full items-center gap-2 rounded-lg px-2 py-1.5 text-left text-[12px] text-white/70 hover:bg-white/8"
          >
            <Icon name={ic} className="h-3.5 w-3.5" /> {n}
          </button>
        ))}
      </div>
      <div className="grid flex-1 grid-cols-3 gap-3">
        {APPS.slice(8, 17).map((a) => (
          <button key={a.id} onClick={() => onOpen(a.id)} className="flex flex-col items-center gap-1.5">
            <div
              className="app-icon h-[72px] w-[72px]"
              style={{ background: `linear-gradient(160deg, ${a.color}, ${a.color2 ?? a.color})` }}
            >
              <Icon name={a.icon} className="h-7 w-7" />
            </div>
            <span className="text-[11px] font-medium text-white/80">{a.name}</span>
          </button>
        ))}
      </div>
    </div>
  );
}
