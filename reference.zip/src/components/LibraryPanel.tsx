import { useState } from "react";
import { APPS, type AppId } from "../data/catalog";
import { Icon } from "../mr/icons";
import { STORE_GAMES, gameCover } from "../data/store";

export function LibraryPanel({ onOpen, images, recent }: { onOpen: (app: AppId) => void; images: Record<string, string>; recent: string[] }) {
  const [tab, setTab] = useState("Todos");
  const [query, setQuery] = useState("");
  const apps = APPS.filter((app) => !["photos", "media", "explore"].includes(app.id) && app.name.toLowerCase().includes(query.toLowerCase()) && (tab !== "Recentes" || recent.includes(app.id)));
  return <section className="library-app">
    <header className="app-heading"><div><h1>Biblioteca</h1><p>Tudo no seu espaço.</p></div><div className="library-search"><Icon name="search" className="h-4 w-4" /><input value={query} onChange={(event) => setQuery(event.target.value)} inputMode="none" placeholder="Buscar aplicativos" aria-label="Buscar aplicativos" /></div></header>
    <div className="library-layout"><aside>{[["Todos", "grid"], ["Recentes", "history"], ["Jogos", "diamond"]].map(([name, icon]) => <button key={name} className={tab === name ? "is-active" : ""} onClick={() => setTab(name)} title={name}><Icon name={icon} className="h-5 w-5" /></button>)}<button className="library-store-link" onClick={() => onOpen("store")} title="Loja"><Icon name="store" className="h-5 w-5" /></button></aside>
      <div className="library-grid" data-scroll>
        {tab === "Jogos" ? STORE_GAMES.map((game) => <button className="library-item" key={game.id} onClick={() => onOpen("store")}><div className="library-banner"><img src={gameCover(game.id, true)} alt="" loading="lazy" /></div><span>{game.name}</span><small>Descobrir na loja</small></button>) : apps.map((app) => <button className="library-item" key={app.id} onClick={() => onOpen(app.id)}>
          <div className={`library-banner ${app.id === "youtube" ? "library-youtube" : ""}`} style={{ background: app.id === "youtube" ? "#f7f8fa" : `linear-gradient(145deg, ${app.color}, ${app.color2})` }}>
            {images[app.id] || app.iconImage ? <img src={images[app.id] || app.iconImage} alt="" className="custom-app-icon" /> : <Icon name={app.icon} className="h-9 w-9" />}
            {app.id === "youtube" && <strong>YouTube</strong>}
          </div><span>{app.name}</span><small>{app.subtitle}</small>
        </button>)}
        {tab === "Recentes" && !apps.length && <p className="app-notice">Nenhum app foi aberto nesta sessão.</p>}
      </div>
    </div>
  </section>;
}