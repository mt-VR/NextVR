import { useState } from "react";
import { Icon } from "../mr/icons";
import { LANGUAGE_ORDER, LOCALE_LABELS, tr } from "../lib/i18n";
import type { NextLanguage } from "../lib/preferences";

export function LanguagePicker({ initial = "pt", onSelect, onClose }: { initial?: NextLanguage; onSelect: (language: NextLanguage) => void; onClose?: () => void }) {
  const [selected, setSelected] = useState<NextLanguage>(initial);
  return <div className="language-onboarding">
    <div className="language-panel">
      <div className="language-copy"><span className="language-logo">N<i /></span><small>NEXT VR</small><h1>{tr(selected, "chooseLanguage")}</h1><p>{tr(selected, "languageDescription")}</p>
        <div className="language-current"><span className="language-flag">{LOCALE_LABELS[selected].flag}</span><span>{LOCALE_LABELS[selected].detail}</span><Icon name="chevron" className="h-4 w-4" /></div>
        <div className="language-list" data-scroll>{LANGUAGE_ORDER.map((language) => <button key={language} className={selected === language ? "is-selected" : ""} onClick={() => setSelected(language)}>
          <span className="language-flag">{LOCALE_LABELS[language].flag}</span><span><strong>{LOCALE_LABELS[language].native}</strong><small>{LOCALE_LABELS[language].detail}</small></span>{selected === language && <Icon name="check" className="h-5 w-5" />}
        </button>)}</div>
      </div>
      <div className="language-art" aria-hidden="true"><div className="language-orb"><i /><i /><i /></div><div className="language-hand-shape" /></div>
      <button className="language-continue" onClick={() => onSelect(selected)}>{tr(selected, "continue")}<Icon name="chevron" className="h-5 w-5" /></button>
      {onClose && <button className="language-close close-red" onClick={onClose} aria-label={tr(selected, "close")}><Icon name="close" className="h-4 w-4" /></button>}
    </div>
  </div>;
}