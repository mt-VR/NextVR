import { Dock } from "./Dock";

export function StartScreen({
  onEnter,
  camOk,
  busy = false,
}: {
  onEnter: (mode: "passthrough" | "horizon") => void;
  camOk: boolean;
  busy?: boolean;
}) {
  return (
    <div className="landing relative flex min-h-full items-center justify-center overflow-hidden px-6 py-10">
      <div className="noise pointer-events-none absolute inset-0 opacity-40 mix-blend-overlay" />
      <div className="relative z-10 grid w-full max-w-5xl gap-10 lg:grid-cols-[1.1fr_0.9fr] lg:items-center">
        <div>
          <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.18em] text-orange-200/80">
            Next VR · Mixed Reality
          </div>
          <h1 className="text-5xl font-extrabold leading-[1.05] tracking-tight text-white sm:text-6xl">
            Next VR
            <span className="block bg-gradient-to-r from-orange-300 via-amber-100 to-sky-300 bg-clip-text text-transparent">
              seu espaço MR.
            </span>
          </h1>
          <p className="mt-4 max-w-lg text-[15px] leading-relaxed text-white/65">
            Dock world-locked em 3D com 3DOF, Kalman + One Euro Filter. Janelas flutuantes,
            pinça na barrinha branca, YouTube de verdade e passthrough da câmera — a barra
            <em> não</em> fica colada na tela.
          </p>

          <ul className="mt-6 grid gap-2 text-sm text-white/70 sm:grid-cols-2">
            {[
              "Dock 3D · world lock",
              "Kalman + 1€ filter",
              "Gesto de pinça",
              "YouTube real (embed)",
              "Janelas com profundidade",
              "Ambiente 3D leve",
            ].map((t) => (
              <li key={t} className="flex items-center gap-2">
                <span className="h-1.5 w-1.5 rounded-full bg-orange-400" />
                {t}
              </li>
            ))}
          </ul>

          <div className="mt-8 flex flex-wrap gap-3">
            <button
              onClick={() => onEnter("passthrough")}
              disabled={busy}
              className="rounded-2xl bg-[#3e7e90] px-5 py-3 text-sm font-semibold text-white shadow-lg shadow-cyan-900/30 hover:brightness-110"
            >
              {busy ? "Preparando desktop..." : "Entrar no Next VR"}
            </button>
            <button
              onClick={() => onEnter("horizon")}
              disabled={busy}
              className="rounded-2xl border border-white/15 bg-white/5 px-5 py-3 text-sm font-semibold text-white hover:bg-white/10"
            >
              Ambiente 3D
            </button>
          </div>
          <div className="mt-4 flex gap-4 text-xs text-white/45">
            <span>Câmera {camOk ? "pronta" : "somente ao ativar"}</span>
            <span>Janelas e dock fixas no mundo</span>
            <span>Hand pela câmera · R recentraliza</span>
          </div>
        </div>

        <div className="relative mx-auto w-full max-w-md">
          <div
            className="floaty"
            style={{ perspective: 900 }}
          >
            <div className="dock-preview pointer-events-none" aria-hidden="true" style={{ transform: "rotateX(15deg) rotateY(-12deg)" }}>
              <Dock onOpen={() => {}} onPlus={() => {}} battery={76} online={true} activeApp="youtube" windows={[{ kind: "youtube", minimized: false }]} />
            </div>
          </div>
          <p className="mt-8 text-center text-xs text-white/40">
            Preview da dock — no MR ela vive no espaço 3D, ancorada no mundo.
          </p>
        </div>
      </div>
    </div>
  );
}
