import type { ReactNode } from "react";
import { Icon } from "../mr/icons";

export function WindowFrame({
  title,
  width,
  children,
  onClose,
  onMinimize,
  grabbing,
  noFooter,
  scale = 1,
  resizing = false,
  onScale,
  height = 490,
  selected = false,
}: {
  title: string;
  width: number;
  children: ReactNode;
  onClose: () => void;
  onMinimize?: () => void;
  grabbing?: boolean;
  noFooter?: boolean;
  scale?: number;
  resizing?: boolean;
  onScale?: (scale: number) => void;
  height?: number;
  selected?: boolean;
}) {
  return (
    <div className={`spatial-window flex flex-col items-center gap-3 ${resizing ? "is-resizing" : ""} ${selected ? "is-selected" : ""}`} style={{ width }}>
      <div className="window-shell w-full" data-resize-frame>
        <div className="window-glass w-full" data-window>
          <div className="window-content" data-scroll style={{ height }}>{children}</div>
        </div>
        {onScale && (["nw", "ne", "sw", "se"] as const).map((corner) => (
          <button key={corner} type="button" className={`resize-corner resize-${corner}`} data-resize={corner}
            title="Arraste ou faça pinça para redimensionar. Duplo clique restaura."
            aria-label={`Redimensionar janela: ${corner}`}
            onDoubleClick={() => onScale(1)}
            onKeyDown={(event) => {
              if (["ArrowRight", "ArrowUp", "ArrowLeft", "ArrowDown"].includes(event.key)) {
                event.preventDefault();
                event.stopPropagation();
                onScale(scale + (["ArrowRight", "ArrowUp"].includes(event.key) ? 0.05 : -0.05));
              }
            }}>
            <span />
          </button>
        ))}
      </div>
      {!noFooter && <div className="window-footer">
        <div className="window-toolbar-title">{title}</div>
        <button type="button" className="win-btn" onClick={onMinimize} title="Minimizar e restaurar pela dock" aria-label="Minimizar janela"><Icon name="minus" className="h-3.5 w-3.5" /></button>
        {onScale && <div className="window-size-controls">
          <button type="button" title="Diminuir janela" aria-label="Diminuir janela" onClick={() => onScale(scale - 0.15)}><Icon name="minus" className="h-3.5 w-3.5" /></button>
          <button type="button" className="window-scale-label" title="Restaurar tamanho original" onClick={() => onScale(1)} data-scale-readout>{Math.round(scale * 100)}%</button>
          <button type="button" title="Aumentar janela" aria-label="Aumentar janela" onClick={() => onScale(scale + 0.15)}><Icon name="plus" className="h-3.5 w-3.5" /></button>
        </div>}
        <button type="button" className="win-btn close-red" onClick={onClose} title="Fechar" aria-label="Fechar janela"><Icon name="close" className="h-3.5 w-3.5" /></button>
      </div>}
      <div className={`grab-bar ${grabbing ? "is-pinch" : ""}`} data-grab="window" />
    </div>
  );
}
