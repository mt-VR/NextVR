import { useCallback, useEffect, useRef, useState } from "react";
import { Icon } from "../mr/icons";

type TextField = HTMLInputElement | HTMLTextAreaElement;

export function useSpatialKeyboard(autoOpen: boolean) {
  const target = useRef<TextField | null>(null);
  const [opened, setOpened] = useState(false);
  const [text, setText] = useState("");
  const [label, setLabel] = useState("Selecione um campo de texto");
  useEffect(() => {
    const prepareFields = () => {
      document.querySelectorAll<HTMLInputElement | HTMLTextAreaElement>("[data-spatial] input, [data-spatial] textarea").forEach((field) => {
        if (field.closest("[data-eye-mirror]") || field instanceof HTMLInputElement && ["file", "range", "checkbox", "color", "radio"].includes(field.type)) return;
        const mode = autoOpen ? "none" : field.type === "url" ? "url" : "text";
        if (field.inputMode !== mode) field.inputMode = mode;
      });
    };
    prepareFields();
    const observer = new MutationObserver(prepareFields);
    observer.observe(document.getElementById("root")!, { childList: true, subtree: true });
    if (!autoOpen) setOpened(false);
    const focus = (event: FocusEvent) => {
      const field = event.target;
      if (!(field instanceof HTMLInputElement || field instanceof HTMLTextAreaElement)) return;
      if (field instanceof HTMLInputElement && ["file", "range", "checkbox", "color", "radio"].includes(field.type)) return;
      if (field.closest("[data-eye-mirror]")) return;
      target.current = field;
      setText(field.type === "password" ? "*".repeat(field.value.length) : field.value);
      setLabel(field.getAttribute("aria-label") || field.placeholder || "Texto");
      if (autoOpen) { field.inputMode = "none"; setOpened(true); }
    };
    const input = () => {
      const field = target.current;
      if (field) setText(field.type === "password" ? "*".repeat(field.value.length) : field.value);
    };
    document.addEventListener("focusin", focus);
    document.addEventListener("input", input);
    return () => { observer.disconnect(); document.removeEventListener("focusin", focus); document.removeEventListener("input", input); };
  }, [autoOpen]);

  const press = useCallback((key: string) => {
    const field = target.current;
    if (!field?.isConnected) return;
    if (key === "enter") {
      if (field.form) field.form.requestSubmit();
      else field.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", bubbles: true }));
      return;
    }
    const start = field.selectionStart ?? field.value.length;
    const end = field.selectionEnd ?? start;
    const prefix = field.value.slice(0, start);
    const suffix = field.value.slice(end);
    const insertion = key === "backspace" ? "" : key === "space" ? " " : key;
    const left = key === "backspace" && start === end ? Array.from(prefix).slice(0, -1).join("") : prefix;
    const next = left + insertion + suffix;
    const prototype = field instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    // React observes the native value setter plus a bubbling input event.
    Object.getOwnPropertyDescriptor(prototype, "value")?.set?.call(field, next);
    field.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: key === "backspace" ? "deleteContentBackward" : "insertText", data: insertion }));
    try { field.setSelectionRange(left.length + insertion.length, left.length + insertion.length); } catch { /* URL/number fields do not expose a selection. */ }
    setText(field.type === "password" ? "*".repeat(next.length) : next);
  }, []);

  return {
    opened, text, label, press,
    toggle: () => setOpened((value) => !value),
    close: () => setOpened(false),
    closeForWindow: (id: string) => {
      if (target.current?.closest<HTMLElement>("[data-win]")?.dataset.win === id) {
        setOpened(false); target.current = null; setText(""); setLabel("Selecione um campo de texto");
      }
    },
  };
}

export function VirtualKeyboard({ text, label, onKey, onClose }: {
  text: string; label: string; onKey: (key: string) => void; onClose: () => void;
}) {
  const [shift, setShift] = useState(false);
  const [symbols, setSymbols] = useState(false);
  const [pressed, setPressed] = useState("");
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  useEffect(() => () => { if (timer.current) clearTimeout(timer.current); }, []);
  const rows = symbols ? ["1234567890", "@#%&*()-+=", "!?.,:/_'\""] : ["qwertyuiop", "asdfghjkl", "zxcvbnm"];
  const send = (key: string) => {
    setPressed(key);
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => setPressed(""), 130);
    onKey(shift && key.length === 1 ? key.toUpperCase() : key);
    if (shift && key.length === 1) setShift(false);
  };
  return <div className="mr-keyboard" data-keyboard onPointerDown={(event) => event.preventDefault()}>
    <div className="keyboard-top"><span><Icon name="keyboard" className="h-4 w-4" />Teclado Next VR</span>
      <button onClick={onClose} className="close-red" aria-label="Fechar teclado"><Icon name="close" className="h-4 w-4" /></button>
    </div>
    <div className="keyboard-preview"><small>{label}</small><div>{text || <span>Digite usando pinça ou toque</span>}<i /></div></div>
    {rows.map((row, index) => <div key={index} className="keyboard-row">
      {index === 2 && <button className={shift ? "is-active" : ""} onClick={() => setShift((value) => !value)} aria-label="Maiúsculas"><Icon name="shift" className="h-4 w-4" /></button>}
      {Array.from(row).map((letter) => <button key={letter} className={pressed === letter ? "is-pressed" : ""} onClick={() => send(letter)}>{shift ? letter.toUpperCase() : letter}</button>)}
      {index === 2 && <button onClick={() => send("backspace")} aria-label="Apagar"><Icon name="backspace" className="h-4 w-4" /></button>}
    </div>)}
    <div className="keyboard-row keyboard-bottom">
      <button onClick={() => setSymbols((value) => !value)}>{symbols ? "ABC" : "?123"}</button>
      <button onClick={() => send("ç")}>ç</button>
      <button className="space-key" onClick={() => send("space")}>espaço</button>
      <button onClick={() => send(".")}>.</button>
      <button className="enter-key" onClick={() => send("enter")}>Buscar <Icon name="enter" className="h-4 w-4" /></button>
    </div>
    <div className="keyboard-grab"><div className="grab-bar" data-grab="keyboard" /></div>
  </div>;
}