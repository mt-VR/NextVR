import { Icon } from "../mr/icons";
import { APPS } from "../data/catalog";
import { MAX_VISIBLE_APPS, type WorkspaceWindow } from "../mr/workspace";

export function MultitaskPanel({ windows, active, onFocus, onClose, onMinimize, onArrange, onOpenThree }: {
  windows: WorkspaceWindow[]; active: string | null; onFocus: (id: string) => void;
  onClose: (id: string) => void; onMinimize: (id: string) => void; onArrange: () => void;
  onOpenThree: () => void;
}) {
  const apps = windows.filter((window) => window.kind !== "multitask");
  const visible = apps.filter((window) => !window.minimized).length;
  return <section className="multitask-app"><header className="app-heading"><div><h1>Seu workspace</h1><p>{visible} de {MAX_VISIBLE_APPS} abas no espaço. O gerenciador não ocupa uma vaga.</p></div><button className="mr-primary" onClick={onArrange}><Icon name="arc" className="h-4 w-4" />Organizar em arco</button></header>
    <div className="workspace-arc-preview" aria-hidden="true"><i /><i /><i /><div /></div>
    <div className="flex items-center justify-center gap-3 px-6 pb-3"><button className="mr-secondary" onClick={onOpenThree}><Icon name="layers" className="h-4 w-4" />Abrir 3 abas</button><span className="text-xs text-white/45">YouTube + Navegador + Galeria</span></div>
    <div className="task-list" data-scroll>{apps.map((window) => <div key={window.id} className={`task-item ${active === window.id ? "is-active" : ""}`}>
      <button className="task-select" onClick={() => onFocus(window.id)}><span style={{ background: APPS.find((app) => app.id === window.kind)?.color ?? "#556885" }}><Icon name={APPS.find((app) => app.id === window.kind)?.icon ?? "square"} className="h-5 w-5" /></span><div><strong>{window.title}</strong><small>{window.minimized ? "Minimizada" : "No espaço MR"}</small></div></button>
      <button className="win-btn" onClick={() => onMinimize(window.id)} title="Minimizar"><Icon name="minus" className="h-4 w-4" /></button><button className="close-red" onClick={() => onClose(window.id)} title="Fechar somente esta janela"><Icon name="close" className="h-4 w-4" /></button>
    </div>)}</div>
    {!apps.length && <div className="mr-empty"><Icon name="layers" className="h-9 w-9" /><h2>Nenhum aplicativo aberto.</h2><p>Abra apps pela dock para começar sua multitarefa.</p></div>}
    <p className="app-footnote">Três apps simultâneos: esquerda, centro e direita. Ao abrir um quarto app, o mais antigo é minimizado, não fechado. Mover uma janela não altera as outras.</p>
  </section>;
}