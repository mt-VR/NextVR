import { useEffect, useId, useRef, useState, type FormEvent } from "react";
import { Icon } from "../mr/icons";
import { loadGoogleCse, type GoogleCseControl } from "../lib/google-search";

const configuredCx = String(import.meta.env.VITE_GOOGLE_CSE_ID ?? "").trim();

function GoogleResults({ cx, query, onReady, onStatus, onNavigate }: {
  cx: string; query: string; onReady: (control: GoogleCseControl | null) => void; onStatus: (message: string) => void; onNavigate: (url: string) => void;
}) {
  const host = useRef<HTMLDivElement>(null);
  const name = useId().replace(/:/g, "");

  useEffect(() => {
    if (!cx || !host.current) return;
    let disposed = false;
    onStatus("Carregando a busca oficial do Google...");
    host.current.replaceChildren();
    void loadGoogleCse(cx).then((api) => {
      if (disposed || !host.current) return;
      api.render({ div: host.current, tag: "searchresults-only", gname: name, attributes: { linkTarget: "_self", enableAutoComplete: "true" } });
      const control = api.getElement(name);
      onReady(control);
      if (query.trim()) control?.execute(query.trim());
      onStatus("");
    }).catch((failure: unknown) => {
      if (!disposed) onStatus(failure instanceof Error ? failure.message : "A busca do Google não carregou.");
    });
    return () => { disposed = true; onReady(null); };
  }, [cx, name]);

  useEffect(() => {
    if (!query.trim()) return;
    const timer = window.setTimeout(() => {
      const api = (window as Window & { google?: { search?: { cse?: { element?: { getElement: (id: string) => GoogleCseControl | null } } } } }).google?.search?.cse?.element;
      api?.getElement(name)?.execute(query.trim());
    }, 0);
    return () => clearTimeout(timer);
  }, [query, name]);

  return <div ref={host} className="google-cse-results" data-scroll onClickCapture={(event) => {
    const link = (event.target as HTMLElement).closest<HTMLAnchorElement>("a[href]");
    if (!link || !/^https?:/i.test(link.href)) return;
    event.preventDefault();
    event.stopPropagation();
    onNavigate(link.href);
  }} />;
}

export function MetaBrowser({ onYouTube, hidden = false }: { onYouTube: () => void; hidden?: boolean }) {
  const inputId = useId();
  const cseId = useId();
  const [query, setQuery] = useState("");
  const [history, setHistory] = useState<string[]>([]);
  const [index, setIndex] = useState(-1);
  const [notice, setNotice] = useState("");
  const [cx, setCx] = useState(() => {
    try { return localStorage.getItem("next-vr:google-cse-id") ?? configuredCx; } catch { return configuredCx; }
  });
  const [cxDraft, setCxDraft] = useState(cx);
  const [showSetup, setShowSetup] = useState(!cx);
  const [control, setControl] = useState<GoogleCseControl | null>(null);
  const [googleQuery, setGoogleQuery] = useState("");
  const src = history[index] ?? "";
  const googleMode = !src;

  useEffect(() => { if (hidden) setControl(null); }, [hidden]);

  const searchGoogle = (value: string) => {
    if (!cx) {
      setShowSetup(true);
      setNotice("Para usar o Google dentro desta janela, configure o ID de um Google Programmable Search Engine. Google.com bloqueia iframe comum.");
      return;
    }
    setHistory([]); setIndex(-1); setGoogleQuery(value); control?.execute(value); setNotice("");
  };
  const open = (event: FormEvent) => {
    event.preventDefault();
    const value = query.trim();
    if (!value) return;
    if (/youtube\.com|youtu\.be/i.test(value)) { onYouTube(); return; }
    const looksUrl = /^https?:\/\//i.test(value) || (value.includes(".") && !value.includes(" "));
    if (!looksUrl) { searchGoogle(value); return; }
    try {
      const url = new URL(/^https?:\/\//i.test(value) ? value : `https://${value}`);
      if (!["http:", "https:"].includes(url.protocol)) throw new Error();
      const next = [...history.slice(0, index + 1), url.toString()];
      setHistory(next); setIndex(next.length - 1); setNotice("");
    } catch { setNotice("Insira um endereço HTTP ou HTTPS válido."); }
  };
  const saveCx = (event: FormEvent) => {
    event.preventDefault();
    const next = cxDraft.trim();
    if (!/^[a-z0-9:_-]{6,120}$/i.test(next)) { setNotice("Informe um ID cx válido do Google Programmable Search Engine."); return; }
    try { localStorage.setItem("next-vr:google-cse-id", next); } catch { /* The CSE ID is non-sensitive. */ }
    setCx(next); setShowSetup(false); setNotice("");
  };
  const navigateResult = (url: string) => {
    const next = [...history.slice(0, index + 1), url];
    setHistory(next); setIndex(next.length - 1); setNotice("");
  };

  return <section className="browser-app next-browser">
    <form className="browser-bar" onSubmit={open}>
      <button type="button" disabled={index <= 0} onClick={() => setIndex((value) => value - 1)} aria-label="Voltar"><Icon name="back" className="h-4 w-4" /></button>
      <button type="button" onClick={() => { setIndex(-1); setHistory([]); setGoogleQuery(""); }} title="Pesquisa Google"><Icon name="home" className="h-4 w-4" /></button>
      <label><Icon name={googleMode ? "search" : "globe"} className="h-4 w-4" /><input id={inputId} inputMode="none" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Pesquisar no Google ou digitar endereço" aria-label="Pesquisar no Google ou digitar endereço" /></label>
      <button type="submit" className="mr-primary">{googleMode ? "Pesquisar" : "Abrir"}</button>
    </form>
    {notice && <p className="app-notice" role="status">{notice}</p>}
    {googleMode ? <div className="google-real-panel">
      <header><div><span>GOOGLE</span><h1>Pesquisa na web</h1><p>Resultados oficiais dentro da sua janela Next VR.</p></div><button className="mr-text" onClick={() => setShowSetup((value) => !value)}><Icon name="gear" className="h-4 w-4" />Configurar</button></header>
      {showSetup && <form className="google-setup" onSubmit={saveCx}>
        <strong>Ativar Google real nesta janela</strong>
        <p>O endereço <code>google.com</code> bloqueia iframe por segurança. Para exibir Google de verdade dentro de uma janela, use o Google Programmable Search oficial e cole o ID <code>cx</code> de um mecanismo configurado para pesquisar a web.</p>
        <div><label htmlFor={cseId}>ID do mecanismo (cx)</label><input id={cseId} inputMode="none" value={cxDraft} onChange={(event) => setCxDraft(event.target.value)} placeholder="ID do Google Programmable Search" /><button className="mr-primary">Conectar</button></div>
        <a href="https://programmablesearchengine.google.com/controlpanel/all" target="_blank" rel="noopener">Criar mecanismo do Google <Icon name="external" className="h-3 w-3" /></a>
      </form>}
      {cx && !hidden ? <GoogleResults cx={cx} query={googleQuery} onReady={setControl} onStatus={setNotice} onNavigate={navigateResult} /> : !showSetup && <div className="mr-empty"><Icon name="search" className="h-10 w-10" /><h2>Google dentro do Next VR</h2><p>Configure o mecanismo oficial uma vez para pesquisar e abrir resultados reais nesta janela.</p><button className="mr-primary" onClick={() => setShowSetup(true)}>Configurar Google</button></div>}
    </div> : <>
      <div className="browser-viewport">{!hidden && <iframe title="Página no navegador Next VR" src={src} referrerPolicy="strict-origin-when-cross-origin" sandbox="allow-scripts allow-forms allow-same-origin allow-popups" />}</div>
      <div className="browser-limits"><span>Alguns sites bloqueiam iframe ou impedem interação por segurança.</span><a href={src} target="_blank" rel="noopener">Abrir no navegador<Icon name="external" className="h-3 w-3" /></a></div>
    </>}
    {googleMode && <div className="browser-shortcuts"><button onClick={onYouTube}><Icon name="play" className="h-4 w-4" />YouTube</button><button onClick={() => setQuery("Next VR realidade virtual")}>Pesquisar Next VR</button></div>}
  </section>;
}