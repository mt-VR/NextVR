import { Icon } from "../mr/icons";
import type { EnvironmentId } from "../lib/preferences";

export const ENVIRONMENTS: { id: EnvironmentId; name: string; caption: string; colors: string[] }[] = [
  { id: "horizon", name: "Next VR Home", caption: "Seu ambiente 3D original", colors: ["#542010", "#db8847"] },
  { id: "studio", name: "Studio 3D", caption: "A mesma sala, paleta suave", colors: ["#324557", "#8995a3"] },
  { id: "aurora", name: "Aurora 3D", caption: "A mesma sala, tons frios", colors: ["#103c43", "#80c6b9"] },
  { id: "sunset", name: "Pôr do sol 3D", caption: "A mesma sala, paleta quente", colors: ["#442a4d", "#e2ab8e"] },
  { id: "passthrough", name: "Mundo real", caption: "Ativar câmera com sua permissão", colors: ["#313641", "#a4b0c1"] },
];

export function EnvironmentPanel({ current, onSelect }: { current: EnvironmentId; onSelect: (environment: EnvironmentId) => void }) {
  return <section className="environment-app">
    <header className="app-heading"><div><span className="app-eyebrow">SEU ESPAÇO</span><h1>Ambientes virtuais</h1><p>Troque o cenário. Mantenha tudo o que está aberto.</p></div><Icon name="world" className="h-7 w-7" /></header>
    <div className="environment-grid" data-scroll>{ENVIRONMENTS.map((environment) => <button key={environment.id} className={`environment-choice ${current === environment.id ? "is-selected" : ""}`} onClick={() => onSelect(environment.id)}>
      <div className="environment-preview" style={{ background: `linear-gradient(180deg,${environment.colors[0]},${environment.colors[1]})` }}>
        {environment.id === "passthrough" ? <Icon name="camera" className="h-12 w-12" /> : <><i className="env-floor" /><i className="env-column col-one" /><i className="env-column col-two" /><i className="env-column col-three" /><i className="env-platform" /></>}
        {current === environment.id && <span><Icon name="check" className="h-3.5 w-3.5" />Ativo</span>}
      </div>
      <h2>{environment.name}</h2><p>{environment.caption}</p>
    </button>)}</div>
    <p className="app-footnote">Todos os ambientes usam a mesma sala 3D leve, sem fotos panorâmicas. A câmera só inicia ao escolher Mundo real.</p>
  </section>;
}