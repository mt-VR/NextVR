import { useLayoutEffect, useState, type ReactNode } from "react";
import { createPortal } from "react-dom";
import type { MREngine, Vec3 } from "../mr/engine";
import { CSS_WORLD_SCALE } from "../mr/engine";

export function Spatial({
  id,
  engine,
  position,
  children,
  faceUser = false,
  scale = 1,
  visible = true,
  rotation,
}: {
  id: string;
  engine: MREngine;
  position: Vec3;
  children: ReactNode;
  faceUser?: boolean;
  scale?: number;
  visible?: boolean;
  rotation?: [number, number, number, number];
}) {
  const [host, setHost] = useState<HTMLDivElement | null>(null);

  useLayoutEffect(() => {
    const el = document.createElement("div");
    el.style.pointerEvents = "auto";
    engine.attach(id, el, position, CSS_WORLD_SCALE * scale);
    setHost(el);
    return () => {
      engine.detach(id);
      setHost(null);
    };
    // id/engine identity only — position is applied below
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id, engine]);

  useLayoutEffect(() => {
    engine.setPose(id, position, faceUser);
  }, [engine, id, position, faceUser]);

  useLayoutEffect(() => {
    engine.setScale(id, scale);
    engine.setVisible(id, visible);
  }, [engine, id, scale, visible]);

  useLayoutEffect(() => {
    if (rotation) engine.setRotation(id, rotation);
  }, [engine, id, rotation]);

  if (!host) return null;
  return createPortal(children, host);
}
