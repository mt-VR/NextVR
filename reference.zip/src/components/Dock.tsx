import { useEffect, useState, type CSSProperties } from "react";
import { Icon } from "../mr/icons";
import type { AppId } from "../data/catalog";
import type { DockStyle } from "../lib/preferences";
import type { NextLanguage } from "../lib/preferences";
import { tr } from "../lib/i18n";

function useClock() {
  const [t, setT] = useState(() => new Date());
  useEffect(() => {
    const id = setInterval(() => setT(new Date()), 15000);
    return () => clearInterval(id);
  }, []);
  return t.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
}

const DOCK_APPS: { id: AppId; color: string; deep: string; icon: string; title: string }[] = [
  { id: "store", color: "#f2bd70", deep: "#b7772e", icon: "store", title: "Loja" },
  { id: "contacts", color: "#ba97e2", deep: "#8055af", icon: "people", title: "Pessoas" },
  { id: "youtube", color: "#ff5268", deep: "#cf1738", icon: "play", title: "YouTube" },
  { id: "browser", color: "#64dadd", deep: "#1a929f", icon: "globe", title: "Navegador" },
  { id: "gallery", color: "#8fc7ab", deep: "#398169", icon: "photo", title: "Galeria" },
  { id: "worlds", color: "#b1a4df", deep: "#7869a6", icon: "world", title: "Ambientes" },
  { id: "settings", color: "#8ce4c4", deep: "#36a187", icon: "gear", title: "Ajustes" },
];

export function Dock({
  onOpen,
  onPlus,
  battery,
  online,
  grabbing,
  windows = [],
  activeApp = null,
  style = "glass",
  images = {},
  hands = false,
  onHands,
  onKeyboard,
  onArrange,
  onRecenter,
  onMenu,
  menuOpen = false,
  language = "pt",
}: {
  onOpen: (id: AppId) => void;
  onPlus: () => void;
  battery: number;
  online: boolean;
  grabbing?: boolean;
  windows?: { kind: string; minimized?: boolean }[];
  activeApp?: string | null;
  style?: DockStyle;
  images?: Record<string, string>;
  hands?: boolean;
  onHands?: () => void;
  onKeyboard?: () => void;
  onArrange?: () => void;
  onRecenter?: () => void;
  onMenu?: () => void;
  menuOpen?: boolean;
  language?: NextLanguage;
}) {
  const clock = useClock();

  return (
    <div className="dock-composition flex flex-col items-center gap-3">
      <nav className={`horizon-dock dock-v2 dock-${style}`} aria-label="Dock espacial Next VR">
        <div className="dock-reflection" aria-hidden="true" />
        <button type="button" className={`dock-profile ${menuOpen ? "is-active" : ""}`} title={tr(language, "menu")} aria-label={tr(language, "menu")} onClick={onMenu ?? onRecenter ?? (() => onOpen("contacts"))}>
          <span className="metamr-symbol">N</span><i className={online ? "is-online" : ""} />
        </button>
        <button type="button" className="dock-status" onClick={() => onOpen("system")} title="Configurações rápidas">
          <span className="dock-clock">{clock}<small>Next VR</small></span>
          <span className="dock-status-detail">
            <Icon name="wifi" className={`h-3.5 w-3.5 ${online ? "" : "opacity-30"}`} />
            <span className="dock-battery" aria-label={battery >= 0 ? `Bateria ${battery}%` : "Bateria indisponível"}>
              <i style={{ width: `${Math.max(0, Math.min(100, battery))}%` }} />
            </span>
            <span>{battery >= 0 ? `${battery}%` : "--"}</span>
          </span>
        </button>
        <span className="dock-divider" aria-hidden="true" />
        <button type="button"
          className="dock-utility"
          onClick={() => onOpen("multitask")}
          title="Multitarefa"
          aria-label="Multitarefa"
        >
          <Icon name="layers" className="h-[18px] w-[18px]" />
        </button>
        {onRecenter && <button type="button" className="dock-utility" onClick={onRecenter} title={tr(language, "recenter")} aria-label={tr(language, "recenter")}><Icon name="recenter" className="h-[18px] w-[18px]" /></button>}
        <span className="dock-divider" aria-hidden="true" />
        <div className="dock-app-rail">
        {DOCK_APPS.map((a) => {
          const appKind = a.id === "home" ? "apps" : a.id;
          const opened = windows.find((window) => window.kind === appKind);
          return <button type="button"
            key={a.id}
            title={`${a.title}${opened?.minimized ? " (restaurar)" : ""}`}
            aria-label={`${a.title}${opened?.minimized ? " (restaurar janela)" : ""}`}
            className={`dock-app ${activeApp === appKind && !opened?.minimized ? "is-active" : ""}`}
            style={{ "--app-color": a.color, "--app-deep": a.deep } as CSSProperties}
            onClick={() => onOpen(a.id)}
          >
            <span className="dock-app-tile">{images[a.id] ? <img src={images[a.id]} alt="" /> : <Icon name={a.icon} className="h-[23px] w-[23px]" />}</span>
            <span className="dock-app-label">{a.title}</span>
            <i className={`dock-running-indicator ${opened ? "is-running" : ""} ${opened?.minimized ? "is-minimized" : ""}`} />
          </button>;
        })}
        </div>
        <span className="dock-divider" aria-hidden="true" />
        {onHands && <button className={`dock-utility ${hands ? "is-active" : ""}`} onClick={onHands} title={hands ? "Desativar Hand" : "Ativar Hand com câmera"} aria-label={hands ? "Desativar Hand" : "Ativar Hand com câmera"}><Icon name="hand" className="h-5 w-5" /></button>}
        {onKeyboard && <button className="dock-utility" onClick={onKeyboard} title="Abrir ou fechar teclado" aria-label="Abrir ou fechar teclado"><Icon name="keyboard" className="h-5 w-5" /></button>}
        {onArrange && <button className="dock-utility" onClick={onArrange} title="Organizar em arco" aria-label="Organizar em arco"><Icon name="arc" className="h-5 w-5" /></button>}
        <button type="button"
          className="dock-library"
          onClick={onPlus}
          title="Abrir biblioteca"
          aria-label="Abrir biblioteca de aplicativos"
        >
          <Icon name="grid" className="h-[21px] w-[21px]" />
        </button>
      </nav>
      <div className={`grab-bar ${grabbing ? "is-pinch" : ""}`} data-grab="dock" />
    </div>
  );
}
