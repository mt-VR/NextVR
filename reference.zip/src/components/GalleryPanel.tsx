import { useEffect, useRef, useState } from "react";
import { Icon } from "../mr/icons";

type Photo = { id: string; name: string; url: string; size: number };

export function GalleryPanel() {
  const fileInput = useRef<HTMLInputElement>(null);
  const allocated = useRef(new Set<string>());
  const [photos, setPhotos] = useState<Photo[]>([]);
  const [selected, setSelected] = useState<number | null>(null);
  const [zoom, setZoom] = useState(1);
  const [notice, setNotice] = useState("");
  useEffect(() => () => allocated.current.forEach((url) => URL.revokeObjectURL(url)), []);

  const importPhotos = (files: FileList | File[]) => {
    let total = photos.reduce((sum, photo) => sum + photo.size, 0);
    const accepted = Array.from(files).filter((file) => {
      if (!/^image\//.test(file.type) || file.size > 25 * 1024 * 1024 || total + file.size > 96 * 1024 * 1024) return false;
      total += file.size;
      return true;
    }).slice(0, Math.max(0, 48 - photos.length));
    const additions = accepted.map((file, index) => {
      const url = URL.createObjectURL(file);
      allocated.current.add(url);
      return { id: `${Date.now()}-${index}`, name: file.name, url, size: file.size };
    });
    setPhotos((previous) => [...previous, ...additions]);
    setNotice(additions.length ? `${additions.length} fotos autorizadas. Os arquivos originais não são alterados.` : "Selecione imagens de até 25 MB. Limite de 48 fotos e 96 MB por sessão.");
  };
  const pick = () => {
    if (navigator.userActivation && !navigator.userActivation.isActive) {
      setNotice("O Android exige uma ativação real para abrir o seletor de fotos. Toque neste botão uma vez e depois navegue pelas fotos usando a mão.");
      return;
    }
    fileInput.current?.click();
  };
  const remove = () => {
    if (selected === null) return;
    const photo = photos[selected];
    URL.revokeObjectURL(photo.url);
    allocated.current.delete(photo.url);
    setPhotos((previous) => previous.filter((item) => item.id !== photo.id));
    setSelected(null);
    setNotice("Foto removida apenas desta sessão do Next VR. O arquivo do celular foi preservado.");
  };
  const current = selected === null ? null : photos[selected];
  return <section className="gallery-app" onDragOver={(event) => event.preventDefault()} onDrop={(event) => { event.preventDefault(); importPhotos(event.dataTransfer.files); }}>
    <header className="app-heading"><div><h1>Galeria</h1><p>Suas memórias, no seu espaço.</p></div>
      <button className="mr-primary" onClick={pick}><Icon name="plus" className="h-4 w-4" />Selecionar fotos</button>
      <input ref={fileInput} type="file" accept="image/*" multiple hidden onChange={(event) => {
        if (event.target.files) importPhotos(event.target.files);
        event.target.value = "";
      }} />
    </header>
    {notice && <p className="app-notice" role="status">{notice}</p>}
    {current ? <div className="gallery-detail">
      <div className="gallery-tools"><button onClick={() => { setSelected(null); setZoom(1); }}><Icon name="back" className="h-4 w-4" />Todas as fotos</button><span>{current.name}</span>
        <button onClick={() => setZoom((value) => Math.max(1, value - 0.25))}><Icon name="minus" className="h-4 w-4" /></button><small>{Math.round(zoom * 100)}%</small>
        <button onClick={() => setZoom((value) => Math.min(3, value + 0.25))}><Icon name="plus" className="h-4 w-4" /></button>
      </div>
      <div className="gallery-viewer" data-scroll><img src={current.url} alt={current.name} style={{ transform: `scale(${zoom})` }} onError={() => setNotice("Este navegador não suporta esta imagem. Tente JPEG, PNG ou WebP.")} /></div>
      <div className="gallery-navigation"><button disabled={selected === 0} onClick={() => { setSelected((value) => value === null ? 0 : value - 1); setZoom(1); }}><Icon name="back" className="h-4 w-4" />Anterior</button>
        <small>{(selected ?? 0) + 1} / {photos.length}</small>
        <button onClick={remove} title="Remover apenas do Next VR"><Icon name="trash" className="h-4 w-4" /></button>
        <button disabled={selected === photos.length - 1} onClick={() => { setSelected((value) => value === null ? 0 : value + 1); setZoom(1); }}>Próxima<Icon name="chevron" className="h-4 w-4" /></button>
      </div>
    </div> : photos.length ? <div className="gallery-grid" data-scroll>{photos.map((photo, index) => <button key={photo.id} onClick={() => { setSelected(index); setZoom(1); }}><img src={photo.url} alt={photo.name} loading="lazy" decoding="async" /><span>{photo.name}</span></button>)}</div> :
      <div className="mr-empty"><Icon name="photo" className="h-12 w-12" /><h2>Só o que você permitir.</h2><p>Escolha fotos no seletor do Android. Elas aparecem aqui,<br />dentro desta janela, sem upload ou acesso automático.</p><button className="mr-secondary" onClick={pick}>Abrir seletor de fotos</button></div>}
  </section>;
}