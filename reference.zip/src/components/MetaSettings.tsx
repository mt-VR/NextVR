import { useRef, useState } from "react";
import { Icon } from "../mr/icons";
import { APPS } from "../data/catalog";
import type { MetaPreferences } from "../lib/preferences";
import type { NextLanguage } from "../lib/preferences";
import { LOCALE_LABELS, tr, type NextCopyKey } from "../lib/i18n";
import type { HandTrackingState } from "../mr/tracking-types";

function SettingSwitch({ title, caption, on, onChange }: { title: string; caption?: string; on: boolean; onChange: () => void }) {
  return <button className="settings-option" role="switch" aria-checked={on} onClick={onChange}><div><strong>{title}</strong>{caption && <small>{caption}</small>}</div><span className={`settings-switch ${on ? "is-on" : ""}`}><i /></span></button>;
}

function SettingNumber({ title, caption, value, display, step, min, max, onChange }: { title: string; caption?: string; value: number; display: string; step: number; min: number; max: number; onChange: (number: number) => void }) {
  return <div className="settings-option"><div><strong>{title}</strong>{caption && <small>{caption}</small>}</div><span className="settings-stepper"><button disabled={value <= min} onClick={() => onChange(Math.max(min, value - step))}><Icon name="minus" className="h-4 w-4" /></button><small>{display}</small><button disabled={value >= max} onClick={() => onChange(Math.min(max, value + step))}><Icon name="plus" className="h-4 w-4" /></button></span></div>;
}

const categories: { id: string; translation: NextCopyKey; caption: string; icon: string }[] = [
  { id: "general", translation: "general", icon: "gear", caption: "Informações, idioma e preferências" },
  { id: "hands", translation: "interaction", icon: "hand", caption: "Pinça, suavidade e rastreamento" },
  { id: "dock", translation: "dock", icon: "grid", caption: "Modelos, proporções e ícones PNG" },
  { id: "appearance", translation: "appearance", icon: "pencil", caption: "Sua identidade no espaço MR" },
  { id: "windows", translation: "windows", icon: "layers", caption: "Profundidade, escala e organização" },
  { id: "performance", translation: "performance", icon: "bolt", caption: "Priorize seu Android" },
  { id: "privacy", translation: "privacy", icon: "shield", caption: "Câmera, arquivos e permissões" },
];

export function MetaSettings({ preferences, onUpdate, onReset, hands, handState, onHands, onRetry, onArrange, onEnvironments, onSensors, fps, stereo, onStereo, language, onLanguage }: {
  preferences: MetaPreferences; onUpdate: (patch: Partial<MetaPreferences>) => void; onReset: () => void;
  hands: boolean; handState: HandTrackingState; onHands: (on: boolean) => void; onRetry: () => void;
  onArrange: () => void; onEnvironments: () => void; onSensors: () => void; fps: number;
  stereo: boolean; onStereo: () => void;
  language: NextLanguage; onLanguage: (language: NextLanguage) => void;
}) {
  const [page, setPage] = useState("home");
  const [iconTarget, setIconTarget] = useState("youtube");
  const [notice, setNotice] = useState("");
  const fileInput = useRef<HTMLInputElement>(null);
  const current = categories.find((category) => category.id === page);
  const loadIcon = async (file: File) => {
    if (file.type !== "image/png" || file.size > 2 * 1024 * 1024) { setNotice("Escolha uma imagem PNG de até 2 MB."); return; }
    try {
      const bitmap = await createImageBitmap(file);
      const canvas = document.createElement("canvas");
      canvas.width = canvas.height = 128;
      const ctx = canvas.getContext("2d");
      const ratio = Math.min(128 / bitmap.width, 128 / bitmap.height);
      ctx?.drawImage(bitmap, (128 - bitmap.width * ratio) / 2, (128 - bitmap.height * ratio) / 2, bitmap.width * ratio, bitmap.height * ratio);
      bitmap.close();
      onUpdate({ iconImages: { ...preferences.iconImages, [iconTarget]: canvas.toDataURL("image/png") } });
      setNotice("Ícone atualizado. A imagem original não foi modificada.");
    } catch { setNotice("Não foi possível ler essa imagem PNG."); }
  };
  return <section className="settings-app">
    <header className="settings-heading"><button onClick={() => setPage("home")} className="settings-back" title="Voltar"><Icon name={page === "home" ? "gear" : "back"} className="h-5 w-5" /></button><div><small>Next VR</small><h1>{current ? tr(language, current.translation) : tr(language, "settings")}</h1></div><span>Seu espaço, do seu jeito.</span></header>
    <div className="settings-page" key={page} data-scroll>
      {page === "home" ? <>
        <div className="settings-intro"><span className="settings-avatar"><Icon name="face" className="h-8 w-8" /></span><div><h2>Você no controle.</h2><p>Personalize o Next VR sem sair do seu ambiente.</p></div></div>
        <div className="settings-categories">{categories.map((category) => <button key={category.id} onClick={() => setPage(category.id)}><span className={`settings-category-icon category-${category.id}`}><Icon name={category.icon} className="h-5 w-5" /></span><div><h2>{tr(language, category.translation)}</h2><p>{category.caption}</p></div><Icon name="chevron" className="h-4 w-4" /></button>)}</div>
      </> : page === "general" ? <>
        <div className="privacy-note"><Icon name="world" className="h-8 w-8" /><h2>Next VR</h2><p>Interface espacial com janelas 3D fixas no ambiente.</p></div>
        <div className="settings-option"><div><strong>{tr(language, "language")}</strong><small>{LOCALE_LABELS[language].detail}</small></div><button className="mr-secondary" onClick={() => onLanguage(language === "pt" ? "en" : language === "en" ? "es" : "pt")}>{LOCALE_LABELS[language].flag}</button></div>
        <div className="settings-option"><div><strong>Versão</strong><small>Next VR Web · 3DOF</small></div><span className="text-xs text-white/45">Atual</span></div>
        <SettingSwitch title="Reduzir animações" caption="Menos transições decorativas no espaço 3D" on={preferences.reduceMotion} onChange={() => onUpdate({ reduceMotion: !preferences.reduceMotion })} />
        <SettingNumber title="Sensibilidade do giroscópio" caption="Movimentos menores e mais suaves no ambiente" value={preferences.gyroSensitivity} display={`${Math.round(preferences.gyroSensitivity * 100)}%`} step={0.02} min={0.12} max={0.42} onChange={(gyroSensitivity) => onUpdate({ gyroSensitivity })} />
      </> : page === "hands" ? <>
        <p className="settings-description">A mão real aparece acima de todas as janelas. O toque na tela nunca movimenta o Hand.</p>
        <SettingSwitch title="Hand tracking" caption="A câmera só será solicitada ao ativar" on={hands} onChange={() => onHands(!hands)} />
        <div className={`hand-status status-${handState.status}`} role="status"><i /><p>{handState.message}</p>{hands && ["error", "camera-required"].includes(handState.status) && <button onClick={onRetry}>Tentar novamente</button>}</div>
        <SettingNumber title="Confirmar pinça" caption="Evita cliques involuntários; solte para selecionar" value={preferences.pinchConfirmMs} display={`${preferences.pinchConfirmMs} ms`} step={10} min={60} max={200} onChange={(pinchConfirmMs) => onUpdate({ pinchConfirmMs })} />
        <SettingNumber title="Tolerância a perdas" caption="Mantém a mão em falhas breves, mas bloqueia cliques sem detecção fresca" value={preferences.handHoldMs} display={`${preferences.handHoldMs} ms`} step={100} min={300} max={900} onChange={(handHoldMs) => onUpdate({ handHoldMs })} />
        <SettingNumber title="Suavidade" caption="Filtro adaptativo: mais estabilidade parado, resposta rápida ao mover" value={preferences.handSmoothing} display={`${Math.round(preferences.handSmoothing * 100)}%`} step={0.1} min={0} max={1} onChange={(handSmoothing) => onUpdate({ handSmoothing })} />
        <SettingSwitch title="Teclado espacial" caption="Abre ao selecionar campos de texto" on={preferences.virtualKeyboard} onChange={() => onUpdate({ virtualKeyboard: !preferences.virtualKeyboard })} />
      </> : page === "dock" ? <>
        <p className="settings-description">Três acabamentos. A mesma dock ancorada no mundo 3D.</p>
        <div className="dock-style-options">{[["glass", "Vidro", "Translúcida e suave"], ["carbon", "Carbon", "Clássica, como sua referência"], ["minimal", "Minimal", "Leve e essencial"]].map(([id, name, caption]) => <button key={id} className={preferences.dockStyle === id ? "is-selected" : ""} onClick={() => onUpdate({ dockStyle: id as MetaPreferences["dockStyle"] })}><div className={`dock-sample sample-${id}`}>{["#739bf0", "#e9a14a", "#bb85dd", "#da6c81", "#7cabb2"].map((color) => <i key={color} style={{ background: color }} />)}</div><strong>{name}</strong><small>{caption}</small>{preferences.dockStyle === id && <Icon name="check" className="h-4 w-4" />}</button>)}</div>
        <SettingNumber title="Tamanho da dock" value={preferences.dockScale} display={`${Math.round(preferences.dockScale * 100)}%`} min={0.65} max={1.2} step={0.05} onChange={(dockScale) => onUpdate({ dockScale })} />
        <h2 className="settings-section-label">Ícones PNG personalizados</h2><div className="icon-customization"><div>{["store", "youtube", "browser", "gallery", "worlds", "settings"].map((id) => <button key={id} className={iconTarget === id ? "is-active" : ""} onClick={() => setIconTarget(id)}>{preferences.iconImages[id] ? <img src={preferences.iconImages[id]} alt="" /> : <Icon name={APPS.find((app) => app.id === id)?.icon ?? "grid"} className="h-5 w-5" />}{APPS.find((app) => app.id === id)?.name}</button>)}</div><button className="mr-secondary" onClick={() => { if (navigator.userActivation && !navigator.userActivation.isActive) setNotice("Toque no botão para autorizar o seletor de imagens."); else fileInput.current?.click(); }}>Selecionar PNG</button><button className="mr-text" onClick={() => { const next = { ...preferences.iconImages }; delete next[iconTarget]; onUpdate({ iconImages: next }); }}>Restaurar ícone</button><input type="file" ref={fileInput} accept="image/png" hidden onChange={(event) => { if (event.target.files?.[0]) void loadIcon(event.target.files[0]); event.target.value = ""; }} /></div>
      </> : page === "appearance" ? <>
        <div className="settings-option"><div><strong>Cor de destaque</strong><small>Usada na janela selecionada</small></div><div className="accent-options">{["#9bbaff", "#95d9be", "#d7adf5", "#f1bf93"].map((accent) => <button key={accent} style={{ background: accent }} className={preferences.accent === accent ? "is-active" : ""} onClick={() => onUpdate({ accent })} aria-label={`Cor ${accent}`} />)}</div></div>
        <SettingSwitch title="Reduzir animações" caption="Mantém o espaço 3D sem transições decorativas" on={preferences.reduceMotion} onChange={() => onUpdate({ reduceMotion: !preferences.reduceMotion })} />
        <button className="settings-option" onClick={onEnvironments}><div><strong>Ambientes virtuais</strong><small>Escolha o cenário sem fechar o Next VR</small></div><Icon name="chevron" className="h-4 w-4" /></button>
      </> : page === "windows" ? <>
        <SettingSwitch title="Multitarefa em arco" caption="Novos apps recebem posições separadas ao redor do usuário" on={preferences.autoArrange} onChange={() => onUpdate({ autoArrange: !preferences.autoArrange })} />
        <SettingNumber title="Escala padrão" caption="Mesmo tamanho inicial para todos os aplicativos" value={preferences.windowScale} display={`${Math.round(preferences.windowScale * 100)}%`} step={0.05} min={0.6} max={1.3} onChange={(windowScale) => onUpdate({ windowScale })} />
        <SettingNumber title="Distância das janelas" value={preferences.windowDistance} display={`${preferences.windowDistance.toFixed(2)} m`} step={0.1} min={1} max={1.9} onChange={(windowDistance) => onUpdate({ windowDistance })} />
        <button className="settings-option" onClick={onArrange}><div><strong>Organizar janelas abertas</strong><small>Distribuir em arco e igualar o tamanho</small></div><Icon name="arc" className="h-5 w-5" /></button>
        <SettingSwitch title="Visualização de dois olhos" caption="Cardboard experimental, em paisagem. Uma câmera compartilhada; não é captura estéreo nativa. Maior consumo de GPU e decodificação de vídeo" on={stereo} onChange={onStereo} />
      </> : page === "performance" ? <>
        <div className="performance-reading"><strong>{fps || "--"}<span>FPS</span></strong><p>Medido nesta sessão, não é uma promessa de desempenho.</p></div>
        {[ ["battery", "Economia", "24 FPS, menor resolução e Hand adaptativo"], ["balanced", "Equilibrado", "45 FPS, resolução reduzida e filtros leves"], ["quality", "Qualidade", "Até 60 FPS; exige mais GPU"] ].map(([id, title, caption]) => <button key={id} className="settings-option" onClick={() => onUpdate({ performance: id as MetaPreferences["performance"] })}><div><strong>{title}</strong><small>{caption}</small></div><span className={`settings-radio ${preferences.performance === id ? "is-selected" : ""}`} /></button>)}
        <p className="settings-description">Sem sombras dinâmicas. Inferência em worker, sem fila de frames. Apps e câmera não são iniciados ao abrir o sistema.</p>
      </> : <>
        <div className="privacy-note"><Icon name="shield" className="h-8 w-8" /><h2>Permissão antes de acesso.</h2><p>Hand processado no seu navegador. Fotos somente pelo seletor do Android. Sem upload automático. YouTube precisa da API oficial para pesquisa integrada.</p></div>
        <button className="settings-option" onClick={onSensors}><div><strong>Recentralizar espaço</strong><small>Reposiciona sua visão sem girar o mundo</small></div><Icon name="compass" className="h-5 w-5" /></button>
        <button className="settings-option" onClick={onReset}><div><strong>Restaurar preferências</strong><small>Não apaga fotos nem arquivos do dispositivo</small></div><Icon name="restore" className="h-5 w-5" /></button>
        <p className="app-footnote">Next VR Web · 3DOF. Rastreamento monocular não fornece ancoragem física 6DOF/SLAM nem acesso ao rastreamento nativo de headsets.</p>
      </>}
      {notice && <p className="app-notice" role="status">{notice}</p>}
    </div>
  </section>;
}