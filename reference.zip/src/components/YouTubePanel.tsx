import { useEffect, useId, useRef, useState, type FormEvent } from "react";
import { Icon } from "../mr/icons";
import {
  isWebLink, parseYouTubeLink, searchYouTube, youtubeSearchUrl, youtubeWatchUrl, youtubeOfficialUrl, youtubeAndroidIntent,
  type YouTubeResult, type YouTubeSelection,
} from "../lib/youtube";
import { YouTubePlayer } from "./YouTubePlayer";

const configuredKey = String(import.meta.env.VITE_YOUTUBE_API_KEY ?? "").trim();

function resultSelection(result: YouTubeResult): YouTubeSelection {
  return { videoId: result.id, playlistId: null, startSeconds: 0, title: result.title, channel: result.channel };
}

export function YouTubePanel({
  hidden = false,
  scale,
  onScale,
}: {
  hidden?: boolean;
  scale: number;
  onScale: (scale: number) => void;
}) {
  const inputId = useId();
  const keyId = useId();
  const input = useRef<HTMLInputElement>(null);
  const request = useRef<AbortController | null>(null);
  const [query, setQuery] = useState("");
  const [selection, setSelection] = useState<YouTubeSelection | null>(null);
  const [history, setHistory] = useState<YouTubeSelection[]>([]);
  const [results, setResults] = useState<YouTubeResult[]>([]);
  const [searchedQuery, setSearchedQuery] = useState("");
  const [nextPage, setNextPage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [status, setStatus] = useState("");
  const [showSearch, setShowSearch] = useState(true);
  const [showSettings, setShowSettings] = useState(false);
  const [apiKey, setApiKey] = useState(configuredKey);
  const [keyDraft, setKeyDraft] = useState(configuredKey);
  const [keyError, setKeyError] = useState("");
  const [externalQuery, setExternalQuery] = useState("");
  const [clipboardBusy, setClipboardBusy] = useState(false);
  const android = /Android/i.test(navigator.userAgent);

  useEffect(() => () => request.current?.abort(), []);

  useEffect(() => {
    if (hidden) { request.current?.abort(); setLoading(false); }
  }, [hidden]);

  function choose(video: YouTubeSelection) {
    request.current?.abort();
    setLoading(false);
    setSelection(video);
    setShowSearch(false);
    setShowSettings(false);
    setError("");
    setStatus("");
    setHistory((previous) => [video, ...previous.filter((item) =>
      item.videoId !== video.videoId || item.playlistId !== video.playlistId,
    )].slice(0, 8));
  }

  async function runSearch(value: string, pageToken?: string, key = apiKey) {
    request.current?.abort();
    const controller = new AbortController();
    request.current = controller;
    let timedOut = false;
    const timeout = window.setTimeout(() => { timedOut = true; controller.abort(); }, 15000);
    setLoading(true);
    setError("");
    setStatus("");
    setShowSearch(true);
    if (!pageToken) { setResults([]); setNextPage(null); setSearchedQuery(value); }
    try {
      const page = await searchYouTube(value, key, controller.signal, pageToken);
      if (controller.signal.aborted) return;
      setResults((previous) => pageToken
        ? [...previous, ...page.videos.filter((video) => !previous.some((item) => item.id === video.id))]
        : page.videos);
      setNextPage(page.nextPageToken);
      if (!page.videos.length && !pageToken) setStatus("Nenhum resultado para esta busca. Tente outro termo.");
    } catch (failure) {
      if (controller.signal.aborted && !timedOut) return;
      setError(timedOut ? "A busca demorou para responder. Tente novamente ou abra o YouTube." : failure instanceof Error && failure.message !== "Failed to fetch"
        ? failure.message : "Sem conex\u00e3o com a busca. Tente novamente ou abra o YouTube.");
    } finally {
      clearTimeout(timeout);
      if (!controller.signal.aborted || timedOut) setLoading(false);
    }
  }

  function submit(event: FormEvent) {
    event.preventDefault();
    const value = query.trim();
    if (!value) { input.current?.focus(); return; }
    const parsed = parseYouTubeLink(value);
    if (parsed) { choose(parsed); return; }
    if (isWebLink(value)) {
      setError("Cole o link de um v\u00eddeo, Short, live ou playlist do YouTube.");
      return;
    }
    if (apiKey) { void runSearch(value); return; }
    setExternalQuery(value);
    setStatus("O YouTube oficial foi aberto em outra aba. O Next VR continua aqui; o app do YouTube pode ser aberto pelo botão App.");
    setError("");
    setShowSearch(true);
    window.open(android ? youtubeAndroidIntent(value) : youtubeSearchUrl(value), "_blank", "noopener");
  }

  async function pasteLink() {
    if (!navigator.clipboard?.readText) {
      setStatus("Cole o link no campo de busca usando o teclado do seu dispositivo.");
      input.current?.focus();
      return;
    }
    setClipboardBusy(true);
    try {
      const text = await navigator.clipboard.readText();
      const parsed = parseYouTubeLink(text);
      setQuery(text);
      if (parsed) choose(parsed);
      else { setError("A \u00e1rea de transfer\u00eancia n\u00e3o cont\u00e9m um link de v\u00eddeo do YouTube."); input.current?.focus(); }
    } catch {
      setStatus("O navegador n\u00e3o permitiu ler a \u00e1rea de transfer\u00eancia. Cole o link manualmente no campo.");
      input.current?.focus();
    } finally {
      setClipboardBusy(false);
    }
  }

  function saveKey(event: FormEvent) {
    event.preventDefault();
    const key = keyDraft.trim();
    if (!/^[A-Za-z0-9_-]{20,120}$/.test(key)) {
      setKeyError("Insira uma chave v\u00e1lida da YouTube Data API v3.");
      return;
    }
    setApiKey(key);
    setKeyError("");
    setShowSettings(false);
    setStatus("Busca no app configurada. Digite o que voc\u00ea quiser assistir.");
    const value = query.trim();
    if (value && !parseYouTubeLink(value) && !isWebLink(value)) void runSearch(value, undefined, key);
  }

  const parsed = parseYouTubeLink(query);
  const cinema = scale >= 1.35;

  return (
    <section className={`youtube-app ${cinema ? "yt-cinema" : ""}`} aria-label="YouTube no espa&#231;o MR">
      <header className="yt-app-header">
        <button type="button" className="yt-brand" title="Escolher outro v&#237;deo" onClick={() => setShowSearch(true)}>
          <span className="yt-brand-mark"><Icon name="play" className="h-5 w-5" /></span>
          <span>YouTube<span className="yt-brand-sub">espacial</span></span>
        </button>
        {android && <a className="yt-text-action yt-native-youtube" href={youtubeAndroidIntent(query)} target="_blank" rel="noopener" title="Abrir o app oficial do YouTube"><Icon name="external" className="h-3.5 w-3.5" />App</a>}
        <div className="flex-1" />
        <a className="yt-text-action" href={youtubeOfficialUrl(query)} target="_blank" rel="noopener" title="Abrir YouTube completo sem chave de API">
          YouTube oficial <Icon name="external" className="h-4 w-4" />
        </a>
        {selection && <button type="button" className="yt-text-action" onClick={() => { setShowSearch((value) => !value); input.current?.focus(); }}>
          <Icon name={showSearch ? "film" : "search"} className="h-4 w-4" />
          {showSearch ? "Voltar ao v\u00eddeo" : "Escolher outro"}
        </button>}
        <button type="button" className={`yt-size-action ${cinema ? "is-active" : ""}`}
          onClick={() => onScale(cinema ? 1 : 1.55)} title="Aumentar ou restaurar a janela, sem reiniciar o v&#237;deo">
          <Icon name={cinema ? "restore" : "expand"} className="h-4 w-4" />
          {cinema ? "Restaurar" : "Cinema"}
        </button>
      </header>

      <form className="yt-search-form" onSubmit={submit}>
        <label className="sr-only" htmlFor={inputId}>Pesquisar ou colar link do YouTube</label>
        <div className="yt-search-input">
          <Icon name={parsed ? "link" : "search"} className="h-4 w-4 shrink-0" />
          <input id={inputId} ref={input} type="text" value={query} autoComplete="off" spellCheck={false}
            inputMode="none" aria-label="Pesquisar vídeos no YouTube"
            placeholder="Pesquisar no YouTube"
            onChange={(event) => { setQuery(event.target.value); setError(""); }} />
          {query && <button type="button" className="yt-clear" title="Limpar busca" onClick={() => { setQuery(""); input.current?.focus(); }}>
            <Icon name="close" className="h-3.5 w-3.5" />
          </button>}
        </div>
        <button type="submit" className="yt-submit" disabled={loading}>
          <Icon name={parsed ? "play" : "search"} className="h-4 w-4" />
          {parsed ? "Assistir aqui" : apiKey ? "Buscar aqui" : "Buscar no YouTube"}
        </button>
        <button type="button" className="yt-paste" disabled={clipboardBusy} onClick={() => void pasteLink()} title="Colar e abrir link copiado">
          <Icon name="clipboard" className="h-4 w-4" />
        </button>
      </form>

      {(error || status) && <div className={`yt-message ${error ? "is-error" : ""}`} role={error ? "alert" : "status"}>
        <p>{error || status}</p>
        {(error || externalQuery) && <a href={youtubeSearchUrl(externalQuery || searchedQuery || query)} target="_blank" rel="noopener">
          Abrir busca <Icon name="external" className="h-3 w-3" />
        </a>}
      </div>}

      {selection && <div className="yt-now-playing">
        <YouTubePlayer selection={selection} hidden={hidden} />
        <div className="yt-video-info">
          <div>
            <h2>{selection.title}</h2>
            <p>{selection.channel ?? (selection.playlistId ? "Playlist escolhida por voc\u00ea" : "V\u00eddeo escolhido por voc\u00ea")}</p>
          </div>
          <a href={youtubeWatchUrl(selection)} target="_blank" rel="noopener" className="yt-text-action">
            YouTube <Icon name="external" className="h-3.5 w-3.5" />
          </a>
        </div>
      </div>}

      {showSearch && <div className="yt-discovery">
        {!selection && !results.length && !loading && !searchedQuery && <div className="yt-empty-state">
          <div className="yt-empty-mark"><Icon name="play" className="h-7 w-7" /></div>
          <h2>O que vamos assistir?</h2>
          <p>{apiKey ? "Pesquise, escolha um resultado e assista nesta janela." : "Acesse o YouTube completo: pesquisa, canais e os vídeos que você escolher."}<br />Sem listas prontas ou vídeos de demonstração.</p>
          <div className="yt-empty-actions">
            {apiKey ? <button type="button" className="yt-primary-link" onClick={() => input.current?.focus()}><Icon name="search" className="h-3.5 w-3.5" />Pesquisar vídeos</button> :
              <a className="yt-primary-link" href={youtubeOfficialUrl(query)} target="_blank" rel="noopener"><Icon name="external" className="h-3.5 w-3.5" />Abrir YouTube</a>}
            {!apiKey && android && <a className="yt-text-action" href={youtubeAndroidIntent(query)} target="_blank" rel="noopener"><Icon name="play" className="h-3.5 w-3.5" />Abrir app do Android</a>}
          </div>
          {!apiKey && <small>O app/site oficial abre fora da janela MR; o Next VR permanece aberto. Busca dentro da janela requer a API oficial.</small>}
        </div>}

        {(loading || results.length > 0) && <div className="yt-search-results" aria-busy={loading} data-scroll>
          <div className="yt-results-heading">
            <h3>Resultados para <span>{searchedQuery}</span></h3>
            <span>Busca ao vivo do YouTube</span>
          </div>
          <div className="yt-results-grid">
            {results.map((result) => <button key={result.id} type="button" className="yt-result" onClick={() => choose(resultSelection(result))}>
              <div className="yt-result-image"><img src={result.thumbnail} alt="" loading="lazy" /><span><Icon name="play" className="h-5 w-5" /></span></div>
              <h4>{result.title}</h4><p>{result.channel}</p>
            </button>)}
            {loading && !results.length && [0, 1, 2].map((index) => <div key={index} className="yt-result-skeleton" aria-hidden="true" />)}
          </div>
          {nextPage && <button type="button" className="yt-load-more" disabled={loading}
            onClick={() => void runSearch(searchedQuery, nextPage)}>{loading ? "Buscando..." : "Carregar mais resultados"}</button>}
        </div>}

        {history.length > 0 && <div className="yt-history">
          <h3>Escolhidos por voc&ecirc;</h3>
          <div>{history.map((item) => <button key={`${item.videoId}-${item.playlistId}`} type="button" onClick={() => choose(item)}>
            <Icon name="history" className="h-3.5 w-3.5" /><span>{item.title === "Seu v\u00eddeo" ? item.videoId : item.title}</span>
          </button>)}</div>
        </div>}
      </div>}

      <footer className="yt-app-bottom">
        <span><Icon name="resize" className="h-3.5 w-3.5" />Arraste ou fa&ccedil;a pin&ccedil;a na quina para mudar o tamanho</span>
        <button type="button" onClick={() => { setKeyDraft(apiKey); setShowSettings((value) => !value); setKeyError(""); }}>
          <Icon name="gear" className="h-3.5 w-3.5" />{apiKey ? "Busca conectada" : "Configurar busca na janela"}
        </button>
      </footer>

      {showSettings && <form className="yt-api-settings" onSubmit={saveKey}>
        <div className="yt-settings-title"><h3>Busca oficial dentro do app</h3>
          <button type="button" title="Fechar configura&#231;&#227;o" onClick={() => setShowSettings(false)}><Icon name="close" className="h-4 w-4" /></button>
        </div>
        <p>Opcional: a busca dentro desta janela precisa de uma chave da <strong>YouTube Data API v3</strong>. Sem ela, o botão Abrir YouTube funciona com o app/site oficial. O site completo bloqueia incorporação em iframe; não simulamos essa navegação.</p>
        <label htmlFor={keyId}>Chave da API</label>
        <div className="yt-key-field">
          <input id={keyId} type="password" value={keyDraft} inputMode="none" placeholder="Sua chave de API" autoComplete="off" spellCheck={false}
            onChange={(event) => { setKeyDraft(event.target.value); setKeyError(""); }} />
          <button type="submit">Conectar</button>
        </div>
        {keyError && <p className="yt-key-error" role="alert">{keyError}</p>}
        <small>A chave digitada fica s&oacute; na mem&oacute;ria desta janela. Como toda chave de frontend, ela &eacute; vis&iacute;vel no navegador: restrinja-a ao seu dom&iacute;nio e &agrave; YouTube Data API.</small>
        <div className="yt-api-links">
          <a href="https://console.cloud.google.com/apis/library/youtube.googleapis.com" target="_blank" rel="noopener">Ativar YouTube Data API <Icon name="external" className="h-3 w-3" /></a>
          {apiKey && <button type="button" onClick={() => { request.current?.abort(); setLoading(false); setApiKey(""); setKeyDraft(""); setResults([]); setNextPage(null); setSearchedQuery(""); }}>Desconectar busca</button>}
        </div>
      </form>}
    </section>
  );
}