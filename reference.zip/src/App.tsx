import { useCallback, useEffect, useMemo, useRef, useState, type CSSProperties } from "react";
import { Quaternion } from "three";
import { StartScreen } from "./components/StartScreen";
import { HUD, SideFabs } from "./components/HUD";
import { Dock } from "./components/Dock";
import { WindowFrame } from "./components/WindowFrame";
import { Spatial } from "./components/Spatial";
import {
  AppsLibrary,
  ContactsPanel,
  GamesPanel,
  GenericPanel,
  HandsPanel,
  LauncherPanel,
  MusicPanel,
  SettingsGrid,
  StoragePanel,
  SystemPanel,
  WifiPanel,
} from "./components/panels";
import { YouTubePanel } from "./components/YouTubePanel";
import { MetaSettings } from "./components/MetaSettings";
import { GalleryPanel } from "./components/GalleryPanel";
import { EnvironmentPanel } from "./components/EnvironmentPanel";
import { LibraryPanel } from "./components/LibraryPanel";
import { StorePanel } from "./components/StorePanel";
import { MultitaskPanel } from "./components/MultitaskPanel";
import { MetaBrowser } from "./components/MetaBrowser";
import { VirtualKeyboard, useSpatialKeyboard } from "./components/VirtualKeyboard";
import { APPS, SETTINGS_TILES, type AppId } from "./data/catalog";
import { Icon } from "./mr/icons";
import { MREngine, requestOrientationPermission, type Vec3 } from "./mr/engine";
import type { HandTrackingState } from "./mr/tracking-types";
import { MIN_WINDOW_SCALE, MAX_WINDOW_SCALE, type ResizeCorner, type WindowResizeResult, type WindowResizeSession } from "./mr/resize";
import { arcPose, flatPose, reserveWorkspaceSlot, isApplicationWindow, WORKSPACE_SLOTS, WINDOW_WIDTH, WINDOW_HEIGHT, type WorkspaceWindow } from "./mr/workspace";
import { useMetaPreferences, type EnvironmentId } from "./lib/preferences";
import type { NextLanguage } from "./lib/preferences";
import { LanguagePicker } from "./components/LanguagePicker";
import { QuickMenu } from "./components/QuickMenu";

type Win = WorkspaceWindow;

function add(p: Vec3, d: Vec3): Vec3 {
  return { x: p.x + d.x, y: p.y + d.y, z: p.z + d.z };
}

function dist(a: Vec3, b: Vec3) {
  return Math.hypot(a.x - b.x, a.y - b.y, a.z - b.z);
}

function titleOf(kind: string) {
  const a = APPS.find((x) => x.id === kind);
  if (a) return a.name;
  const s = SETTINGS_TILES.find((x) => x.id === kind);
  if (s) return s.name;
  if (kind === "settings") return "Configurações";
  if (kind === "home") return "Apps";
  return kind;
}

function widthOf(_kind: string) { return WINDOW_WIDTH; }

let uid = 1;
const WORLD_FRONT: [number, number, number, number] = [0, 0, 0, 1];

export default function App() {
  const { preferences, update: updatePreferences, reset: resetPreferences } = useMetaPreferences();
  const preferencesRef = useRef(preferences);
  preferencesRef.current = preferences;
  useEffect(() => { document.documentElement.lang = preferences.language === "pt" ? "pt-BR" : preferences.language; }, [preferences.language]);
  const keyboard = useSpatialKeyboard(preferences.virtualKeyboard);
  const [keyboardPos, setKeyboardPos] = useState<Vec3>({ x: 0, y: -0.38, z: -1.2 });
  const [menuOpen, setMenuOpen] = useState(false);
  const [menuPos, setMenuPos] = useState<Vec3>({ x: 0, y: 0.02, z: -1.05 });
  const [menuRotation, setMenuRotation] = useState<[number, number, number, number]>([0, 0, 0, 1]);
  const [languageOverlay, setLanguageOverlay] = useState(false);
  const [stereo, setStereo] = useState(false);
  const [fps, setFps] = useState(0);
  const arcBasis = useRef(new Quaternion());
  const stageRef = useRef<HTMLDivElement>(null);
  const engineRef = useRef<MREngine | null>(null);
  const [engine, setEngine] = useState<MREngine | null>(null);
  const [phase, setPhase] = useState<"language" | "start" | "mr">(() => preferences.languageConfigured ? "mr" : "language");
  const [env, setEnv] = useState<EnvironmentId>(preferences.environment);
  const [wins, setWins] = useState<Win[]>([]);
  const winsRef = useRef<Win[]>([]);
  winsRef.current = wins;
  const [activeApp, setActiveApp] = useState<string | null>(null);
  const [activeWindow, setActiveWindow] = useState<string | null>(null);
  const [dockPos, setDockPos] = useState<Vec3>({ x: 0, y: -0.34, z: -1.22 });
  const [hintPos, setHintPos] = useState<Vec3>({ x: 0, y: -0.18, z: -1.28 });
  const [fabPos, setFabPos] = useState<Vec3>({ x: -0.78, y: -0.12, z: -1.2 });
  const [trashPos, setTrashPos] = useState<Vec3>({ x: 0.72, y: -0.42, z: -1.18 });
  const [dragging, setDragging] = useState<string | null>(null);
  const [resizing, setResizing] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [pointer, setPointer] = useState({ x: 0, y: 0 });
  const [pointerVisible, setPointerVisible] = useState(false);
  const [entering, setEntering] = useState(false);
  const [dnd, setDnd] = useState(false);
  const [hands, setHands] = useState(false);
  const [handState, setHandState] = useState<HandTrackingState>({
    status: "off", count: 0, message: "Hand desativado. Ative pela dock quando quiser.",
  });
  const [battery, setBattery] = useState(-1);
  const [online, setOnline] = useState(true);
  const [trashHot, setTrashHot] = useState(false);
  const dragRef = useRef<{ id: string; x: number; y: number; pointerId: number } | null>(null);
  const resizeRef = useRef<{ session: WindowResizeSession; pointerId: number; handle: HTMLElement; result: WindowResizeResult } | null>(null);
  const posMap = useRef<Record<string, Vec3>>({});
  const initialStream = useRef<MediaStream | null>(null);
  const gyroAllowedRef = useRef(true);
  const entryPending = useRef(false);
  const dockMovedRef = useRef(false);
  const [landscape, setLandscape] = useState(() => window.innerWidth > window.innerHeight);

  const chooseLanguage = async (language: NextLanguage) => {
    updatePreferences({ language, languageConfigured: true });
    gyroAllowedRef.current = await requestOrientationPermission();
    setPhase("mr");
  };
  const changeLanguage = (language: NextLanguage) => {
    updatePreferences({ language, languageConfigured: true });
  };

  const enter = async (mode: "passthrough" | "horizon") => {
    if (entryPending.current) return;
    entryPending.current = true;
    setEntering(true);
    try {
      if (mode === "passthrough") {
        try {
          if (navigator.mediaDevices?.getUserMedia) {
            initialStream.current = await navigator.mediaDevices.getUserMedia({
              video: { facingMode: { ideal: "environment" }, width: { ideal: 1280 }, height: { ideal: 720 }, frameRate: { ideal: 30, max: 30 } },
              audio: false,
            });
          }
        } catch { initialStream.current = null; }
      }
      gyroAllowedRef.current = await requestOrientationPermission();
      setHands(false);
      setEnv(mode === "horizon" ? preferencesRef.current.environment : "passthrough");
      setPhase("mr");
    } finally {
      entryPending.current = false;
      setEntering(false);
    }
  };

  useEffect(() => {
    if (phase !== "mr" || !stageRef.current) return;
    const mr = new MREngine(gyroAllowedRef.current);
    mr.passthrough = env === "passthrough";
    mr.handTrackingEnabled = hands;
    mr.mount(stageRef.current);
    if (initialStream.current?.active) {
      mr.attachStream(initialStream.current);
      initialStream.current = null;
    }
    setPointerVisible(false);
    mr.onTrackingState = setHandState;
    mr.onMetrics = (metrics) => setFps(metrics.fps);
    engineRef.current = mr;
    setEngine(mr);

    const onKey = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
      if (e.key === "r" || e.key === "R") mr.recenter();
      if (e.key === "Escape") keyboard.close();
    };
    window.addEventListener("keydown", onKey);

    return () => {
      window.removeEventListener("keydown", onKey);
      mr.unmount();
      dragRef.current = null;
      resizeRef.current?.handle.classList.remove("is-pinch");
      resizeRef.current = null;
      setDragging(null);
      setResizing(null);
      setTrashHot(false);
      setPointerVisible(false);
      document.body.classList.remove("is-pinching");
      document.body.classList.remove("is-resizing");
      engineRef.current = null;
      setEngine(null);
    };
  }, [phase]);

  useEffect(() => {
    if (!engine || phase !== "mr") return;
    engine.recenter();
    const dock = engine.frontPosition(landscape ? 0.62 : 0.85, -0.29, 0);
    const hint = engine.frontPosition(0.88, -0.38, 0);
    const fab = engine.frontPosition(0.66, -0.04, -0.48);
    const trash = engine.frontPosition(0.66, -0.28, 0.42);
    arcBasis.current.copy(engine.camera.quaternion);
    setDockPos(dock);
    setHintPos(hint);
    setFabPos(fab);
    setTrashPos(trash);
    setWins([]);
    setActiveApp(null);
    setActiveWindow(null);
    posMap.current = {
      dock,
      hint,
      fab,
      trash,
      keyboard: { x: 0, y: -0.38, z: -1.2 },
    };
  }, [engine, phase]);

  useEffect(() => {
    const updateOrientation = () => setLandscape(window.innerWidth > window.innerHeight);
    window.addEventListener("resize", updateOrientation);
    return () => window.removeEventListener("resize", updateOrientation);
  }, []);

  useEffect(() => {
    if (!engine || dockMovedRef.current) return;
    const position = engine.frontPosition(landscape ? 0.62 : 0.85, -0.29, 0);
    commitPos("dock", position);
  }, [engine, landscape]);

  useEffect(() => {
    if (!engine) return;
    void engine.setHandTracking(hands);
  }, [hands, engine]);

  useEffect(() => {
    if (engine) engine.setEnvironment(env);
  }, [env, engine]);

  useEffect(() => {
    if (!engine) return;
    engine.configureHands({
      confirmMs: preferences.pinchConfirmMs, holdMs: preferences.handHoldMs,
      smoothing: preferences.handSmoothing,
      fps: preferences.performance === "battery" ? 18 : 28,
      resolution: preferences.performance === "battery" ? 480 : 640,
    });
  }, [engine, preferences.pinchConfirmMs, preferences.handHoldMs, preferences.handSmoothing, preferences.performance]);

  useEffect(() => { engine?.setGyroSensitivity(preferences.gyroSensitivity); }, [engine, preferences.gyroSensitivity]);

  useEffect(() => { engine?.setPerformance(preferences.performance); }, [engine, preferences.performance]);
  useEffect(() => { engine?.setStereo(stereo); }, [engine, stereo]);

  useEffect(() => {
    if (!engine || !keyboard.opened) return;
    const position = engine.frontPosition(1.05, -0.38, 0);
    posMap.current.keyboard = position;
    setKeyboardPos(position);
  }, [engine, keyboard.opened]);

  const changeHands = useCallback((enabled: boolean) => {
    setHands(enabled);
    void engineRef.current?.setHandTracking(enabled, enabled);
  }, []);

  const centralizeView = useCallback(() => {
    engineRef.current?.recenter();
  }, []);

  const openQuickMenu = useCallback(() => {
    const mr = engineRef.current;
    if (!mr) return;
    setMenuPos(mr.frontPosition(0.92, 0.02, 0));
    setMenuRotation(mr.camera.quaternion.toArray() as [number, number, number, number]);
    setMenuOpen(true);
  }, []);

  const changeEnvironment = useCallback((environment: EnvironmentId) => {
    const mr = engineRef.current;
    if (!mr) return;
    if (environment === "passthrough") {
      void mr.startPassthrough().then((ok) => { if (ok) setEnv("passthrough"); });
    } else {
      setEnv(environment);
      updatePreferences({ environment });
    }
  }, [updatePreferences]);

  useEffect(() => {
    const nav = navigator as Navigator & {
      getBattery?: () => Promise<{ level: number }>;
    };
    nav.getBattery?.().then((b) => setBattery(Math.round(b.level * 100))).catch(() => {});
    setOnline(navigator.onLine);
    const on = () => setOnline(true);
    const off = () => setOnline(false);
    window.addEventListener("online", on);
    window.addEventListener("offline", off);
    return () => {
      window.removeEventListener("online", on);
      window.removeEventListener("offline", off);
    };
  }, []);

  const getPos = (id: string): Vec3 => posMap.current[id] ?? { x: 0, y: 0, z: -1.2 };

  const commitPos = (id: string, p: Vec3) => {
    posMap.current[id] = p;
    engineRef.current?.setPose(id, p, false);
    if (id === "dock") setDockPos(p);
    else if (id === "hint") setHintPos(p);
    else if (id === "fab") setFabPos(p);
    else if (id === "trash") setTrashPos(p);
    else if (id === "keyboard") setKeyboardPos(p);
    else setWins((ws) => ws.map((w) => (w.id === id ? { ...w, pos: p } : w)));
  };

  const finishDrag = (id: string, position: Vec3) => {
    if (!["dock", "hint", "fab", "trash", "keyboard"].includes(id) && dist(position, getPos("trash")) < 0.28) {
      setWins((ws) => ws.filter((w) => w.id !== id));
      engineRef.current?.detach(id);
      delete posMap.current[id];
    } else {
      commitPos(id, position);
    }
    setDragging(null);
    setTrashHot(false);
    document.body.classList.remove("is-pinching");
  };

  const setWindowScale = useCallback((id: string, requestedScale: number) => {
    const scale = Math.min(MAX_WINDOW_SCALE, Math.max(MIN_WINDOW_SCALE, requestedScale));
    engineRef.current?.setScale(id, scale);
    setWins((windows) => windows.map((window) => window.id === id
      ? { ...window, scale, pos: posMap.current[id] ?? window.pos } : window));
  }, []);

  const finishResize = (result: WindowResizeResult) => {
    posMap.current[result.id] = result.position;
    setWins((windows) => windows.map((window) => window.id === result.id
      ? { ...window, pos: result.position, scale: result.scale } : window));
    setResizing(null);
    document.body.classList.remove("is-pinching", "is-resizing");
  };

  useEffect(() => {
    if (!engine) return;
    engine.onHandPointer = (point) => {
      setPointerVisible(point !== null);
      stageRef.current?.querySelectorAll<HTMLElement>(".reticle").forEach((cursor) => {
        if (!point) return;
        const offset = cursor.classList.contains("reticle-right") ? (stageRef.current?.clientWidth ?? 0) / 2 : 0;
        cursor.style.left = `${point.x + offset}px`; cursor.style.top = `${point.y}px`;
        cursor.style.setProperty("--pinch-progress", `${(point.progress ?? 0) * 360}deg`);
        cursor.classList.toggle("is-pinching", point.pinching === true);
        cursor.classList.toggle("is-stale", point.fresh === false);
      });
    };
    engine.onWindowSelect = (id) => {
      const window = winsRef.current.find((item) => item.id === id);
      if (window) { setActiveWindow(id); setActiveApp(window.kind); }
    };
    engine.onHandDrag = (event) => {
      posMap.current[event.id] = event.position;
      if (event.phase === "start") {
        if (event.id === "dock") dockMovedRef.current = true;
        setDragging(event.id);
        document.body.classList.add("is-pinching");
      } else if (event.phase === "move") {
        setTrashHot(!["dock", "hint", "fab", "trash"].includes(event.id) &&
          dist(event.position, getPos("trash")) < 0.28);
      } else {
        finishDrag(event.id, event.position);
      }
    };
    engine.onHandResize = (event) => {
      posMap.current[event.id] = event.position;
      if (event.phase === "start") {
        setResizing(event.id);
        const kind = winsRef.current.find((window) => window.id === event.id)?.kind;
        if (kind) setActiveApp(kind);
        document.body.classList.add("is-pinching", "is-resizing");
      } else if (event.phase === "end") finishResize(event);
    };
    return () => {
      engine.onHandPointer = null;
      engine.onHandDrag = null;
      engine.onHandResize = null;
      engine.onWindowSelect = null;
    };
  }, [engine]);

  useEffect(() => {
    const down = (e: PointerEvent) => {
      const mr = engineRef.current;
      if (e.button !== 0 || !mr || mr.handDragging || dragRef.current || resizeRef.current) return;
      const t = e.target as HTMLElement;
      if (t.closest?.("[data-eye-mirror]")) return;
      const resizeHandle = t.closest?.<HTMLElement>("[data-resize]");
      if (resizeHandle) {
        const id = resizeHandle.closest<HTMLElement>("[data-win]")?.dataset.win;
        const corner = resizeHandle.dataset.resize as ResizeCorner;
        const session = id && mr.beginResize(id, corner, e.clientX, e.clientY);
        if (!session) return;
        e.preventDefault();
        e.stopPropagation();
        resizeRef.current = {
          session, pointerId: e.pointerId, handle: resizeHandle,
          result: { id: session.id, scale: session.startScale, position: getPos(session.id) },
        };
        resizeHandle.classList.add("is-pinch");
        setResizing(session.id);
        const kind = winsRef.current.find((window) => window.id === session.id)?.kind;
        if (kind) setActiveApp(kind);
        mr.pointerDragActive = true;
        document.body.classList.add("is-pinching", "is-resizing");
        return;
      }
      const grab = t.closest?.("[data-grab]") as HTMLElement | null;
      if (!grab) return;
      const winEl = t.closest?.("[data-win]") as HTMLElement | null;
      const id = winEl?.dataset.win;
      if (!id) return;
      e.stopPropagation();
      dragRef.current = { id, x: e.clientX, y: e.clientY, pointerId: e.pointerId };
      if (id === "dock") dockMovedRef.current = true;
      setDragging(id);
      if (engineRef.current) engineRef.current.pointerDragActive = true;
      document.body.classList.add("is-pinching");
    };
    const move = (e: PointerEvent) => {
      if ((e.target as HTMLElement).closest?.("[data-eye-mirror]")) return;
      if (e.pointerType === "mouse" && !engineRef.current?.handTrackingEnabled) {
        setPointer({ x: e.clientX, y: e.clientY });
        setPointerVisible(true);
      }
      const d = dragRef.current;
      const mr = engineRef.current;
      const resize = resizeRef.current;
      if (resize && mr) {
        if (resize.pointerId !== e.pointerId) return;
        const result = mr.updateResize(resize.session, e.clientX, e.clientY);
        if (result) {
          resize.result = result;
          posMap.current[result.id] = result.position;
        }
        return;
      }
      if (!d || !mr) return;
      if (d.pointerId !== e.pointerId) return;
      const delta = mr.dragDelta(e.clientX - d.x, e.clientY - d.y);
      d.x = e.clientX;
      d.y = e.clientY;
      const next = add(getPos(d.id), delta);
      posMap.current[d.id] = next;
      mr.setPose(d.id, next, false);
      setTrashHot(!["dock", "hint", "fab", "trash"].includes(d.id) && dist(next, getPos("trash")) < 0.28);
    };
    const up = (event: Event) => {
      if ((event.target as HTMLElement)?.closest?.("[data-eye-mirror]")) return;
      const d = dragRef.current;
      const mr = engineRef.current;
      const resize = resizeRef.current;
      if (event instanceof PointerEvent && event.pointerId !== (resize?.pointerId ?? d?.pointerId)) return;
      if (resize) {
        resize.handle.classList.remove("is-pinch");
        finishResize(resize.result);
        resizeRef.current = null;
        if (mr) mr.pointerDragActive = false;
        return;
      }
      if (!d) return;
      finishDrag(d.id, getPos(d.id));
      dragRef.current = null;
      if (mr) mr.pointerDragActive = false;
    };
    const wheel = (e: WheelEvent) => {
      if (resizeRef.current || dragRef.current || engineRef.current?.handDragging) return;
      const t = e.target as HTMLElement;
      const winEl = t.closest?.("[data-win]") as HTMLElement | null;
      const id = winEl?.dataset.win;
      const mr = engineRef.current;
      if (!id || !mr || id === "trash") return;
      if (!t.closest("[data-grab]") && !e.shiftKey) return;
      e.preventDefault();
      const next = add(getPos(id), mr.pushDepth(e.deltaY));
      commitPos(id, next);
    };
    window.addEventListener("pointerdown", down, true);
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
    window.addEventListener("pointercancel", up);
    window.addEventListener("blur", up);
    window.addEventListener("wheel", wheel, { passive: false });
    return () => {
      window.removeEventListener("pointerdown", down, true);
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
      window.removeEventListener("pointercancel", up);
      window.removeEventListener("blur", up);
      window.removeEventListener("wheel", wheel);
    };
  }, []);

  const openApp = useCallback(
    (kind: AppId | string) => {
      const mr = engineRef.current;
      if (!mr) return;
      if (kind === "home") kind = "apps";
      setActiveApp(kind);
      const previous = winsRef.current;
      const existing = previous.find((window) => window.kind === kind);
      if (existing && !existing.minimized) {
        setActiveWindow(existing.id);
        return;
      }
      const id = existing?.id ?? `w-${kind}-${uid++}`;
      const isApp = kind !== "multitask";
      const reserved = isApp ? reserveWorkspaceSlot(previous, id) : { windows: previous, slot: 0, minimizedIds: [] as string[] };
      reserved.minimizedIds.forEach((minimizedId) => {
        keyboard.closeForWindow(minimizedId);
        mr.setVisible(minimizedId, false);
      });
      if (isApp) arcBasis.current.copy(mr.camera.quaternion);
      const pref = preferencesRef.current;
      const scale = existing?.scale ?? pref.windowScale;
      const slot = reserved.slot;
      const radius = Math.max(pref.windowDistance, WINDOW_WIDTH * scale * 0.001 / 0.62);
      const initialPose = isApp
        ? pref.autoArrange ? arcPose(slot, radius, arcBasis.current) : flatPose(slot, radius, arcBasis.current, scale)
        : { pos: mr.frontPosition(1.65, 0.65, 0), rotation: mr.camera.quaternion.toArray() as [number, number, number, number] };
      const win: Win = { id, kind, title: titleOf(kind), ...initialPose, width: widthOf(kind), scale, minimized: false, slot };
      let next = existing ? reserved.windows.map((window) => window.id === id ? win : window) : [...reserved.windows, win];
      if (isApp && pref.autoArrange) {
        const activeApps = next.filter((window) => isApplicationWindow(window) && !window.minimized);
        next = next.map((window) => {
          if (!isApplicationWindow(window) || window.minimized) return window;
          const appIndex = activeApps.findIndex((app) => app.id === window.id);
          const appSlot = WORKSPACE_SLOTS[appIndex] ?? 0;
          const appRadius = Math.max(pref.windowDistance, WINDOW_WIDTH * window.scale * 0.001 / 0.62);
          const pose = arcPose(appSlot, appRadius, arcBasis.current);
          posMap.current[window.id] = pose.pos;
          mr.setPose(window.id, pose.pos);
          mr.setRotation(window.id, pose.rotation);
          mr.setVisible(window.id, true);
          return { ...window, ...pose, slot: appSlot };
        });
      }
      const finalWindow = next.find((window) => window.id === id)!;
      posMap.current[id] = finalWindow.pos;
      winsRef.current = next;
      setActiveWindow(id);
      setWins(next);
      if (existing) {
        mr.setPose(id, finalWindow.pos);
        mr.setRotation(id, finalWindow.rotation);
        mr.setVisible(id, true);
      }
    },
    [],
  );

  const openThreeApps = useCallback(() => {
    const mr = engineRef.current;
    if (!mr) return;
    const current = winsRef.current.map((window) => {
      if (!isApplicationWindow(window) || window.minimized) return window;
      keyboard.closeForWindow(window.id);
      mr.setVisible(window.id, false);
      return { ...window, minimized: true };
    });
    winsRef.current = current;
    setWins(current);
    // User-requested trio only; startup still launches no applications.
    openApp("youtube");
    openApp("browser");
    openApp("gallery");
  }, [openApp]);

  const closeWin = (id: string) => {
    keyboard.closeForWindow(id);
    engineRef.current?.detach(id);
    setWins((ws) => ws.filter((w) => w.id !== id));
    delete posMap.current[id];
    const remaining = winsRef.current.filter((window) => window.id !== id && !window.minimized);
    if (activeWindow === id || !remaining.length) {
      setActiveWindow(remaining[0]?.id ?? null);
      setActiveApp(remaining[0]?.kind ?? null);
    }
    if (!remaining.length) engineRef.current?.recenter();
  };

  const minimizeWin = (id: string) => {
    keyboard.closeForWindow(id);
    engineRef.current?.setVisible(id, false);
    setWins((windows) => windows.map((window) => window.id === id ? { ...window, minimized: true } : window));
    if (!winsRef.current.some((window) => window.id !== id && !window.minimized)) engineRef.current?.recenter();
  };

  const arrangeWindows = useCallback(() => {
    const mr = engineRef.current;
    if (!mr || mr.handDragging || mr.pointerDragActive) return;
    const pref = preferencesRef.current;
    arcBasis.current.copy(mr.camera.quaternion);
    let ordinal = 0;
    setWins((windows) => windows.map((window) => {
      if (window.minimized) return window;
      if (!isApplicationWindow(window)) {
        const pose = { pos: mr.frontPosition(1.65, 0.75, 0), rotation: mr.camera.quaternion.toArray() as [number, number, number, number] };
        posMap.current[window.id] = pose.pos;
        mr.setPose(window.id, pose.pos); mr.setRotation(window.id, pose.rotation);
        return { ...window, ...pose };
      }
      if (ordinal >= WORKSPACE_SLOTS.length) {
        mr.setVisible(window.id, false);
        return { ...window, minimized: true };
      }
      const slot = WORKSPACE_SLOTS[ordinal];
      ordinal++;
      const pose = arcPose(slot, Math.max(pref.windowDistance, WINDOW_WIDTH * pref.windowScale * 0.001 / 0.62), arcBasis.current);
      posMap.current[window.id] = pose.pos;
      mr.setPose(window.id, pose.pos); mr.setRotation(window.id, pose.rotation); mr.setScale(window.id, pref.windowScale);
      return { ...window, ...pose, slot, scale: pref.windowScale };
    }));
  }, []);

  const focusWindow = (id: string) => {
    const window = winsRef.current.find((item) => item.id === id);
    if (window) openApp(window.kind);
  };

  const body = useMemo(() => {
    return (w: Win) => {
      const open = (id: AppId) => openApp(id);
      switch (w.kind) {
        case "settings":
          return <MetaSettings preferences={preferences} onUpdate={updatePreferences} onReset={resetPreferences}
            hands={hands} handState={handState} onHands={changeHands} onRetry={() => void engineRef.current?.retryHandTracking()}
            onArrange={arrangeWindows} onEnvironments={() => openApp("worlds")} onSensors={() => { engineRef.current?.enableOrientation(); centralizeView(); }} fps={fps} stereo={stereo} onStereo={() => setStereo((value) => !value)} language={preferences.language} onLanguage={changeLanguage} />;
        case "apps":
        case "home":
          return <LibraryPanel onOpen={open} images={preferences.iconImages} recent={wins.map((window) => window.kind)} />;
        case "store": return <StorePanel onOpen={open} />;
        case "multitask": return <MultitaskPanel windows={wins} active={activeWindow} onFocus={focusWindow} onClose={closeWin} onMinimize={minimizeWin} onArrange={arrangeWindows} onOpenThree={openThreeApps} />;
        case "gallery":
        case "photos":
        case "media": return <GalleryPanel />;
        case "worlds": return <EnvironmentPanel current={env} onSelect={changeEnvironment} />;
        case "camera": return <div className="camera-app"><header className="app-heading"><div><h1>Câmera MR</h1><p>Compartilhada com Hand, sem processos duplicados.</p></div></header><div className="mr-empty"><Icon name="camera" className="h-10 w-10" /><h2>{env === "passthrough" ? "Você está no mundo real." : "A câmera está sob seu controle."}</h2><p>A câmera não é iniciada com o sistema. Ative quando precisar.</p><button className="mr-primary" onClick={() => changeEnvironment(env === "passthrough" ? "studio" : "passthrough")}>{env === "passthrough" ? "Voltar ao ambiente virtual" : "Ativar câmera MR"}</button></div><p className="app-footnote">Se o Hand estiver ativo, a câmera continua necessária para rastreamento. Desative o Hand para interromper totalmente seu uso.</p></div>;
        case "contacts":
          return <ContactsPanel />;
        case "youtube":
          return <YouTubePanel hidden={w.minimized} scale={w.scale} onScale={(scale) => setWindowScale(w.id, scale)} />;
        case "browser":
          return <MetaBrowser onYouTube={() => openApp("youtube")} hidden={w.minimized} />;
        case "storage":
          return <StoragePanel />;
        case "wifi":
          return <WifiPanel />;
        case "system":
          return (
            <SystemPanel
              passthrough={env === "passthrough"}
              setPassthrough={(v) => changeEnvironment(v ? "passthrough" : "studio")}
              dnd={dnd}
              setDnd={setDnd}
            />
          );
        case "hands":
          return <HandsPanel
            tracking={hands}
            state={handState}
            setTracking={(enabled) => {
              changeHands(enabled);
            }}
            onRetry={() => {
              setHands(true);
              void engineRef.current?.retryHandTracking();
            }}
          />;
        case "personalization":
          return <EnvironmentPanel current={env} onSelect={changeEnvironment} />;
        case "experimental": return <SettingsGrid onOpen={open} query={search} setQuery={setSearch} />;
        case "legacy-apps": return <AppsLibrary onOpen={open} />;
        case "music":
          return <MusicPanel />;
        case "games":
          return <GamesPanel onOpen={open} />;
        case "feed":
          return <LauncherPanel onOpen={open} />;
        case "notifications":
          return (
            <GenericPanel
              title="Notifications"
              subtitle={dnd ? "Do Not Disturb ligado" : "Phone Notifications, Do Not Disturb"}
            />
          );
        default: {
          const tile = SETTINGS_TILES.find((t) => t.id === w.kind);
          const app = APPS.find((a) => a.id === w.kind);
          return <GenericPanel title={w.title} subtitle={tile?.subtitle ?? app?.subtitle} />;
        }
      }
    };
  }, [search, env, dnd, hands, handState, openApp, setWindowScale, preferences, fps, stereo, wins, activeWindow]);

  if (phase === "language") {
    return <LanguagePicker initial={preferences.language} onSelect={chooseLanguage} />;
  }

  if (phase === "start") {
    return <StartScreen onEnter={enter} busy={entering} camOk={false} />;
  }

  return (
    <div ref={stageRef} style={{ "--mr-accent": preferences.accent } as CSSProperties} className={`mr-root metamr-desktop performance-${preferences.performance} ${preferences.reduceMotion ? "reduce-motion" : ""} ${stereo ? "stereo-mode" : ""} ${dragging || resizing ? "is-pinching" : ""} ${resizing ? "is-resizing" : ""}`}>
      <HUD
        onExit={() => {
          changeHands(false);
          engine?.stopPassthrough();
          setPhase("start");
        }}
        onRecenter={() => {
          const mr = engineRef.current;
          if (!mr) return;
          centralizeView();
        }}
        pointer={pointer}
        pointerVisible={pointerVisible}
        cardboard={false}
        minimal={true}
        stereo={stereo}
      />

      {engine && (
        <>
          <Spatial id="desktop-brand" engine={engine} position={{ x: 0, y: 0.13, z: -1.9 }} rotation={WORLD_FRONT} visible={!wins.some((window) => !window.minimized)}>
            <div className="desktop-brand"><span className="desktop-logo"><i />N</span><h1>Next VR</h1><p>Seu espaço. Suas possibilidades.</p><small>Escolha um app na dock para começar.</small></div>
          </Spatial>
          <Spatial id="dock" engine={engine} position={dockPos} rotation={WORLD_FRONT} scale={preferences.dockScale}>
            <div data-win="dock">
              <Dock
                onOpen={openApp}
                onPlus={() => openApp("apps")}
                battery={battery}
                online={online}
                grabbing={dragging === "dock"}
                windows={wins}
                activeApp={activeApp}
                style={preferences.dockStyle} images={preferences.iconImages} hands={hands}
                onHands={() => changeHands(!hands)} onKeyboard={keyboard.toggle} onArrange={arrangeWindows}
                onRecenter={centralizeView} onMenu={openQuickMenu} menuOpen={menuOpen} language={preferences.language}
              />
            </div>
          </Spatial>

          {menuOpen && <Spatial id="quick-menu" engine={engine} position={menuPos} rotation={menuRotation} scale={0.84}>
            <div data-win="quick-menu"><QuickMenu language={preferences.language} battery={battery} online={online} hands={hands}
              recents={wins.filter((window) => window.kind !== "multitask")}
              onClose={() => setMenuOpen(false)} onRecenter={centralizeView}
              onOpen={(kind) => { setMenuOpen(false); openApp(kind); }} onHands={() => changeHands(!hands)} onLanguage={() => { setMenuOpen(false); setLanguageOverlay(true); }} />
            </div>
          </Spatial>}

          <Spatial id="hint" engine={engine} position={hintPos} rotation={WORLD_FRONT} visible={hands && !keyboard.opened}>
            <div data-win="hint" className="flex flex-col items-center gap-2">
              <div className="hint-pill">
                {hands ? (
                  handState.status === "tracking" ? "Aponte e faça pinça para selecionar ou mover" :
                  handState.status === "loading" ? "Carregando Hand pela câmera..." :
                  handState.status === "ready" ? "Mostre a mão inteira para a câmera" :
                  "Ative a câmera em Hands and Controllers"
                ) : "Olhe para um cartão e toque para selecionar"}
              </div>
              <div className="grab-bar" data-grab="hint" />
            </div>
          </Spatial>

          <Spatial id="fab" engine={engine} position={fabPos} visible={false}>
            <div data-win="fab" className="flex flex-col items-center gap-3">
              <SideFabs onLayers={() => openApp("apps")} onShare={() => openApp("feed")} />
              <div className="grab-bar" data-grab="fab" />
            </div>
          </Spatial>

          <Spatial id="trash" engine={engine} position={trashPos} rotation={WORLD_FRONT} visible={!!dragging && !["dock", "hint", "fab", "keyboard"].includes(dragging)}>
            <div
              data-win="trash"
              className={`grid h-[88px] w-[88px] place-items-center rounded-[28px] border border-white/15 bg-black/55 text-white backdrop-blur-xl transition ${
                trashHot ? "scale-110 ring-2 ring-red-400 bg-red-500/30" : ""
              }`}
            >
              <Icon name="trash" className="h-8 w-8" />
            </div>
          </Spatial>

          {keyboard.opened && <Spatial id="keyboard" engine={engine} position={keyboardPos} rotation={WORLD_FRONT} scale={0.95}>
            <div data-win="keyboard"><VirtualKeyboard text={keyboard.text} label={keyboard.label} onKey={keyboard.press} onClose={keyboard.close} /></div>
          </Spatial>}

          {wins.map((w) => (
            <Spatial key={w.id} id={w.id} engine={engine} position={w.pos} rotation={w.rotation} scale={w.scale} visible={!w.minimized}>
              <div data-win={w.id} onPointerDown={() => { setActiveApp(w.kind); setActiveWindow(w.id); }}>
                <WindowFrame
                  title={w.title}
                  width={w.width}
                  onClose={() => closeWin(w.id)}
                  onMinimize={() => minimizeWin(w.id)}
                  grabbing={dragging === w.id}
                  scale={w.scale}
                  resizing={resizing === w.id}
                  onScale={(scale) => setWindowScale(w.id, scale)}
                  height={WINDOW_HEIGHT} selected={activeWindow === w.id}
                >
                  {body(w)}
                </WindowFrame>
              </div>
            </Spatial>
          ))}
        </>
      )}
      {languageOverlay && <div className="language-dialog-overlay"><LanguagePicker initial={preferences.language} onSelect={(language) => { changeLanguage(language); setLanguageOverlay(false); }} onClose={() => setLanguageOverlay(false)} /></div>}
    </div>
  );
}
